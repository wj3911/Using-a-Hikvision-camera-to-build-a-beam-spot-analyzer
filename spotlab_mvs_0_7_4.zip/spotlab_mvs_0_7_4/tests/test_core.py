import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from spotlab.core import (AnalysisOptions, _crossing_width, analyze_image, average_frames, center_offset,
                          load_grayscale, make_demo_beam, make_reference_overlay)


class CoreTests(unittest.TestCase):
    def test_demo_metrics_are_finite(self):
        image, white, _ = make_demo_beam(seed=7)
        result = analyze_image(image, white)
        for key in ("centroid_x", "centroid_y", "d4sigma_x", "d4sigma_y", "fwhm_x", "fwhm_y", "snr"):
            self.assertTrue(np.isfinite(result[key]), key)
            self.assertGreater(result[key], 0)
        self.assertGreater(result["d4sigma_x"], result["fwhm_x"])
        self.assertGreater(result["d4sigma_y"], result["fwhm_y"])
        self.assertTrue(result["gaussian_x"]["valid"])
        self.assertTrue(result["gaussian_y"]["valid"])
        self.assertLess(abs(result["centroid_x"] - 0.49 * image.shape[1]), 25)

    def test_fast_mode_preserves_pixel_scale(self):
        image, white, _ = make_demo_beam(seed=3)
        full = analyze_image(image, white)
        fast = analyze_image(image, white, AnalysisOptions(fast_mode=True))
        self.assertAlmostEqual(full["centroid_x"], fast["centroid_x"], delta=2.0)
        self.assertAlmostEqual(full["d4sigma_x"], fast["d4sigma_x"], delta=5.0)
        self.assertEqual(fast["fast_step"], 2)

    def test_roi_coordinates_remain_global(self):
        image, white, _ = make_demo_beam(seed=4)
        result = analyze_image(image, white, roi=(120, 100, 900, 680))
        self.assertGreater(result["centroid_x"], 120)
        self.assertLess(result["centroid_x"], 900)
        self.assertGreater(result["centroid_y"], 100)
        self.assertLess(result["centroid_y"], 680)

    def test_average_frames(self):
        a = np.full((12, 14), 20, dtype=np.float32)
        b = np.full((12, 14), 40, dtype=np.float32)
        mean = average_frames([a, b])
        self.assertEqual(mean.shape, a.shape)
        self.assertTrue(np.allclose(mean, 30))
        with self.assertRaises(ValueError):
            average_frames([a, np.zeros((4, 5), dtype=np.float32)])

    def test_16_bit_tiff_is_loaded(self):
        raw = np.zeros((20, 30), dtype=np.uint16)
        raw[7:13, 10:20] = 42000
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "test16.tif"
            Image.fromarray(raw).save(path)
            loaded, white, meta = load_grayscale(path)
        self.assertEqual(loaded.shape, raw.shape)
        self.assertEqual(white, 65535)
        self.assertEqual(meta["bit_depth"], 16)
        self.assertEqual(float(loaded.max()), 42000.0)

    def test_saturated_region_is_flagged(self):
        img = np.full((80, 100), 4, dtype=np.float32)
        img[25:55, 35:65] = 255
        result = analyze_image(img, 255)
        self.assertGreater(result["saturated_fraction"], .001)
        self.assertEqual(result["quality"], "检查")
        self.assertIn("存在饱和像素", result["quality_reasons"])

    def test_reference_overlay_is_independent_transparent_layer(self):
        image = np.zeros((50, 60), dtype=np.float32)
        image[20:30, 25:35] = 100
        original = image.copy()
        rgba = make_reference_overlay(image, baseline=0, peak=100, clip_percent=13.5)
        self.assertEqual(rgba.shape, (50, 60, 4))
        self.assertEqual(int(rgba[0, 0, 3]), 0)
        self.assertGreater(int(rgba[24, 30, 3]), 0)
        self.assertTrue(np.array_equal(image, original))

    def test_center_offset_sign_and_distance(self):
        dx, dy, distance = center_offset((12, 17), (9, 21))
        self.assertEqual(dx, 3)
        self.assertEqual(dy, -4)
        self.assertAlmostEqual(distance, 5)

    def test_fwhm_crossing_ignores_an_isolated_speckle_notch_in_flat_top(self):
        coords = np.arange(101, dtype=np.float64)
        profile = np.zeros(101, dtype=np.float64)
        profile[30:71] = 100.0
        profile[31] = 0.0  # a one-pixel notch beside the maximum should not collapse FWHM
        width = _crossing_width(profile, coords, baseline=0.0, fraction=0.5)
        self.assertAlmostEqual(width, 41.0, delta=1.0)

    def test_projected_fwhm_resists_a_speckled_single_row(self):
        height, width = 301, 401
        yy, xx = np.mgrid[0:height, 0:width]
        cx, cy, sx, sy = 200.0, 150.0, 50.0, 45.0
        image = 5.0 + 220.0 * np.exp(-0.5 * (((xx - cx) / sx) ** 2 + ((yy - cy) / sy) ** 2))
        # A coherent fringe can create a narrow apparent line width through the
        # centroid, without changing the full 2-D beam envelope appreciably.
        cy_index = int(cy)
        narrow_row = 5.0 + 220.0 * np.exp(-0.5 * ((xx[cy_index] - cx) / 2.0) ** 2)
        image[cy_index - 1:cy_index + 2, :] = narrow_row
        result = analyze_image(image.astype(np.float32), 255.0)
        line_width = _crossing_width(result["x_profile"], result["x_coords"],
                                     result["baseline"], 0.5)
        self.assertLess(line_width, 20.0)
        self.assertAlmostEqual(result["fwhm_x"], 2.3548 * sx, delta=8.0)
        self.assertGreater(result["fwhm_x"], line_width * 5)

    def test_custom_sample_step_preserves_original_pixel_coordinates(self):
        image, white, _ = make_demo_beam(width=600, height=420, seed=5)
        result = analyze_image(image, white, AnalysisOptions(sample_step=3))
        self.assertEqual(result["fast_step"], 3)
        self.assertAlmostEqual(result["centroid_x"], 0.49 * 600, delta=4.0)
        self.assertAlmostEqual(result["fwhm_x"], 2.3548 * 600 * .105, delta=8.0)


if __name__ == "__main__":
    unittest.main()
