import queue
import threading
import unittest
from types import SimpleNamespace

import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.patches import Ellipse

from spotlab.app import (CAM_EXPOSURE_MAX_US, CAM_EXPOSURE_MIN_US,
                         SpotLabApp)
from spotlab.core import AnalysisOptions, analyze_image


class CameraPresetHelperTests(unittest.TestCase):
    def test_exposure_log_slider_round_trip(self):
        for exposure_us in (CAM_EXPOSURE_MIN_US, 25.0, 10_000.0, 250_000.0, CAM_EXPOSURE_MAX_US):
            position = SpotLabApp._exposure_to_position(exposure_us)
            restored = SpotLabApp._position_to_exposure(position)
            self.assertAlmostEqual(restored, exposure_us, delta=max(1e-8, exposure_us * 1e-10))

    def test_exposure_slider_clamps_to_preset_limits(self):
        self.assertAlmostEqual(SpotLabApp._exposure_to_position(0.0), 0.0)
        self.assertAlmostEqual(SpotLabApp._exposure_to_position(2_000_000.0), 100.0)
        self.assertAlmostEqual(SpotLabApp._position_to_exposure(-10), CAM_EXPOSURE_MIN_US)
        self.assertAlmostEqual(SpotLabApp._position_to_exposure(120), CAM_EXPOSURE_MAX_US)

    def test_exposure_slider_uses_actual_device_range(self):
        minimum, maximum, value = 3.5, 250_000.0, 14_000.0
        position = SpotLabApp._exposure_to_position(value, minimum, maximum)
        restored = SpotLabApp._position_to_exposure(position, minimum, maximum)
        self.assertAlmostEqual(restored, value, delta=1e-8)
        self.assertEqual(SpotLabApp._exposure_to_position(minimum, minimum, maximum), 0.0)
        self.assertEqual(SpotLabApp._exposure_to_position(maximum, minimum, maximum), 100.0)

    def test_exposure_readout_uses_microseconds_and_milliseconds(self):
        self.assertEqual(SpotLabApp._format_exposure(500), "500 µs")
        self.assertEqual(SpotLabApp._format_exposure(10_000), "10.00 ms")

    def test_highlight_statistic_detects_a_clipped_beam(self):
        frame = np.full((80, 80), 12, dtype=np.uint8)
        frame[24:56, 24:56] = 255
        high, clipped = SpotLabApp._camera_high_percentile(frame)
        self.assertEqual(high, 255)
        self.assertGreater(clipped, .001)

    def test_safe_auto_exposure_reduces_clipping_and_increases_dim_frames(self):
        shorter = SpotLabApp._safe_auto_exposure(2_000.0, 255.0, .01, 8.0, 100_000.0)
        longer = SpotLabApp._safe_auto_exposure(2_000.0, 80.0, 0.0, 8.0, 100_000.0)
        self.assertLess(shorter, 2_000.0)
        self.assertGreater(longer, 2_000.0)
        self.assertEqual(SpotLabApp._safe_auto_exposure(100.0, 255.0, .01, 80.0, 120.0), 80.0)
        self.assertEqual(SpotLabApp._safe_auto_exposure(110.0, 20.0, 0.0, 8.0, 120.0), 120.0)

    def test_pause_button_toggles_freeze_and_resume_state(self):
        app = SpotLabApp.__new__(SpotLabApp)
        app._camera_state = "connected"
        app._camera_backend = SimpleNamespace(stop_grabbing=lambda: None, start_grabbing=lambda: None)
        app._camera_paused = threading.Event()
        app._camera_pending_frame = ("old",)
        app._camera_frame_queue = queue.Queue(maxsize=1)
        app._camera_frame_queue.put("queued")
        button_calls = []
        app.pause_button = SimpleNamespace(configure=lambda **kwargs: button_calls.append(kwargs))
        app.status_var = SimpleNamespace(set=lambda value: None)
        commands = []
        app._submit_camera_command = lambda label, operation: commands.append(label)
        app.toggle_camera_pause()
        self.assertTrue(app._camera_paused.is_set())
        self.assertIsNone(app._camera_pending_frame)
        self.assertTrue(app._camera_frame_queue.empty())
        self.assertEqual(commands[-1], "暂停实时采集")
        app.toggle_camera_pause()
        self.assertFalse(app._camera_paused.is_set())
        self.assertEqual(commands[-1], "恢复实时采集")

    def test_live_auto_exposure_writes_the_actual_feature(self):
        app = SpotLabApp.__new__(SpotLabApp)
        calls = []
        app._camera_control_state_lock = threading.Lock()
        app._camera_auto_exposure_enabled = True
        app._camera_auto_exposure_us = 2_000.0
        app._camera_auto_exposure_last_update = 0.0
        app._camera_exposure_min_us = 8.0
        app._camera_exposure_max_us = 100_000.0
        app._camera_backend = SimpleNamespace(
            set_float_feature=lambda name, value: calls.append((name, value)))
        app._camera_events = queue.Queue()
        frame = np.full((80, 80), 255, dtype=np.uint8)
        app._maybe_adjust_camera_exposure(frame, 2_000.0, now=1.0)
        self.assertEqual(calls[0][0], "ExposureTime")
        self.assertLess(calls[0][1], 2_000.0)
        self.assertGreater(calls[0][1], app._camera_exposure_min_us)

    def test_cursor_anchored_zoom_and_reversed_axis_bounds(self):
        zoomed = SpotLabApp._zoom_limits((0.0, 100.0), 30.0, .5)
        self.assertEqual(zoomed, (15.0, 65.0))
        zoomed_y = SpotLabApp._zoom_limits((100.0, 0.0), 95.0, .5, (0.0, 100.0))
        self.assertEqual(zoomed_y, (97.5, 47.5))
        full = SpotLabApp._zoom_limits((20.0, 80.0), 50.0, 2.0, (0.0, 100.0))
        self.assertEqual(full, (0.0, 100.0))

    def test_projected_profile_draws_without_a_cross_section_anchor(self):
        app = SpotLabApp.__new__(SpotLabApp)
        app.subtract_bg = SimpleNamespace(get=lambda: True)
        app.show_fit = SimpleNamespace(get=lambda: False)
        app.show_tophat = SimpleNamespace(get=lambda: False)
        fig = Figure()
        ax = fig.add_subplot(111)
        coords = np.arange(21, dtype=float)
        profile = np.exp(-0.5 * ((coords - 10) / 3) ** 2)
        app._draw_profile(ax, coords, profile, "X", float("nan"),
                          {"baseline": 0.0, "scale_um_per_px": 1.0})
        fig.canvas.draw()
        self.assertIn("X projection", ax.get_title(loc="left"))
        self.assertEqual(len(ax.lines), 2)  # profile and baseline; no NaN anchor line

    def test_reset_selection_disables_live_profile_follow_for_offline_sources(self):
        app = SpotLabApp.__new__(SpotLabApp)
        app.roi = (2, 3, 8, 9)
        app.profile_anchor = (4, 5)
        app.slice_mode = True
        app.slice_start = (1.0, 2.0)
        app.slice_profile = (np.arange(2), np.arange(2), (0.0, 0.0), (1.0, 1.0))
        app.roi_selecting = True
        follow = {"enabled": True}
        app.follow_beam_profiles = SimpleNamespace(set=lambda value: follow.__setitem__("enabled", value))
        app._reset_analysis_selection()
        self.assertFalse(follow["enabled"])
        self.assertIsNone(app.profile_anchor)
        self.assertIsNone(app.slice_profile)
        self.assertIsNone(app.roi)

    def test_live_follow_profiles_use_the_latest_centroid_coordinates(self):
        app = SpotLabApp.__new__(SpotLabApp)
        app.profile_anchor = None
        app.slice_profile = None
        app.follow_beam_profiles = SimpleNamespace(get=lambda: True)
        xcoords = np.arange(5, dtype=float)
        ycoords = np.arange(4, dtype=float)
        app.result = {"x_coords": xcoords, "x_profile": np.arange(5, dtype=float),
                      "y_coords": ycoords, "y_profile": np.arange(4, dtype=float),
                      "x_profile_y": 12.0, "y_profile_x": 23.0}
        first = app._display_profiles()
        self.assertEqual((first[4], first[5]), (12.0, 23.0))
        app.result["x_profile_y"] = 18.0
        app.result["y_profile_x"] = 29.0
        second = app._display_profiles()
        self.assertEqual((second[4], second[5]), (18.0, 29.0))
        self.assertIs(second[1], app.result["x_profile"])

    def test_cached_live_renderer_updates_image_and_follow_labels(self):
        height, width = 60, 80
        yy, xx = np.mgrid[:height, :width]
        before = (5 + 220 * np.exp(-.5 * (((xx - 35) / 12) ** 2 + ((yy - 30) / 10) ** 2))).astype(np.float32)
        after = (5 + 220 * np.exp(-.5 * (((xx - 40) / 12) ** 2 + ((yy - 32) / 10) ** 2))).astype(np.float32)
        options = AnalysisOptions(scale_um_per_px=1.0)
        app = SpotLabApp.__new__(SpotLabApp)
        app._camera_state = "connected"
        app.meta = {"mode": "MVS"}
        app.view_mode = SimpleNamespace(get=lambda: "2D + 剖面")
        app.image = before
        app.white_level = 255.0
        app.result = analyze_image(before, 255.0, options)
        palette = {"value": "gray"}
        app.palette = SimpleNamespace(get=lambda: palette["value"])
        app.auto_contrast = SimpleNamespace(get=lambda: False)
        app.vmin_var = SimpleNamespace(get=lambda: "0", set=lambda _v: None)
        app.vmax_var = SimpleNamespace(get=lambda: "255", set=lambda _v: None)
        app.roi = None
        app.profile_anchor = None
        app.follow_beam_profiles = SimpleNamespace(get=lambda: True)
        app.slice_profile = None
        app.slice_start = None
        app.show_reference = SimpleNamespace(get=lambda: False)
        app.reference_rgba = None
        app.subtract_bg = SimpleNamespace(get=lambda: True)
        app.show_fit = SimpleNamespace(get=lambda: False)
        app.show_tophat = SimpleNamespace(get=lambda: False)
        app.crosshair_pos = None
        app._crosshair_background = None
        fig = Figure(figsize=(6, 4))
        app.plot_canvas = FigureCanvasAgg(fig)
        app.ax2d = fig.add_axes([.05, .4, .9, .5])
        app.ax_x = fig.add_axes([.05, .1, .4, .2])
        app.ax_y = fig.add_axes([.55, .1, .4, .2])
        app.image_artist = app.ax2d.imshow(before, cmap="gray", vmin=0, vmax=255)
        app.beam_ellipse_artist = Ellipse((35, 30), 10, 10)
        app.ax2d.add_patch(app.beam_ellipse_artist)
        app.centroid_artist, = app.ax2d.plot([35], [30], "+")
        app.peak_artist, = app.ax2d.plot([35], [30], "x")
        app.colorbar = fig.colorbar(app.image_artist, ax=app.ax2d)
        app._live_display_stride = 1
        app._live_render_signature = app._live_render_key()
        app.image = after
        app.result = analyze_image(after, 255.0, options)
        palette["value"] = "plasma"
        self.assertTrue(app._render_live_update())
        self.assertEqual(app.image_artist.get_cmap().name, "plasma")
        self.assertTrue(np.array_equal(np.asarray(app.image_artist.get_array()), after))
        self.assertIn("X profile", app.ax_x.get_title(loc="left"))
        self.assertIn("32.0", app.ax_x.get_title(loc="left"))

    def test_scroll_zoom_targets_cursor_in_physical_coordinates(self):
        app = SpotLabApp.__new__(SpotLabApp)
        fig = Figure()
        app.ax2d = fig.add_axes([.1, .1, .5, .5])
        app.ax3d = fig.add_axes([.65, .1, .3, .5])
        app.ax_x = fig.add_axes([.1, .7, .3, .2])
        app.ax_y = fig.add_axes([.5, .7, .3, .2])
        app.ax2d.set_xlim(0, 2400); app.ax2d.set_ylim(1800, 0)
        app.image = np.zeros((750, 1000), dtype=np.uint8)
        app.result = {"scale_um_per_px": 2.4}
        app.plot_canvas = SimpleNamespace(draw_idle=lambda: None)
        app._on_plot_scroll(SimpleNamespace(inaxes=app.ax2d, step=1, button="up",
                                            xdata=1200.0, ydata=900.0))
        self.assertAlmostEqual(app.ax2d.get_xlim()[0], 216.0)
        self.assertAlmostEqual(app.ax2d.get_xlim()[1], 2184.0)
        self.assertAlmostEqual(app.ax2d.get_ylim()[0], 1638.0)
        self.assertAlmostEqual(app.ax2d.get_ylim()[1], 162.0)

    def test_csv_dimensions_are_converted_to_micrometers(self):
        app = SpotLabApp.__new__(SpotLabApp)
        app.result = {"scale_um_per_px": 2.4, "width": 100, "height": 80,
                      "centroid_x": 20, "centroid_y": 30, "peak_x": 21, "peak_y": 31,
                      "d4sigma_x": 4, "d4sigma_y": 6, "d4sigma_major": 6, "d4sigma_minor": 4,
                      "orientation_deg": 0, "ellipticity": 1.5, "fwhm_x": 3, "fwhm_y": 5,
                      "clip_percent": 13.5, "clip_width_x": 4.5, "clip_width_y": 6.5,
                      "encircled_energy_99_diameter": 10, "baseline": 0, "baseline_std": 1,
                      "peak": 10, "snr": 10, "saturated_fraction": 0, "quality": "良好", "fast_step": 1}
        app.crosshair_pos = (18, 28)
        app.reference_metrics = {"centroid_x": 19, "centroid_y": 29}
        app.reference_image = np.zeros((80, 100), dtype=np.uint8)
        app.image = np.zeros((80, 100), dtype=np.uint8)
        app.meta = {"name": "test"}; app.average_count = 1; app.slice_profile = None
        app._display_profiles = lambda: (np.array([0., 1.]), np.array([1., 2.]),
                                         np.array([0., 1.]), np.array([3., 4.]), 0., 0.)
        rows = app._csv_rows()
        by_name = {row[0]: row[1:] for row in rows if row and row[0] not in ("项目", "X profile coordinate", "Y profile coordinate")}
        self.assertAlmostEqual(by_name["宽度"][0], 240.0)
        self.assertEqual(by_name["宽度"][1], "µm")
        self.assertAlmostEqual(by_name["质心 - 十字线 ΔX"][0], 4.8)
        profile_rows = [row for row in rows if len(row) == 3 and row[2] == "µm" and isinstance(row[0], float)]
        self.assertEqual(profile_rows[:2], [[0.0, 1.0, "µm"], [2.4, 2.0, "µm"]])


if __name__ == "__main__":
    unittest.main()
