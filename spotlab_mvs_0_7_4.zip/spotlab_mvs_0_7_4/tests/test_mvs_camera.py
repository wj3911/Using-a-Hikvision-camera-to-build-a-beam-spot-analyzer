import ctypes
import os
import unittest
from types import SimpleNamespace

import numpy as np

from spotlab.mvs_camera import CameraFeatureRange, MVSBackend, MVSBackendError


class _FakeDeviceInfo(ctypes.Structure):
    _fields_ = [("nTLayerType", ctypes.c_uint)]


class _FakeDeviceList:
    def __init__(self):
        self.nDeviceNum = 0
        self.pDeviceInfo = []
        self._infos = []


class _FakeFloat:
    def __init__(self):
        self.fMin = 0.0
        self.fMax = 0.0
        self.fCurValue = 0.0


class _FakeEnum:
    def __init__(self):
        self.nCurValue = 0


class _FakeFrame:
    pass


class _FakeFrameInfo(ctypes.Structure):
    _fields_ = [
        ("nWidth", ctypes.c_uint),
        ("nHeight", ctypes.c_uint),
        ("enPixelType", ctypes.c_uint),
        ("nFrameLen", ctypes.c_uint),
        ("fExposureTime", ctypes.c_float),
        ("fGain", ctypes.c_float),
        ("nFrameNum", ctypes.c_uint),
    ]


class _FakeIntValue:
    def __init__(self):
        self.nCurValue = 0


class _FakeCamera:
    instances = []
    finalized = 0

    @staticmethod
    def MV_CC_Initialize():
        return 0

    @staticmethod
    def MV_CC_Finalize():
        _FakeCamera.finalized += 1
        return 0

    @staticmethod
    def MV_CC_EnumDevices(_mask, device_list):
        info = _FakeDeviceInfo(1)
        device_list.nDeviceNum = 1
        device_list.pDeviceInfo = [ctypes.pointer(info)]
        device_list._infos = [info]
        return 0

    def __init__(self):
        self.__class__.instances.append(self)
        self.enums = {"ExposureAuto": 2, "GainAuto": 0}
        self.floats = {
            "ExposureTime": (5.0, 500_000.0, 12_500.0),
            "Gain": (0.0, 18.0, 2.0),
        }
        self.set_enum_calls = []
        self.set_float_calls = []
        self.started = False
        self.closed = False
        self.destroyed = False
        self.freed = 0
        self.frame_bytes = bytes((1, 2, 3, 4, 5, 6))
        self.frame_buffer = ctypes.create_string_buffer(self.frame_bytes)

    def MV_CC_CreateHandle(self, _device_info):
        return 0

    def MV_CC_OpenDevice(self):
        return 0

    def MV_CC_SetEnumValueByString(self, name, value):
        self.set_enum_calls.append((name, value))
        self.enums[name] = {"Off": 0, "Continuous": 2, "Mono8": 17_301_505}.get(value, 2)
        return 0

    def MV_CC_SetEnumValue(self, name, value):
        self.set_enum_calls.append((name, int(value)))
        self.enums[name] = int(value)
        return 0

    def MV_CC_StartGrabbing(self):
        self.started = True
        return 0

    def MV_CC_GetFloatValue(self, name, structure):
        structure.fMin, structure.fMax, structure.fCurValue = self.floats[name]
        return 0

    def MV_CC_GetEnumValue(self, name, structure):
        structure.nCurValue = self.enums[name]
        return 0

    def MV_CC_SetFloatValue(self, name, value):
        self.floats[name] = (*self.floats[name][:2], float(value))
        self.set_float_calls.append((name, float(value)))
        return 0

    def MV_CC_GetImageBuffer(self, frame, _timeout_ms):
        frame.pBufAddr = self.frame_buffer
        frame.stFrameInfo = SimpleNamespace(nWidth=3, nHeight=2, nFrameLen=6,
                                            enPixelType=17_301_505, nFrameNum=42,
                                            fExposureTime=12_500.0, fGain=2.0)
        return 0

    def MV_CC_FreeImageBuffer(self, _frame):
        self.freed += 1
        return 0

    def MV_CC_StopGrabbing(self):
        self.started = False
        return 0

    def MV_CC_CloseDevice(self):
        self.closed = True
        return 0

    def MV_CC_DestroyHandle(self):
        self.destroyed = True
        return 0


class _FakeSDK:
    MvCamera = _FakeCamera
    MV_CC_DEVICE_INFO_LIST = _FakeDeviceList
    MV_CC_DEVICE_INFO = _FakeDeviceInfo
    MVCC_FLOATVALUE = _FakeFloat
    MVCC_ENUMVALUE = _FakeEnum
    MV_FRAME_OUT = _FakeFrame
    MV_GIGE_DEVICE = 1
    MV_USB_DEVICE = 4
    PixelType_Gvsp_Mono8 = 17_301_505
    MV_E_NODATA = 0x80000007
    MV_E_GC_TIMEOUT = 0x80000107


class _LegacyCamera:
    """Older MVS Python wrappers omit explicit SDK initialize/finalize methods."""

    @staticmethod
    def MV_CC_EnumDevices(_mask, device_list):
        device_list.nDeviceNum = 0
        device_list.pDeviceInfo = []
        return 0


class _LegacyStreamingCamera(_FakeCamera):
    def MV_CC_GetIntValue(self, name, structure):
        structure.nCurValue = {"PayloadSize": 6, "Width": 3, "Height": 2}[name]
        return 0

    def MV_CC_GetOneFrameTimeout(self, buffer, size, info, _timeout_ms):
        if size < len(self.frame_bytes):
            return 0x8000000A
        ctypes.memmove(buffer, self.frame_bytes, len(self.frame_bytes))
        info.nWidth = 3
        info.nHeight = 2
        info.enPixelType = 17_301_505
        info.nFrameLen = 6
        info.fExposureTime = 12_500.0
        info.fGain = 2.0
        info.nFrameNum = 43
        return 0


class _LegacyFrameSDK:
    # Deliberately no MV_FRAME_OUT: this simulates the user's older MvImport tree.
    MvCamera = _LegacyStreamingCamera
    MV_CC_DEVICE_INFO_LIST = _FakeDeviceList
    MV_CC_DEVICE_INFO = _FakeDeviceInfo
    MVCC_FLOATVALUE = _FakeFloat
    MVCC_ENUMVALUE = _FakeEnum
    MVCC_INTVALUE = _FakeIntValue
    MV_FRAME_OUT_INFO_EX = _FakeFrameInfo
    MV_GIGE_DEVICE = 1
    MV_USB_DEVICE = 4
    PixelType_Gvsp_Mono8 = 17_301_505
    MV_E_NODATA = 0x80000007
    MV_E_GC_TIMEOUT = 0x80000107


class MVSBackendTests(unittest.TestCase):
    def setUp(self):
        _FakeCamera.instances.clear()
        _FakeCamera.finalized = 0

    def test_mono8_buffer_is_copied_as_two_dimensional_image(self):
        frame = MVSBackend.mono8_from_buffer(bytes((1, 2, 3, 4, 5, 6)), 3, 2)
        self.assertEqual(frame.shape, (2, 3))
        self.assertEqual(frame.dtype, np.uint8)
        self.assertTrue(np.array_equal(frame, np.array([[1, 2, 3], [4, 5, 6]], dtype=np.uint8)))
        frame[0, 0] = 0  # returned data is a writable copy
        self.assertEqual(int(frame[0, 0]), 0)

    def test_short_frame_buffer_is_rejected(self):
        with self.assertRaisesRegex(Exception, "缓存长度不足"):
            MVSBackend.mono8_from_buffer(bytes((1, 2)), 3, 2)

    def test_enumerate_connect_read_controls_stream_and_close(self):
        backend = MVSBackend(sdk_module=_FakeSDK)
        devices = backend.enumerate_devices()
        self.assertEqual(len(devices), 1)
        self.assertEqual(devices[0].transport, "GigE")

        profile = backend.open_device(0)
        self.assertEqual(profile["exposure"], CameraFeatureRange(5.0, 500_000.0, 12_500.0))
        self.assertEqual(profile["gain"], CameraFeatureRange(0.0, 18.0, 2.0))
        self.assertTrue(profile["exposure_auto"])
        self.assertFalse(profile["gain_auto"])

        frame, number, exposure, gain = backend.get_frame()
        self.assertEqual(number, 42)
        self.assertEqual(exposure, 12_500.0)
        self.assertEqual(gain, 2.0)
        self.assertTrue(np.array_equal(frame, np.array([[1, 2, 3], [4, 5, 6]], dtype=np.uint8)))
        camera = _FakeCamera.instances[-1]
        self.assertEqual(camera.freed, 1)
        self.assertIn(("TriggerMode", "Off"), camera.set_enum_calls)
        self.assertIn(("PixelFormat", "Mono8"), camera.set_enum_calls)

        backend.stop_grabbing()
        self.assertFalse(camera.started)
        self.assertIsNone(backend.get_frame())
        backend.start_grabbing()
        self.assertTrue(camera.started)
        self.assertIsNotNone(backend.get_frame())

        backend.set_auto("ExposureAuto", False)
        backend.set_float_feature("ExposureTime", 1_250.0)
        self.assertEqual(camera.enums["ExposureAuto"], 0)
        self.assertEqual(camera.set_float_calls[-1], ("ExposureTime", 1_250.0))

        backend.close()
        self.assertTrue(camera.closed)
        self.assertTrue(camera.destroyed)
        self.assertEqual(_FakeCamera.finalized, 1)
        self.assertIsNone(backend.get_frame())

    def test_legacy_mvs_binding_without_explicit_init_and_finalize_is_supported(self):
        legacy_sdk = SimpleNamespace(
            MvCamera=_LegacyCamera,
            MV_CC_DEVICE_INFO_LIST=_FakeDeviceList,
            MV_GIGE_DEVICE=1,
            MV_USB_DEVICE=4,
        )
        backend = MVSBackend(sdk_module=legacy_sdk)
        self.assertEqual(backend.enumerate_devices(), [])
        backend.close()

    def test_legacy_binding_without_mv_frame_out_uses_one_frame_timeout(self):
        backend = MVSBackend(sdk_module=_LegacyFrameSDK)
        devices = backend.enumerate_devices()
        self.assertEqual(len(devices), 1)
        backend.open_device(0)
        frame, number, exposure, gain = backend.get_frame(timeout_ms=100)
        self.assertTrue(np.array_equal(frame, np.array([[1, 2, 3], [4, 5, 6]], dtype=np.uint8)))
        self.assertEqual(number, 43)
        self.assertAlmostEqual(exposure, 12_500.0)
        self.assertAlmostEqual(gain, 2.0)
        backend.close()

    @unittest.skipIf(os.name == "nt", "Windows uses the installed MVS binding instead")
    def test_missing_windows_sdk_is_reported_only_when_backend_is_created(self):
        with self.assertRaisesRegex(MVSBackendError, "离线图像分析仍可在此处使用"):
            MVSBackend()

    def test_empty_or_invalid_dimensions_are_rejected(self):
        with self.assertRaisesRegex(Exception, "无效帧尺寸"):
            MVSBackend.mono8_from_buffer(b"", 0, 2)


if __name__ == "__main__":
    unittest.main()
