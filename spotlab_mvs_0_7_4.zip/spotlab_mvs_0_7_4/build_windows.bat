@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher (py) not found.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :failed
".venv\Scripts\pyinstaller.exe" --noconfirm --clean --windowed --onedir --name SpotLab --collect-all matplotlib --hidden-import matplotlib.backends.backend_tkagg --hidden-import mpl_toolkits.mplot3d main.py
if errorlevel 1 goto :failed
echo.
echo Build complete: dist\SpotLab\SpotLab.exe
pause
exit /b 0
:failed
echo.
echo Build failed. See the error above.
pause
exit /b 1
