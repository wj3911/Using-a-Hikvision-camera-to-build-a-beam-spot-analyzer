"""Optional Hikrobot MVS camera adapter.

The vendor SDK and Python bindings are deliberately not bundled with SpotLab.
They are loaded lazily only when the user asks to connect a camera, so the
offline/file-analysis workflow remains independent of MVS.
"""
from __future__ import annotations

import ctypes
import importlib
import math
import os
from dataclasses import dataclass
from pathlib import Path
import sys
import threading
from typing import Any

import numpy as np


class MVSBackendError(RuntimeError):
    """An SDK, device, stream, or feature operation failed."""


@dataclass(frozen=True)
class CameraDevice:
    index: int
    model: str
    serial: str
    user_name: str
    transport: str
    ip_address: str = ""

    @property
    def label(self) -> str:
        name = self.user_name or self.model or "Hikrobot camera"
        bits = [name]
        if self.serial:
            bits.append(f"S/N {self.serial}")
        if self.transport:
            bits.append(self.transport)
        if self.ip_address:
            bits.append(self.ip_address)
        return " · ".join(bits)


@dataclass(frozen=True)
class CameraFeatureRange:
    minimum: float
    maximum: float
    current: float


# Keep Windows DLL directory handles alive for as long as ctypes modules use them.
_DLL_DIRECTORY_HANDLES: list[Any] = []


def _decode_sdk_text(value: Any) -> str:
    """Decode an MVS fixed-size C character/byte array without leaking NULs."""
    if value is None:
        return ""
    try:
        raw = bytes(value)
    except (TypeError, ValueError):
        raw = str(value).encode("utf-8", errors="replace")
    raw = raw.split(b"\0", 1)[0].strip()
    if not raw:
        return ""
    for encoding in ("utf-8", "gbk", "mbcs"):
        try:
            return raw.decode(encoding).strip()
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("latin-1", errors="replace").strip()


def _program_files_roots() -> list[Path]:
    roots: list[Path] = []
    for name in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
        value = os.environ.get(name)
        if value:
            path = Path(value)
            if path not in roots:
                roots.append(path)
    return roots


def _mvs_python_candidates() -> list[Path]:
    candidates: list[Path] = []
    override = os.environ.get("SPOTLAB_MVS_PYTHON_PATH", "").strip().strip('"')
    if override:
        path = Path(override).expanduser()
        # Accept either the MvImport folder itself or its parent Python folder.
        for candidate in (path, path / "MvImport"):
            if candidate not in candidates:
                candidates.append(candidate)

    for root in _program_files_roots():
        base = root / "MVS" / "Development" / "Samples" / "Python"
        for candidate in (base / "MvImport", base / "Win64" / "MvImport", base):
            if candidate not in candidates:
                candidates.append(candidate)
    return candidates


def _mvs_dll_candidates() -> list[Path]:
    candidates: list[Path] = []
    runtime = os.environ.get("MVCAM_COMMON_RUNENV", "").strip().strip('"')
    if runtime:
        candidates.append(Path(runtime).expanduser())

    for root in _program_files_roots():
        mvs = root / "MVS"
        common = root / "Common Files" / "MVS" / "Runtime"
        candidates.extend((
            mvs / "Development" / "Win64" / "DLL",
            mvs / "Development" / "Win64",
            mvs / "Runtime" / "Win64_x64",
            mvs / "Runtime" / "Win64",
            common / "Win64_x64",
            common / "Win64",
        ))
    # Keep order while removing duplicates.
    return list(dict.fromkeys(candidates))


def _load_mvs_module() -> Any:
    if os.name != "nt":
        raise MVSBackendError(
            "SpotLab 的 MVS 相机连接目前按 Windows SDK 目录结构配置。"
            "请在安装了 Hikrobot MVS 的 Windows 电脑上运行；离线图像分析仍可在此处使用。"
        )

    python_paths = [path for path in _mvs_python_candidates()
                    if path.is_dir() and (path / "MvCameraControl_class.py").is_file()]
    for path in reversed(python_paths):
        text = str(path)
        if text not in sys.path:
            sys.path.insert(0, text)

    for path in _mvs_dll_candidates():
        if not path.is_dir():
            continue
        add_dll_directory = getattr(os, "add_dll_directory", None)
        if add_dll_directory is not None:
            try:
                _DLL_DIRECTORY_HANDLES.append(add_dll_directory(str(path)))
            except (OSError, FileNotFoundError):
                pass

    try:
        return importlib.import_module("MvCameraControl_class")
    except Exception as exc:
        searched = [str(path) for path in _mvs_python_candidates()]
        raise MVSBackendError(
            "未能加载 Hikrobot MVS Python 绑定或运行库。请先安装与相机匹配的官方 MVS，"
            "并确认 Python 与 MVS 的位数一致。若 SDK 样例目录不在默认位置，可设置环境变量 "
            "SPOTLAB_MVS_PYTHON_PATH 指向包含 MvCameraControl_class.py 的 MvImport 文件夹。"
            f"\nPython 绑定候选目录：{'; '.join(searched)}\n详细错误：{exc}"
        ) from exc


class MVSBackend:
    """Small, thread-safe adapter for a Hikrobot camera using the MVS Python API."""

    def __init__(self, sdk_module: Any | None = None):
        # Import only on explicit camera discovery; app startup stays SDK-independent.
        self.sdk = sdk_module if sdk_module is not None else _load_mvs_module()
        self.camera_class = self.sdk.MvCamera
        self._api_lock = threading.RLock()
        self._device_list: Any | None = None  # owns the SDK-allocated device pointers
        self._camera: Any | None = None
        self._initialized = False
        self._sdk_initialized_by_call = False
        self._handle_created = False
        self._opened = False
        self._grabbing = False
        self._use_one_frame_timeout = False
        self._legacy_frame_buffer: Any | None = None
        self._legacy_frame_buffer_size = 0
        # Newer MVS bindings expose explicit SDK init/finalize functions; older
        # Python samples (including legacy releases) load/initialize through the DLL
        # and omit them. Treat those functions as optional for compatibility.
        initialize = getattr(self.camera_class, "MV_CC_Initialize", None)
        if callable(initialize):
            ret = initialize()
            self._check_ret("MVS SDK 初始化", ret)
            self._sdk_initialized_by_call = True
        self._initialized = True

    @classmethod
    def discover(cls) -> tuple["MVSBackend", list[CameraDevice]]:
        backend = cls()
        try:
            devices = backend.enumerate_devices()
            return backend, devices
        except Exception:
            backend.close()
            raise

    @staticmethod
    def mono8_from_buffer(data: bytes | bytearray | memoryview, width: int, height: int) -> np.ndarray:
        width, height = int(width), int(height)
        if width <= 0 or height <= 0:
            raise MVSBackendError(f"相机返回了无效帧尺寸：{width} × {height}")
        count = width * height
        pixels = np.frombuffer(data, dtype=np.uint8)
        if pixels.size < count:
            raise MVSBackendError(
                f"Mono8 帧缓存长度不足：收到 {pixels.size}，但 {width} × {height} 需要 {count}。"
            )
        return pixels[:count].reshape(height, width).copy()

    @staticmethod
    def _optional_finite_float(value: Any) -> float | None:
        try:
            result = float(value)
        except (TypeError, ValueError):
            return None
        return result if math.isfinite(result) else None

    @staticmethod
    def _check_ret(operation: str, ret: Any) -> None:
        try:
            code = int(ret) & 0xFFFFFFFF
        except (TypeError, ValueError):
            code = -1
        if code != 0:
            raise MVSBackendError(f"{operation}失败（MVS 错误码 0x{code:08X}）。")

    @staticmethod
    def _feature_node_name(kind: str) -> str:
        return {"exposure": "ExposureTime", "gain": "Gain"}[kind]

    def enumerate_devices(self) -> list[CameraDevice]:
        with self._api_lock:
            if not self._initialized:
                raise MVSBackendError("MVS SDK 尚未初始化或已关闭。")
            device_list = self.sdk.MV_CC_DEVICE_INFO_LIST()
            transport_mask = int(getattr(self.sdk, "MV_GIGE_DEVICE", 0x1)) | int(
                getattr(self.sdk, "MV_USB_DEVICE", 0x4)
            )
            ret = self.camera_class.MV_CC_EnumDevices(transport_mask, device_list)
            self._check_ret("枚举 GigE/USB 相机", ret)
            self._device_list = device_list
            devices: list[CameraDevice] = []
            count = int(device_list.nDeviceNum)
            for index in range(count):
                try:
                    pointer = device_list.pDeviceInfo[index]
                    info = ctypes.cast(pointer, ctypes.POINTER(self.sdk.MV_CC_DEVICE_INFO)).contents
                    devices.append(self._describe_device(index, info))
                except Exception as exc:
                    # Keep enumeration useful even if one optional metadata field differs by SDK version.
                    devices.append(CameraDevice(index, "Hikrobot camera", "", "", "MVS", ""))
            return devices

    def _describe_device(self, index: int, info: Any) -> CameraDevice:
        layer = int(getattr(info, "nTLayerType", 0))
        gige_flag = int(getattr(self.sdk, "MV_GIGE_DEVICE", 0x1))
        usb_flag = int(getattr(self.sdk, "MV_USB_DEVICE", 0x4))
        if layer & gige_flag:
            transport, detail = "GigE", getattr(getattr(info, "SpecialInfo", None), "stGigEInfo", None)
        elif layer & usb_flag:
            transport, detail = "USB3", getattr(getattr(info, "SpecialInfo", None), "stUsb3VInfo", None)
        else:
            transport, detail = "MVS", None
        model = _decode_sdk_text(getattr(detail, "chModelName", b""))
        serial = _decode_sdk_text(getattr(detail, "chSerialNumber", b""))
        user_name = _decode_sdk_text(getattr(detail, "chUserDefinedName", b""))
        ip_address = ""
        if transport == "GigE" and detail is not None:
            try:
                ip = int(detail.nCurrentIp) & 0xFFFFFFFF
                ip_address = ".".join(str((ip >> shift) & 0xFF) for shift in (24, 16, 8, 0))
            except (AttributeError, TypeError, ValueError):
                pass
        return CameraDevice(index=index, model=model or "Hikrobot camera", serial=serial,
                            user_name=user_name, transport=transport, ip_address=ip_address)

    def open_device(self, index: int) -> dict[str, Any]:
        """Open a selected device, configure continuous Mono8 acquisition, and start streaming."""
        with self._api_lock:
            if not self._initialized:
                raise MVSBackendError("MVS SDK 尚未初始化或已关闭。")
            if self._device_list is None:
                raise MVSBackendError("请先枚举相机设备。")
            if self._camera is not None:
                raise MVSBackendError("当前已有相机句柄，请先断开设备。")
            count = int(self._device_list.nDeviceNum)
            if index < 0 or index >= count:
                raise MVSBackendError("所选相机已不在设备列表中，请重新搜索。")

            camera = self.camera_class()
            self._camera = camera
            try:
                pointer = self._device_list.pDeviceInfo[index]
                device_info = ctypes.cast(pointer, ctypes.POINTER(self.sdk.MV_CC_DEVICE_INFO)).contents
                ret = camera.MV_CC_CreateHandle(device_info)
                self._check_ret("创建相机句柄", ret)
                self._handle_created = True
                ret = camera.MV_CC_OpenDevice()
                self._check_ret("打开相机", ret)
                self._opened = True

                # The first integration targets a mono beam-profile camera. Free-run and
                # Mono8 keep the image path deterministic and avoid color demosaicing.
                self._set_enum("TriggerMode", "Off", fallback_value=0, required=True)
                self._set_enum("AcquisitionMode", "Continuous", fallback_value=2, required=False)
                mono8 = int(getattr(self.sdk, "PixelType_Gvsp_Mono8", 17301505))
                self._set_enum("PixelFormat", "Mono8", fallback_value=mono8, required=True)
                self._use_one_frame_timeout = (
                    not hasattr(self.sdk, "MV_FRAME_OUT")
                    or not callable(getattr(camera, "MV_CC_GetImageBuffer", None))
                )
                if self._use_one_frame_timeout:
                    self._prepare_one_frame_timeout_buffer()
                self._start_grabbing()
                return self.read_control_profile()
            except Exception:
                self._cleanup_camera_locked()
                raise

    def _set_enum(self, name: str, symbol: str, fallback_value: int | None,
                  required: bool) -> None:
        if self._camera is None:
            raise MVSBackendError("相机尚未打开。")
        last_ret: Any = None
        set_by_string = getattr(self._camera, "MV_CC_SetEnumValueByString", None)
        if callable(set_by_string):
            try:
                last_ret = set_by_string(name, symbol)
                if int(last_ret) == 0:
                    return
            except Exception as exc:
                last_ret = exc
        set_by_number = getattr(self._camera, "MV_CC_SetEnumValue", None)
        if fallback_value is not None and callable(set_by_number):
            try:
                last_ret = set_by_number(name, int(fallback_value))
                if int(last_ret) == 0:
                    return
            except Exception as exc:
                last_ret = exc
        if not required:
            return
        if name == "PixelFormat" and fallback_value is not None:
            try:
                current = self.get_enum_value(name)
                if current == int(fallback_value):
                    return
            except Exception:
                pass
        detail = f"；SDK 返回 {last_ret}" if last_ret is not None else ""
        raise MVSBackendError(
            f"无法设置相机节点 {name}={symbol}{detail}。请在 MVS 中确认该节点可写。"
        )

    def _read_integer_node(self, name: str) -> int | None:
        if self._camera is None:
            return None
        candidates = (
            ("MV_CC_GetIntValueEx", "MVCC_INTVALUE_EX"),
            ("MV_CC_GetIntValue", "MVCC_INTVALUE"),
        )
        for method_name, structure_name in candidates:
            method = getattr(self._camera, method_name, None)
            structure_type = getattr(self.sdk, structure_name, None)
            if not callable(method) or structure_type is None:
                continue
            try:
                structure = structure_type()
                ret = method(name, structure)
                if int(ret) == 0:
                    value = int(structure.nCurValue)
                    if value > 0:
                        return value
            except Exception:
                continue
        return None

    def _prepare_one_frame_timeout_buffer(self) -> None:
        if self._camera is None:
            raise MVSBackendError("相机尚未打开。")
        getter = getattr(self._camera, "MV_CC_GetOneFrameTimeout", None)
        frame_info_type = getattr(self.sdk, "MV_FRAME_OUT_INFO_EX", None)
        if not callable(getter) or frame_info_type is None:
            raise MVSBackendError(
                "此旧版 MVS 绑定没有 MV_FRAME_OUT；同时也没有可用的 "
                "MV_CC_GetOneFrameTimeout / MV_FRAME_OUT_INFO_EX 接口。请安装与相机匹配的完整 MVS SDK。"
            )
        payload_size = self._read_integer_node("PayloadSize")
        if payload_size is None:
            width = self._read_integer_node("Width")
            height = self._read_integer_node("Height")
            if width and height:
                payload_size = width * height  # PixelFormat was set to Mono8 above.
        if payload_size is None:
            # Last-resort capacity for the 6 MP mono target; still guarded against
            # an implausibly large SDK value if a node read succeeded.
            payload_size = 64 * 1024 * 1024
        if payload_size <= 0 or payload_size > 512 * 1024 * 1024:
            raise MVSBackendError(f"旧版取帧缓存大小无效：{payload_size} bytes。")
        self._legacy_frame_buffer_size = int(payload_size)
        self._legacy_frame_buffer = (ctypes.c_ubyte * self._legacy_frame_buffer_size)()

    def _start_grabbing(self) -> None:
        if self._camera is None:
            raise MVSBackendError("相机尚未打开。")
        ret = self._camera.MV_CC_StartGrabbing()
        self._check_ret("启动图像采集", ret)
        self._grabbing = True

    def stop_grabbing(self) -> None:
        """Pause device acquisition without closing the camera handle."""
        with self._api_lock:
            if self._camera is None or not self._opened:
                raise MVSBackendError("相机尚未打开。")
            if not self._grabbing:
                return
            ret = self._camera.MV_CC_StopGrabbing()
            self._check_ret("暂停图像采集", ret)
            self._grabbing = False

    def start_grabbing(self) -> None:
        """Resume acquisition after stop_grabbing()."""
        with self._api_lock:
            if self._camera is None or not self._opened:
                raise MVSBackendError("相机尚未打开。")
            if self._grabbing:
                return
            self._start_grabbing()

    def _frame_to_tuple(self, info: Any, buffer: Any,
                        buffer_size: int | None = None) -> tuple[np.ndarray, int, float | None, float | None]:
        width = int(info.nWidth)
        height = int(info.nHeight)
        pixel_type = int(info.enPixelType)
        mono8 = int(getattr(self.sdk, "PixelType_Gvsp_Mono8", 17301505))
        if pixel_type != mono8:
            raise MVSBackendError(
                f"收到的像素格式不是 Mono8（0x{pixel_type:08X}）。"
                "请将 MVS 相机 PixelFormat 设为 Mono8 后重连。"
            )
        length = int(getattr(info, "nFrameLen", 0))
        if length <= 0:
            length = width * height
        if buffer_size is not None and length > int(buffer_size):
            raise MVSBackendError(
                f"相机帧长 {length} 超过取帧缓存 {buffer_size}；请检查相机分辨率或 PayloadSize。"
            )
        if buffer is None:
            raise MVSBackendError("MVS 返回了空图像缓存。")
        raw = ctypes.string_at(buffer, length)
        image = self.mono8_from_buffer(raw, width, height)
        exposure = self._optional_finite_float(getattr(info, "fExposureTime", None))
        gain = self._optional_finite_float(getattr(info, "fGain", None))
        if exposure is not None and exposure <= 0:
            exposure = None
        return image, int(getattr(info, "nFrameNum", 0)), exposure, gain

    def _get_one_frame_timeout_locked(self, timeout_ms: int) -> tuple[np.ndarray, int, float | None, float | None] | None:
        if self._camera is None or self._legacy_frame_buffer is None:
            raise MVSBackendError("旧版 MVS 取帧缓存尚未准备好。")
        info = self.sdk.MV_FRAME_OUT_INFO_EX()
        try:
            ctypes.memset(ctypes.byref(info), 0, ctypes.sizeof(info))
        except (TypeError, ctypes.ArgumentError):
            pass
        ret = self._camera.MV_CC_GetOneFrameTimeout(
            self._legacy_frame_buffer, self._legacy_frame_buffer_size, info, int(timeout_ms))
        code = int(ret) & 0xFFFFFFFF
        no_data_codes = {
            int(getattr(self.sdk, "MV_E_NODATA", 0x80000007)) & 0xFFFFFFFF,
            int(getattr(self.sdk, "MV_E_GC_TIMEOUT", 0x80000107)) & 0xFFFFFFFF,
        }
        if code in no_data_codes:
            return None
        self._check_ret("读取相机图像（旧版 MVS API）", ret)
        return self._frame_to_tuple(info, self._legacy_frame_buffer, self._legacy_frame_buffer_size)

    def get_frame(self, timeout_ms: int = 120) -> tuple[np.ndarray, int, float | None, float | None] | None:
        """Return Mono8 image, frame counter, frame exposure, and frame gain."""
        with self._api_lock:
            if self._camera is None or not self._grabbing:
                return None
            if self._use_one_frame_timeout:
                return self._get_one_frame_timeout_locked(timeout_ms)
            frame_type = getattr(self.sdk, "MV_FRAME_OUT", None)
            if frame_type is None:
                raise MVSBackendError("当前 MVS Python 绑定不包含 MV_FRAME_OUT，无法取帧。")
            frame = frame_type()
            try:
                ctypes.memset(ctypes.byref(frame), 0, ctypes.sizeof(frame))
            except (TypeError, ctypes.ArgumentError):
                pass
            ret = self._camera.MV_CC_GetImageBuffer(frame, int(timeout_ms))
            code = int(ret) & 0xFFFFFFFF
            if code != 0:
                no_data_codes = {
                    int(getattr(self.sdk, "MV_E_NODATA", 0x80000007)) & 0xFFFFFFFF,
                    int(getattr(self.sdk, "MV_E_GC_TIMEOUT", 0x80000107)) & 0xFFFFFFFF,
                }
                if code in no_data_codes:
                    return None
                self._check_ret("读取相机图像", ret)
            try:
                info = frame.stFrameInfo
                length = int(getattr(info, "nFrameLen", 0)) or int(info.nWidth) * int(info.nHeight)
                return self._frame_to_tuple(info, frame.pBufAddr, length)
            finally:
                try:
                    self._camera.MV_CC_FreeImageBuffer(frame)
                except Exception:
                    pass

    def get_float_feature(self, name: str) -> CameraFeatureRange:
        with self._api_lock:
            if self._camera is None or not self._opened:
                raise MVSBackendError("相机尚未打开。")
            structure = self.sdk.MVCC_FLOATVALUE()
            ret = self._camera.MV_CC_GetFloatValue(name, structure)
            self._check_ret(f"读取相机参数 {name}", ret)
            minimum = float(structure.fMin)
            maximum = float(structure.fMax)
            current = float(structure.fCurValue)
            if not all(math.isfinite(value) for value in (minimum, maximum, current)) or maximum <= minimum:
                raise MVSBackendError(f"相机节点 {name} 返回了无效范围。")
            return CameraFeatureRange(minimum, maximum, current)

    def get_enum_value(self, name: str) -> int:
        with self._api_lock:
            if self._camera is None or not self._opened:
                raise MVSBackendError("相机尚未打开。")
            structure = self.sdk.MVCC_ENUMVALUE()
            ret = self._camera.MV_CC_GetEnumValue(name, structure)
            self._check_ret(f"读取相机模式 {name}", ret)
            return int(structure.nCurValue)

    def get_auto_state(self, name: str) -> bool:
        # GenICam ExposureAuto/GainAuto values: Off=0, Once=1, Continuous=2.
        return self.get_enum_value(name) == 2

    def read_control_profile(self) -> dict[str, Any]:
        profile: dict[str, Any] = {}
        for kind, node in (("exposure", "ExposureTime"), ("gain", "Gain")):
            try:
                profile[kind] = self.get_float_feature(node)
            except Exception as exc:
                profile[kind] = None
                profile[f"{kind}_error"] = str(exc)
        for kind, node in (("exposure", "ExposureAuto"), ("gain", "GainAuto")):
            try:
                profile[f"{kind}_auto"] = self.get_auto_state(node)
            except Exception as exc:
                profile[f"{kind}_auto"] = None
                profile[f"{kind}_auto_error"] = str(exc)
        return profile

    def set_float_feature(self, name: str, value: float) -> None:
        with self._api_lock:
            if self._camera is None or not self._opened:
                raise MVSBackendError("相机尚未打开。")
            ret = self._camera.MV_CC_SetFloatValue(name, float(value))
            self._check_ret(f"设置相机参数 {name}", ret)

    def set_auto(self, name: str, enabled: bool) -> None:
        with self._api_lock:
            if self._camera is None or not self._opened:
                raise MVSBackendError("相机尚未打开。")
            symbol = "Continuous" if enabled else "Off"
            fallback = 2 if enabled else 0
            last_ret: Any = None
            setter = getattr(self._camera, "MV_CC_SetEnumValueByString", None)
            if callable(setter):
                try:
                    last_ret = setter(name, symbol)
                    if int(last_ret) == 0:
                        return
                except Exception as exc:
                    last_ret = exc
            setter = getattr(self._camera, "MV_CC_SetEnumValue", None)
            if callable(setter):
                try:
                    last_ret = setter(name, fallback)
                    if int(last_ret) == 0:
                        return
                except Exception as exc:
                    last_ret = exc
            detail = f"；SDK 返回 {last_ret}" if last_ret is not None else ""
            raise MVSBackendError(f"设置相机自动模式 {name}={symbol} 失败{detail}。")

    def _cleanup_camera_locked(self) -> None:
        camera = self._camera
        if camera is None:
            return
        if self._grabbing:
            try:
                camera.MV_CC_StopGrabbing()
            except Exception:
                pass
            self._grabbing = False
        if self._opened:
            try:
                camera.MV_CC_CloseDevice()
            except Exception:
                pass
            self._opened = False
        if self._handle_created:
            try:
                camera.MV_CC_DestroyHandle()
            except Exception:
                pass
            self._handle_created = False
        self._camera = None
        self._legacy_frame_buffer = None
        self._legacy_frame_buffer_size = 0
        self._use_one_frame_timeout = False

    def close(self) -> None:
        with self._api_lock:
            self._cleanup_camera_locked()
            self._device_list = None
            if self._initialized:
                finalize = getattr(self.camera_class, "MV_CC_Finalize", None)
                if self._sdk_initialized_by_call and callable(finalize):
                    try:
                        finalize()
                    except Exception:
                        pass
                self._initialized = False
                self._sdk_initialized_by_call = False
