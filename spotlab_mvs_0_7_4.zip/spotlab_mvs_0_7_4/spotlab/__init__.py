"""SpotLab beam-profile analysis with optional Hikrobot MVS camera support."""
__version__ = "0.7.4"
