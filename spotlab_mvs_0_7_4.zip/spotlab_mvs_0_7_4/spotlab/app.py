"""SpotLab desktop beam profiler with optional Hikrobot MVS camera acquisition.

Run with: python -m spotlab.app
"""
from __future__ import annotations

import base64
import csv
import html
import io
import json
import math
import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Any

import numpy as np
from PIL import Image
from matplotlib import font_manager, rcParams
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.patches import Ellipse, Rectangle
from matplotlib.widgets import RectangleSelector

from .core import (AnalysisOptions, _fit_gaussian, _top_hat_fit,
                   analyze_image, average_frames, center_offset, load_grayscale,
                   make_demo_beam, make_reference_overlay)
from .mvs_camera import CameraDevice, CameraFeatureRange, MVSBackend

# Prefer common Windows Traditional/Simplified Chinese fonts; plot titles use English
# fallbacks as well, so glyph coverage does not depend on the host locale.
for _font_name in ("Microsoft JhengHei", "Microsoft JhengHei UI", "Microsoft YaHei", "Microsoft YaHei UI",
                   "Noto Sans CJK TC", "Noto Sans CJK SC", "SimHei", "Arial Unicode MS"):
    try:
        font_manager.findfont(_font_name, fallback_to_default=False)
        rcParams["font.sans-serif"] = [_font_name, "DejaVu Sans"]
        break
    except Exception:
        continue
rcParams["axes.unicode_minus"] = False

APP_TITLE = "SpotLab · 光束分析仪（MVS 相机接入）"
DEFAULT_SENSOR_SCALE_UM_PER_PX = 2.4
CAM_EXPOSURE_MIN_US = 8.0
CAM_EXPOSURE_MAX_US = 1_000_000.0
CAM_GAIN_MIN_DB = 0.0
CAM_GAIN_MAX_DB = 24.0
CAMERA_PREVIEW_FPS = 6.0
AUTO_EXPOSURE_TARGET_ADU = 185.0


def _fmt(value: Any, digits: int = 2) -> str:
    try:
        v = float(value)
        return f"{v:.{digits}f}" if math.isfinite(v) else "—"
    except (TypeError, ValueError):
        return "—"


class SpotLabApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        screen_w = self.root.winfo_screenwidth(); screen_h = self.root.winfo_screenheight()
        window_w = min(1600, max(1120, screen_w - 40))
        window_h = min(960, max(680, screen_h - 90))
        self.root.geometry(f"{window_w}x{window_h}")
        self.root.minsize(min(1280, window_w), min(760, window_h))
        self.root.configure(bg="#edf2f6")
        self.style = ttk.Style(root)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self._configure_style()

        self.image, self.white_level, self.meta = make_demo_beam()
        self.roi: tuple[int, int, int, int] | None = None
        self.result: dict[str, Any] | None = None
        self._result_generation = 0
        self.crosshair_pos: tuple[float, float] | None = None
        self._dragging_crosshair = False
        self._crosshair_background = None
        self.crosshair_h_artist = None; self.crosshair_v_artist = None; self.crosshair_marker_artist = None
        self.reference_image: np.ndarray | None = None
        self.reference_rgba: np.ndarray | None = None
        self.reference_metrics: dict[str, Any] | None = None
        self.reference_meta: dict[str, Any] | None = None
        self.reference_white_level = 255.0
        self.reference_artist = None; self.reference_center_artist = None
        self.records: list[dict[str, Any]] = []
        self.average_count = 1
        self.profile_anchor: tuple[int, int] | None = None
        self.slice_mode = False
        self.slice_start: tuple[float, float] | None = None
        self.slice_profile: tuple[np.ndarray, np.ndarray, tuple[float, float], tuple[float, float]] | None = None
        self.roi_selecting = False
        self.source_paths: list[str] = []
        self._render_after_id: str | None = None
        self._live_render_signature = None
        self.image_artist = None
        self.beam_ellipse_artist = None
        self.centroid_artist = None
        self.peak_artist = None
        self._live_display_stride = 1
        self._live_render_pending = False
        self._trace_guard = False
        self._analysis_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="spotlab-analysis")
        self._analysis_queue: queue.Queue = queue.Queue()
        self._analysis_generation = 0
        self._analysis_future = None
        self._analysis_poll_id = None
        self._last_histogram_draw = 0.0

        # Optional MVS integration. SDK calls are serialized away from Tk; the stream
        # thread keeps only the newest frame so slow analysis never builds a backlog.
        self._camera_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="spotlab-mvs")
        self._camera_events: queue.Queue = queue.Queue()
        self._camera_backend: MVSBackend | None = None
        self._camera_device: CameraDevice | None = None
        self._camera_devices: list[CameraDevice] = []
        self._camera_future = None
        self._camera_action: str | None = None
        self._camera_operation_poll_id = None
        self._camera_state = "disconnected"
        self._camera_dialog: tk.Toplevel | None = None
        self._camera_capture_thread: threading.Thread | None = None
        self._camera_capture_stop = threading.Event()
        self._camera_paused = threading.Event()
        self._camera_frame_queue: queue.Queue = queue.Queue(maxsize=1)
        self._camera_pending_frame = None
        self._camera_poll_id = None
        self._camera_analysis_inflight = False
        self._camera_closing = False
        self._camera_control_supported = {"exposure": True, "gain": True}
        self._camera_profile_warnings: list[str] = []
        self._camera_syncing_controls = False
        self._camera_control_state_lock = threading.Lock()
        self._camera_auto_exposure_enabled = False
        self._camera_auto_exposure_us = 10_000.0
        self._camera_auto_exposure_last_update = 0.0
        self._camera_actual_exposure_us: float | None = None
        self._camera_actual_gain_db: float | None = None
        self._camera_param_after_ids: dict[str, str] = {}
        self._camera_exposure_min_us = CAM_EXPOSURE_MIN_US
        self._camera_exposure_max_us = CAM_EXPOSURE_MAX_US
        self._camera_gain_min_db = CAM_GAIN_MIN_DB
        self._camera_gain_max_db = CAM_GAIN_MAX_DB

        self.subtract_bg = tk.BooleanVar(value=True)
        self.lock_bg = tk.BooleanVar(value=False)
        self.manual_bg = tk.StringVar(value="0")
        self.clip_choice = tk.StringVar(value="13.5% · 1/e²")
        self.custom_clip = tk.StringVar(value="13.5")
        self.smoothing = tk.StringVar(value="0")
        self.fast_mode = tk.BooleanVar(value=False)
        self.scale_um = tk.StringVar(value=str(DEFAULT_SENSOR_SCALE_UM_PER_PX))
        self.palette = tk.StringVar(value="turbo")
        self.view_mode = tk.StringVar(value="2D + 剖面")
        self.show_fit = tk.BooleanVar(value=True)
        self.show_tophat = tk.BooleanVar(value=False)
        self.show_reference = tk.BooleanVar(value=True)
        self.reference_opacity = tk.DoubleVar(value=0.38)
        self.reference_opacity_text = tk.StringVar(value="38%")
        self.auto_contrast = tk.BooleanVar(value=True)
        self.vmin_var = tk.StringVar(value="0")
        self.vmax_var = tk.StringVar(value="")
        self.anchor_mode = tk.StringVar(value="质心")
        self.follow_beam_profiles = tk.BooleanVar(value=False)
        # Offline camera presets: these become device controls after the MVS backend is connected.
        self.exposure_auto = tk.BooleanVar(value=True)
        self.exposure_us = tk.DoubleVar(value=10_000.0)
        self.exposure_slider_pos = tk.DoubleVar(value=self._exposure_to_position(10_000.0))
        self.exposure_value_text = tk.StringVar(value="10.00 ms")
        self.gain_auto = tk.BooleanVar(value=True)
        self.gain_db = tk.DoubleVar(value=0.0)
        self.gain_value_text = tk.StringVar(value="0.0 dB")
        self.camera_preset_note = tk.StringVar(value="离线预设 · 曝光自动 / 增益自动；尚未下发相机")
        self.camera_note_title_var = tk.StringVar(value="离线预设")
        self.connection_label_var = tk.StringVar(value="● 离线 · 文件 / 演示输入")
        self.exposure_range_min_text = tk.StringVar(value="8 µs")
        self.exposure_range_max_text = tk.StringVar(value="1000 ms")
        self.gain_range_min_text = tk.StringVar(value="0 dB")
        self.gain_range_max_text = tk.StringVar(value="24 dB")
        self.camera_button = None
        self.pause_button = None
        self.fast_button = None
        self.exposure_scale_widget = None
        self.gain_scale_widget = None

        self._build_ui()
        self._set_source_labels()
        self._connect_plot_events()
        self._refresh_analysis()
        self._analysis_poll_id = self.root.after(60, self._poll_analysis)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.bind("<Control-o>", lambda _e: self.open_image())
        self.root.bind("<Control-Shift-O>", lambda _e: self.average_image_stack())
        self.root.bind("<Control-e>", lambda _e: self.export_csv())
        self.root.bind("<Control-s>", lambda _e: self.save_project())
        self.root.bind("<Escape>", lambda _e: self.set_roi_mode(False))

    @staticmethod
    def _exposure_to_position(exposure_us: float, minimum_us: float = CAM_EXPOSURE_MIN_US,
                              maximum_us: float = CAM_EXPOSURE_MAX_US) -> float:
        minimum_us, maximum_us = float(minimum_us), float(maximum_us)
        if not (math.isfinite(minimum_us) and math.isfinite(maximum_us)) or maximum_us <= minimum_us:
            minimum_us, maximum_us = CAM_EXPOSURE_MIN_US, CAM_EXPOSURE_MAX_US
        value = min(maximum_us, max(minimum_us, float(exposure_us)))
        return 100.0 * math.log(value / minimum_us) / math.log(maximum_us / minimum_us)

    @staticmethod
    def _position_to_exposure(position: float, minimum_us: float = CAM_EXPOSURE_MIN_US,
                              maximum_us: float = CAM_EXPOSURE_MAX_US) -> float:
        minimum_us, maximum_us = float(minimum_us), float(maximum_us)
        if not (math.isfinite(minimum_us) and math.isfinite(maximum_us)) or maximum_us <= minimum_us:
            minimum_us, maximum_us = CAM_EXPOSURE_MIN_US, CAM_EXPOSURE_MAX_US
        fraction = min(100.0, max(0.0, float(position))) / 100.0
        return minimum_us * math.exp(fraction * math.log(maximum_us / minimum_us))

    @staticmethod
    def _format_exposure(exposure_us: float) -> str:
        value = float(exposure_us)
        return f"{value:.0f} µs" if value < 1000 else f"{value / 1000:.2f} ms"

    @staticmethod
    def _camera_high_percentile(image: np.ndarray) -> tuple[float, float]:
        """Robust highlight statistic from a 1-in-4 sample of a Mono8 frame."""
        sample = np.asarray(image, dtype=np.uint8)[::2, ::2]
        if sample.size == 0:
            return 0.0, 0.0
        flat = sample.ravel()
        histogram = np.bincount(flat, minlength=256)
        rank = max(1, int(math.ceil(flat.size * .9999)))
        high_adu = float(np.searchsorted(np.cumsum(histogram), rank, side="left"))
        near_clip_fraction = float(np.count_nonzero(flat >= 250) / flat.size)
        return high_adu, near_clip_fraction

    @staticmethod
    def _safe_auto_exposure(exposure_us: float, high_adu: float, near_clip_fraction: float,
                            minimum_us: float, maximum_us: float,
                            target_adu: float = AUTO_EXPOSURE_TARGET_ADU) -> float:
        """Return a bounded exposure update that leaves headroom for a bright beam."""
        current = float(exposure_us)
        minimum, maximum = float(minimum_us), float(maximum_us)
        if not all(math.isfinite(v) for v in (current, minimum, maximum, high_adu, near_clip_fraction)):
            return current
        if minimum <= 0 or maximum <= minimum:
            return current
        current = float(np.clip(current, minimum, maximum))
        target = float(np.clip(target_adu, 1.0, 245.0))
        high = float(np.clip(high_adu, 0.0, 255.0))
        clipped = float(np.clip(near_clip_fraction, 0.0, 1.0))
        if high > target + 8.0 or clipped >= .0005:
            factor = target / max(high, 1.0)
            if clipped >= .0005:
                factor = min(factor, .78)
        elif high < target - 8.0:
            factor = target / max(high, 4.0)
        else:
            return current
        factor = float(np.clip(factor, .60, 1.50))
        updated = float(np.clip(current * factor, minimum, maximum))
        return updated if abs(updated - current) >= max(1.0, current * .025) else current

    def _configure_style(self) -> None:
        # A restrained navy / teal palette with consistent spacing and readable
        # hierarchy; keep native ttk controls for Windows high-DPI support.
        self.style.configure("TFrame", background="#edf2f7")
        self.style.configure("Panel.TFrame", background="#ffffff")
        self.style.configure("Camera.TFrame", background="#f8fbfd")
        self.style.configure("TLabel", background="#edf2f7", foreground="#1d3143", font=("Segoe UI", 10))
        self.style.configure("Panel.TLabel", background="#ffffff", foreground="#21384a", font=("Segoe UI", 10))
        self.style.configure("Title.TLabel", background="#102535", foreground="#ffffff", font=("Segoe UI", 18, "bold"))
        self.style.configure("SubTitle.TLabel", background="#102535", foreground="#a8bdc9", font=("Segoe UI", 8))
        self.style.configure("Section.TLabelframe", background="#ffffff", bordercolor="#d6e1e9", relief="solid")
        self.style.configure("Section.TLabelframe.Label", background="#ffffff", foreground="#425b6d", font=("Segoe UI", 9, "bold"))
        self.style.configure("TButton", padding=(9, 6), font=("Segoe UI", 9))
        self.style.map("TButton", foreground=[("disabled", "#9aa8b3"), ("active", "#0d7180")])
        self.style.configure("TCheckbutton", background="#ffffff", foreground="#344b5d", font=("Segoe UI", 9))
        self.style.map("TCheckbutton", foreground=[("disabled", "#9aa7b2"), ("active", "#087f8c")])
        self.style.configure("Primary.TButton", padding=(10, 6), background="#087f8c", foreground="#ffffff")
        self.style.map("Primary.TButton", background=[("active", "#066b77"), ("pressed", "#055963")])
        self.style.configure("Accent.TButton", padding=(10, 6), background="#e5f5f3", foreground="#126a68")
        self.style.map("Accent.TButton", background=[("active", "#d2ece8"), ("pressed", "#c1e4de")])
        self.style.configure("Treeview", rowheight=27, font=("Segoe UI", 9), background="#ffffff", fieldbackground="#ffffff")
        self.style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#f2f6f8")
        self.style.map("Treeview", background=[("selected", "#d9efed")], foreground=[("selected", "#183746")])
        self.style.configure("TNotebook", background="#ffffff", tabmargins=(2, 5, 2, 0))
        self.style.configure("TNotebook.Tab", padding=(12, 8), font=("Segoe UI", 9))
        self.style.map("TNotebook.Tab", background=[("selected", "#ffffff"), ("active", "#f4f8fa")],
                       foreground=[("selected", "#087f8c")])
        self.style.configure("Horizontal.TScale", background="#ffffff", troughcolor="#d8e2ea")

    def _build_ui(self) -> None:
        header = tk.Frame(self.root, bg="#102535", height=60)
        header.pack(fill="x")
        header.pack_propagate(False)
        brand = tk.Frame(header, bg="#102535")
        brand.pack(side="left", padx=16, pady=7)
        mark = tk.Canvas(brand, width=34, height=34, bg="#183746", highlightthickness=0)
        mark.pack(side="left", padx=(0, 10))
        mark.create_oval(6, 10, 26, 22, outline="#83ddd4", width=1.4)
        mark.create_oval(13, 13, 19, 19, fill="#ffbd66", outline="")
        mark.create_line(6, 16, 26, 16, fill="#83ddd4", width=1)
        titles = tk.Frame(brand, bg="#102535")
        titles.pack(side="left")
        ttk.Label(titles, text="光束分析仪", style="Title.TLabel").pack(anchor="w")
        ttk.Label(titles, text="SPOTLAB · MVS CAMERA + OFFLINE ANALYSIS", style="SubTitle.TLabel").pack(anchor="w")
        tk.Label(header, text="0.7.4 · HIKROBOT MVS", bg="#1c4652", fg="#b9e7df",
                 padx=10, pady=5, font=("Segoe UI", 8)).pack(side="right", padx=15)
        tk.Label(header, textvariable=self.connection_label_var, bg="#102535", fg="#c0d1d9",
                 font=("Segoe UI", 9)).pack(side="right", padx=8)
        tk.Frame(self.root, bg="#1aa89d", height=2).pack(fill="x")

        bar = ttk.Frame(self.root, padding=(12, 8))
        bar.pack(fill="x")
        ttk.Button(bar, text="打开图像", command=self.open_image, style="Primary.TButton").pack(side="left", padx=(0, 5))
        ttk.Button(bar, text="多帧平均", command=self.average_image_stack).pack(side="left", padx=4)
        ttk.Button(bar, text="演示光斑", command=self.load_demo).pack(side="left", padx=3)
        ttk.Button(bar, text="记录光斑", command=self.record_reference, style="Primary.TButton").pack(side="left", padx=3)
        ttk.Button(bar, text="清除参考", command=self.clear_reference).pack(side="left", padx=3)
        ttk.Button(bar, text="十字线→中心", command=self.reset_crosshair).pack(side="left", padx=3)
        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=6)
        ttk.Button(bar, text="保存 TIFF", command=self.save_tiff).pack(side="left", padx=4)
        ttk.Button(bar, text="导出 CSV", command=self.export_csv).pack(side="left", padx=4)
        ttk.Button(bar, text="生成报告", command=self.export_report).pack(side="left", padx=4)
        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(bar, text="打开项目…", command=self.open_project).pack(side="left", padx=4)
        ttk.Button(bar, text="保存项目…", command=self.save_project).pack(side="left", padx=4)
        self.camera_button = ttk.Button(bar, text="连接相机", command=self.toggle_camera_connection,
                                         style="Primary.TButton")
        self.camera_button.pack(side="right", padx=4)
        self.pause_button = ttk.Button(bar, text="暂停实时", command=self.toggle_camera_pause,
                                       style="Accent.TButton", state="disabled")
        self.pause_button.pack(side="right", padx=4)
        self._build_camera_controls(self.root)

        body = ttk.Panedwindow(self.root, orient="horizontal")
        body.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        left = ttk.Frame(body, width=270, style="Panel.TFrame", padding=8)
        center = ttk.Frame(body, style="Panel.TFrame", padding=5)
        right = ttk.Frame(body, width=350, style="Panel.TFrame", padding=8)
        body.add(left, weight=0)
        body.add(center, weight=1)
        body.add(right, weight=0)
        left.pack_propagate(False)
        right.pack_propagate(False)
        self._build_left_panel(left)
        self._build_center(center)
        self._build_right_panel(right)

        self.status_var = tk.StringVar(value="就绪 · 可连接 Hikrobot MVS 相机，或继续进行离线图像分析。")
        status = tk.Frame(self.root, bg="#102535", height=28)
        status.pack(fill="x", side="bottom")
        status.pack_propagate(False)
        tk.Label(status, textvariable=self.status_var, bg="#102535", fg="#c0d1d9",
                 anchor="w", padx=14, font=("Segoe UI", 8)).pack(fill="both", expand=True)

    def _build_camera_controls(self, parent: tk.Misc) -> None:
        """Build camera-setting presets; no hardware commands are issued in offline mode."""
        outer = ttk.Frame(parent, padding=(10, 0, 10, 7))
        outer.pack(fill="x")
        card = ttk.Frame(outer, style="Camera.TFrame", padding=(12, 7))
        card.pack(fill="x")
        card.columnconfigure(1, weight=1, minsize=300)
        card.columnconfigure(3, weight=1, minsize=260)
        card.columnconfigure(4, minsize=220)

        intro = ttk.Frame(card, style="Camera.TFrame")
        intro.grid(row=0, column=0, sticky="nsw", padx=(0, 12))
        ttk.Label(intro, text="采集参数", style="Panel.TLabel",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(2, 1))
        ttk.Label(intro, text="MVS CAMERA CONTROL", style="Panel.TLabel",
                  foreground="#8193a2", font=("Segoe UI", 8)).pack(anchor="w")

        exposure = ttk.Frame(card, style="Camera.TFrame")
        exposure.grid(row=0, column=1, sticky="ew", padx=(0, 12))
        exposure_head = ttk.Frame(exposure, style="Camera.TFrame")
        exposure_head.pack(fill="x")
        ttk.Label(exposure_head, text="曝光时间", style="Panel.TLabel",
                  font=("Segoe UI", 9, "bold")).pack(side="left")
        ttk.Checkbutton(exposure_head, text="自动", variable=self.exposure_auto,
                        command=lambda: self._on_camera_auto_mode_changed("exposure")).pack(side="left", padx=(9, 0))
        ttk.Label(exposure_head, textvariable=self.exposure_value_text, style="Panel.TLabel",
                  foreground="#1479b8", font=("Segoe UI", 10, "bold")).pack(side="right")
        self.exposure_scale_widget = ttk.Scale(
            exposure, from_=0.0, to=100.0, variable=self.exposure_slider_pos,
            command=self._on_exposure_slider, style="Horizontal.TScale")
        self.exposure_scale_widget.pack(fill="x", pady=(1, 0))
        exposure_range = ttk.Frame(exposure, style="Camera.TFrame")
        exposure_range.pack(fill="x")
        ttk.Label(exposure_range, textvariable=self.exposure_range_min_text, style="Panel.TLabel",
                  foreground="#94a2ae", font=("Segoe UI", 7)).pack(side="left")
        ttk.Label(exposure_range, text="对数刻度", style="Panel.TLabel",
                  foreground="#94a2ae", font=("Segoe UI", 7)).pack(side="left", expand=True)
        ttk.Label(exposure_range, textvariable=self.exposure_range_max_text, style="Panel.TLabel",
                  foreground="#94a2ae", font=("Segoe UI", 7)).pack(side="right")

        ttk.Separator(card, orient="vertical").grid(row=0, column=2, sticky="ns", padx=(0, 12))
        gain = ttk.Frame(card, style="Camera.TFrame")
        gain.grid(row=0, column=3, sticky="ew", padx=(0, 12))
        gain_head = ttk.Frame(gain, style="Camera.TFrame")
        gain_head.pack(fill="x")
        ttk.Label(gain_head, text="模拟增益", style="Panel.TLabel",
                  font=("Segoe UI", 9, "bold")).pack(side="left")
        ttk.Checkbutton(gain_head, text="自动", variable=self.gain_auto,
                        command=lambda: self._on_camera_auto_mode_changed("gain")).pack(side="left", padx=(9, 0))
        ttk.Label(gain_head, textvariable=self.gain_value_text, style="Panel.TLabel",
                  foreground="#1479b8", font=("Segoe UI", 10, "bold")).pack(side="right")
        self.gain_scale_widget = ttk.Scale(
            gain, from_=CAM_GAIN_MIN_DB, to=CAM_GAIN_MAX_DB, variable=self.gain_db,
            command=self._on_gain_slider, style="Horizontal.TScale")
        self.gain_scale_widget.pack(fill="x", pady=(1, 0))
        gain_range = ttk.Frame(gain, style="Camera.TFrame")
        gain_range.pack(fill="x")
        ttk.Label(gain_range, textvariable=self.gain_range_min_text, style="Panel.TLabel",
                  foreground="#94a2ae", font=("Segoe UI", 7)).pack(side="left")
        ttk.Label(gain_range, text="线性刻度", style="Panel.TLabel",
                  foreground="#94a2ae", font=("Segoe UI", 7)).pack(side="left", expand=True)
        ttk.Label(gain_range, textvariable=self.gain_range_max_text, style="Panel.TLabel",
                  foreground="#94a2ae", font=("Segoe UI", 7)).pack(side="right")

        note = ttk.Frame(card, style="Camera.TFrame")
        note.grid(row=0, column=4, sticky="nsew")
        ttk.Label(note, textvariable=self.camera_note_title_var, style="Panel.TLabel", foreground="#1479b8",
                  font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(1, 2))
        ttk.Label(note, textvariable=self.camera_preset_note, style="Panel.TLabel",
                  foreground="#758796", wraplength=230, justify="left",
                  font=("Segoe UI", 8)).pack(anchor="w")
        self._on_camera_auto_mode_changed()

    def _on_exposure_slider(self, position: str | float) -> None:
        exposure_us = self._position_to_exposure(
            float(position), self._camera_exposure_min_us, self._camera_exposure_max_us)
        self.exposure_us.set(exposure_us)
        self.exposure_value_text.set(self._format_exposure(exposure_us))
        if not self.exposure_auto.get():
            self._schedule_camera_feature_write("ExposureTime", exposure_us)

    def _on_gain_slider(self, value: str | float) -> None:
        gain_db = float(np.clip(float(value), self._camera_gain_min_db, self._camera_gain_max_db))
        self.gain_db.set(gain_db)
        self.gain_value_text.set(f"{gain_db:.1f} dB")
        if not self.gain_auto.get():
            self._schedule_camera_feature_write("Gain", gain_db)

    def _on_camera_auto_mode_changed(self, feature: str | None = None) -> None:
        self._sync_camera_control_states()
        exposure_mode = "高光保护自动" if self.exposure_auto.get() else "手动"
        gain_mode = "自动" if self.gain_auto.get() else "手动"
        if self._camera_state == "connected":
            device_name = self._camera_device.model if self._camera_device else "MVS 相机"
            self.camera_note_title_var.set("MVS 设备控制")
            note = (f"{device_name} · 曝光{exposure_mode} / 增益{gain_mode}\n"
                    f"曝光自动目标约 {AUTO_EXPOSURE_TARGET_ADU:.0f}/255 ADU；"
                    f"范围：{self._format_exposure(self._camera_exposure_min_us)}–"
                    f"{self._format_exposure(self._camera_exposure_max_us)}；"
                    f"增益 {self._camera_gain_min_db:g}–{self._camera_gain_max_db:g} dB")
            if self._camera_profile_warnings:
                note += "\n提示：" + "；".join(self._camera_profile_warnings)
            self.camera_preset_note.set(note)

            if self._camera_syncing_controls:
                return
            backend = self._camera_backend
            if feature in (None, "exposure"):
                automatic = bool(self.exposure_auto.get())
                actual = self._camera_actual_exposure_us
                value = float(actual if actual is not None else self.exposure_us.get())
                value = float(np.clip(value, self._camera_exposure_min_us, self._camera_exposure_max_us))
                self._camera_auto_exposure_last_update = 0.0
                with self._camera_control_state_lock:
                    self._camera_auto_exposure_enabled = automatic
                    self._camera_auto_exposure_us = value
                if not automatic:
                    self.exposure_us.set(value)
                    self.exposure_slider_pos.set(self._exposure_to_position(
                        value, self._camera_exposure_min_us, self._camera_exposure_max_us))
                pending_id = self._camera_param_after_ids.pop("ExposureTime", None)
                if pending_id:
                    try:
                        self.root.after_cancel(pending_id)
                    except tk.TclError:
                        pass
                if backend is not None:
                    def apply_exposure_mode(b=backend, auto=automatic, v=value):
                        # The camera's frame-average AE can clip a small bright beam.
                        # Keep the actual ExposureTime node manual and close the loop
                        # against a robust highlight statistic in the live frames.
                        b.set_auto("ExposureAuto", False)
                        if not auto:
                            b.set_float_feature("ExposureTime", v)
                    self._submit_camera_command("曝光高光保护自动" if automatic else "曝光手动模式",
                                                apply_exposure_mode)
                if feature == "exposure":
                    self.status_var.set(
                        "已启用光束高光保护曝光自动（目标约 185/255 ADU）；"
                        "若仍饱和，可切手动并缩短曝光。" if automatic else
                        "曝光自动已关闭；使用实际相机曝光范围进行手动控制。")

            if feature == "gain":
                automatic = bool(self.gain_auto.get())
                actual = self._camera_actual_gain_db
                value = float(actual if not automatic and actual is not None else self.gain_db.get())
                if not automatic and actual is not None:
                    value = float(np.clip(value, self._camera_gain_min_db, self._camera_gain_max_db))
                    self.gain_db.set(value)
                pending_id = self._camera_param_after_ids.pop("Gain", None)
                if pending_id:
                    try:
                        self.root.after_cancel(pending_id)
                    except tk.TclError:
                        pass
                if backend is not None:
                    def apply_gain_mode(b=backend, auto=automatic, v=value):
                        b.set_auto("GainAuto", auto)
                        if not auto:
                            b.set_float_feature("Gain", v)
                    self._submit_camera_command("gain 模式", apply_gain_mode)
        else:
            self.camera_note_title_var.set("离线预设")
            self.camera_preset_note.set(
                f"离线预设 · 曝光{exposure_mode} / 增益{gain_mode}；不会下发到相机。")

    def _sync_camera_control_states(self) -> None:
        connected = self._camera_state == "connected"
        exposure_supported = (not connected or self._camera_control_supported.get("exposure", False))
        gain_supported = (not connected or self._camera_control_supported.get("gain", False))
        if self.exposure_scale_widget is not None:
            state = "disabled" if self.exposure_auto.get() or not exposure_supported else "normal"
            self.exposure_scale_widget.configure(state=state)
        if self.gain_scale_widget is not None:
            state = "disabled" if self.gain_auto.get() or not gain_supported else "normal"
            self.gain_scale_widget.configure(state=state)

    def _schedule_camera_feature_write(self, node: str, value: float) -> None:
        if self._camera_state != "connected" or self._camera_backend is None:
            return
        if node == "ExposureTime" and self.exposure_auto.get():
            return
        if node == "Gain" and self.gain_auto.get():
            return
        old_id = self._camera_param_after_ids.pop(node, None)
        if old_id:
            try:
                self.root.after_cancel(old_id)
            except tk.TclError:
                pass
        self._camera_param_after_ids[node] = self.root.after(
            220, lambda n=node, v=float(value): self._send_camera_feature(n, v))

    def _send_camera_feature(self, node: str, value: float) -> None:
        self._camera_param_after_ids.pop(node, None)
        backend = self._camera_backend
        if self._camera_state != "connected" or backend is None:
            return
        if (node == "ExposureTime" and self.exposure_auto.get()) or (node == "Gain" and self.gain_auto.get()):
            return
        label = "曝光时间" if node == "ExposureTime" else "模拟增益"
        self._submit_camera_command(label, lambda b=backend, n=node, v=value: b.set_float_feature(n, v))

    def _submit_camera_command(self, label: str, operation: Any) -> None:
        if self._camera_state != "connected" or self._camera_backend is None:
            return
        try:
            future = self._camera_executor.submit(operation)
        except RuntimeError:
            return
        future.add_done_callback(lambda f, name=label: self._camera_events.put(("command", name, f)))

    def _camera_preset(self) -> dict[str, Any]:
        exposure = self._camera_actual_exposure_us if self._camera_state == "connected" else None
        gain = self._camera_actual_gain_db if self._camera_state == "connected" else None
        return {"exposure_auto": bool(self.exposure_auto.get()),
                "exposure_us": float(exposure if exposure is not None else self.exposure_us.get()),
                "gain_auto": bool(self.gain_auto.get()),
                "gain_db": float(gain if gain is not None else self.gain_db.get())}

    def _restore_camera_preset(self, values: dict[str, Any] | None) -> None:
        values = values or {}
        try:
            exposure_us = float(values.get("exposure_us", self.exposure_us.get()))
        except (TypeError, ValueError):
            exposure_us = 10_000.0
        exposure_us = float(np.clip(exposure_us, self._camera_exposure_min_us, self._camera_exposure_max_us))
        try:
            gain_db = float(values.get("gain_db", self.gain_db.get()))
        except (TypeError, ValueError):
            gain_db = 0.0
        gain_db = float(np.clip(gain_db, self._camera_gain_min_db, self._camera_gain_max_db))
        self.exposure_us.set(exposure_us)
        self.exposure_slider_pos.set(self._exposure_to_position(
            exposure_us, self._camera_exposure_min_us, self._camera_exposure_max_us))
        self.exposure_value_text.set(self._format_exposure(exposure_us))
        self.gain_db.set(gain_db)
        self.gain_value_text.set(f"{gain_db:.1f} dB")
        self.exposure_auto.set(bool(values.get("exposure_auto", self.exposure_auto.get())))
        self.gain_auto.set(bool(values.get("gain_auto", self.gain_auto.get())))
        self._on_camera_auto_mode_changed()

    def toggle_camera_connection(self) -> None:
        if self._camera_state == "connected":
            self._disconnect_camera()
            return
        if self._camera_state in {"enumerating", "connecting", "disconnecting"}:
            return
        self._camera_state = "enumerating"
        self.connection_label_var.set("◌ 正在搜索 MVS 设备…")
        self.camera_preset_note.set("正在加载 MVS SDK 并搜索 GigE / USB3 相机…")
        self.camera_note_title_var.set("设备搜索")
        if self.camera_button is not None:
            self.camera_button.configure(text="搜索中…", state="disabled")
        self.status_var.set("正在搜索 Hikrobot MVS 相机；离线分析仍可继续使用。")
        self._camera_action = "enumerate"
        try:
            self._camera_future = self._camera_executor.submit(MVSBackend.discover)
        except RuntimeError as exc:
            self._camera_state = "disconnected"
            self._set_camera_disconnected_ui()
            messagebox.showerror("相机搜索失败", str(exc), parent=self.root)
            return
        self._schedule_camera_operation_poll()

    def _schedule_camera_operation_poll(self) -> None:
        if self._camera_closing or self._camera_operation_poll_id is not None:
            return
        self._camera_operation_poll_id = self.root.after(80, self._poll_camera_operation)

    def _poll_camera_operation(self) -> None:
        self._camera_operation_poll_id = None
        future = self._camera_future
        if future is None:
            return
        if not future.done():
            self._schedule_camera_operation_poll()
            return
        action = self._camera_action
        self._camera_future = None
        self._camera_action = None
        try:
            result = future.result()
        except Exception as exc:
            if action in {"connect", "disconnect"}:
                backend = self._camera_backend
                if backend is not None:
                    try:
                        backend.close()
                    except Exception:
                        pass
                self._camera_backend = None
                self._camera_device = None
                self._camera_state = "disconnected"
                self._set_camera_disconnected_ui()
            elif action == "enumerate":
                self._camera_state = "disconnected"
                self._set_camera_disconnected_ui()
            if not self._camera_closing and action != "disconnect":
                messagebox.showerror("MVS 相机操作失败", str(exc), parent=self.root)
                self.status_var.set(f"相机操作失败：{exc}")
            return

        if action == "enumerate":
            backend, devices = result
            self._camera_backend = backend
            self._camera_devices = devices
            if not devices:
                backend.close()
                self._camera_backend = None
                self._camera_state = "disconnected"
                self._set_camera_disconnected_ui()
                self.status_var.set("未发现 MVS 相机；请检查相机供电、USB3/GigE 连接和 MVS 驱动。")
                messagebox.showinfo("未发现相机", "没有枚举到 Hikrobot GigE / USB3 相机。\n\n"
                                    "请确认相机已连接并供电，关闭占用相机的其他软件后重试。",
                                    parent=self.root)
                return
            self.connection_label_var.set(f"● 找到 {len(devices)} 台 MVS 相机")
            self.camera_preset_note.set("请选择要连接的设备。")
            self.camera_note_title_var.set("选择设备")
            self._show_camera_selection_dialog(devices)
        elif action == "connect":
            self._apply_camera_profile(result or {})
            self._camera_state = "connected"
            model = self._camera_device.model if self._camera_device else "Hikrobot camera"
            serial = f" · S/N {self._camera_device.serial}" if self._camera_device and self._camera_device.serial else ""
            self.connection_label_var.set(f"● MVS 在线 · {model}{serial}")
            self._camera_paused.clear()
            if self.camera_button is not None:
                self.camera_button.configure(text="断开相机", state="normal")
            if self.pause_button is not None:
                self.pause_button.configure(text="暂停实时", state="normal")
            # A 6 MP live stream is much heavier than offline files: enable 1/3
            # sampling and skip the 3D dashboard while streaming.
            if not self.fast_mode.get():
                self.fast_mode.set(True)
            if self.view_mode.get() in ("仪表盘", "3D 表面"):
                self.view_mode.set("2D + 剖面")
            self.follow_beam_profiles.set(True)
            self.profile_anchor = None
            if self.fast_button is not None:
                self.fast_button.configure(text="快速 1/3")
            self._on_camera_auto_mode_changed()
            self._start_camera_capture()
            self.status_var.set(f"相机已连接：{model}{serial} · 正在采集 Mono8 实时帧。")
        elif action == "disconnect":
            self._camera_backend = None
            self._camera_device = None
            self._camera_state = "disconnected"
            self._set_camera_disconnected_ui()
            self.status_var.set("相机已断开；当前帧仍可继续离线分析或保存。")

    def _show_camera_selection_dialog(self, devices: list[CameraDevice]) -> None:
        dialog = tk.Toplevel(self.root)
        self._camera_dialog = dialog
        dialog.title("选择 Hikrobot MVS 相机")
        dialog.transient(self.root)
        dialog.resizable(False, False)
        frame = ttk.Frame(dialog, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="发现以下相机，请选择设备：").pack(anchor="w", pady=(0, 8))
        selected = tk.StringVar(value=devices[0].label)
        combo = ttk.Combobox(frame, textvariable=selected, state="readonly", width=58,
                             values=[device.label for device in devices])
        combo.pack(fill="x", pady=(0, 12))
        combo.current(0)
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x")

        def cancel() -> None:
            if self._camera_dialog is not None:
                try:
                    self._camera_dialog.destroy()
                except tk.TclError:
                    pass
                self._camera_dialog = None
            backend = self._camera_backend
            self._camera_backend = None
            self._camera_devices = []
            self._camera_state = "disconnected"
            if backend is not None:
                try:
                    backend.close()
                except Exception:
                    pass
            self._set_camera_disconnected_ui()
            self.status_var.set("已取消相机连接；离线分析保持可用。")

        def connect_selected() -> None:
            index = combo.current()
            if index < 0 or index >= len(devices):
                return
            device = devices[index]
            try:
                dialog.destroy()
            except tk.TclError:
                pass
            self._camera_dialog = None
            self._connect_camera_device(device)

        ttk.Button(buttons, text="取消", command=cancel).pack(side="right", padx=(6, 0))
        ttk.Button(buttons, text="连接", command=connect_selected, style="Primary.TButton").pack(side="right")
        dialog.protocol("WM_DELETE_WINDOW", cancel)
        dialog.grab_set()
        combo.focus_set()

    def _connect_camera_device(self, device: CameraDevice) -> None:
        backend = self._camera_backend
        if backend is None:
            self._camera_state = "disconnected"
            self._set_camera_disconnected_ui()
            return
        self._camera_device = device
        self._camera_state = "connecting"
        self.connection_label_var.set(f"◌ 正在连接 · {device.model}")
        self.camera_preset_note.set("正在打开设备并读取 ExposureTime / Gain 实际范围…")
        self.camera_note_title_var.set("相机连接")
        if self.camera_button is not None:
            self.camera_button.configure(text="连接中…", state="disabled")
        self.status_var.set(f"正在连接相机：{device.label}")
        self._camera_action = "connect"
        try:
            def open_selected(b=backend, index=device.index):
                profile = b.open_device(index)
                # Disable hardware frame-average AE before the preview thread starts;
                # the UI's auto checkbox then drives the beam-aware software loop.
                if profile.get("exposure_auto"):
                    b.set_auto("ExposureAuto", False)
                return profile
            self._camera_future = self._camera_executor.submit(open_selected)
        except RuntimeError as exc:
            self._camera_state = "disconnected"
            self._camera_backend = None
            self._set_camera_disconnected_ui()
            backend.close()
            messagebox.showerror("相机连接失败", str(exc), parent=self.root)
            return
        self._schedule_camera_operation_poll()

    def _apply_camera_profile(self, profile: dict[str, Any]) -> None:
        exposure: CameraFeatureRange | None = profile.get("exposure")
        gain: CameraFeatureRange | None = profile.get("gain")
        self._camera_control_supported = {"exposure": exposure is not None, "gain": gain is not None}
        self._camera_actual_exposure_us = None
        self._camera_actual_gain_db = None
        self._camera_profile_warnings = []
        if exposure is None:
            self._camera_profile_warnings.append("无法读取 ExposureTime")
        if gain is None:
            self._camera_profile_warnings.append("无法读取 Gain")
        if profile.get("exposure_auto") is None:
            self._camera_profile_warnings.append("无法读取 ExposureAuto")
        if profile.get("gain_auto") is None:
            self._camera_profile_warnings.append("无法读取 GainAuto")
        self._camera_syncing_controls = True
        try:
            if exposure is not None:
                minimum = max(float(exposure.minimum), 1e-9)
                maximum = float(exposure.maximum)
                if maximum > minimum:
                    self._camera_exposure_min_us, self._camera_exposure_max_us = minimum, maximum
                    value = float(np.clip(exposure.current, minimum, maximum))
                    self._camera_actual_exposure_us = value
                    self.exposure_us.set(value)
                    self.exposure_slider_pos.set(self._exposure_to_position(value, minimum, maximum))
                    self.exposure_value_text.set(self._format_exposure(value))
                    self.exposure_range_min_text.set(self._format_exposure(minimum))
                    self.exposure_range_max_text.set(self._format_exposure(maximum))
            if gain is not None:
                minimum, maximum = float(gain.minimum), float(gain.maximum)
                if maximum > minimum:
                    self._camera_gain_min_db, self._camera_gain_max_db = minimum, maximum
                    value = float(np.clip(gain.current, minimum, maximum))
                    self._camera_actual_gain_db = value
                    self.gain_db.set(value)
                    self.gain_value_text.set(f"{value:.1f} dB")
                    self.gain_range_min_text.set(f"{minimum:g} dB")
                    self.gain_range_max_text.set(f"{maximum:g} dB")
                    if self.gain_scale_widget is not None:
                        self.gain_scale_widget.configure(from_=minimum, to=maximum)
            if profile.get("exposure_auto") is not None:
                self.exposure_auto.set(bool(profile["exposure_auto"]))
            if profile.get("gain_auto") is not None:
                self.gain_auto.set(bool(profile["gain_auto"]))
        finally:
            self._camera_syncing_controls = False
        self._sync_camera_control_states()

    def _reset_offline_camera_ranges(self) -> None:
        self._camera_exposure_min_us, self._camera_exposure_max_us = CAM_EXPOSURE_MIN_US, CAM_EXPOSURE_MAX_US
        self._camera_gain_min_db, self._camera_gain_max_db = CAM_GAIN_MIN_DB, CAM_GAIN_MAX_DB
        self._camera_control_supported = {"exposure": True, "gain": True}
        self._camera_profile_warnings = []
        exposure_value = (self._camera_actual_exposure_us if self._camera_actual_exposure_us is not None
                         else self.exposure_us.get())
        gain_value = (self._camera_actual_gain_db if self._camera_actual_gain_db is not None
                      else self.gain_db.get())
        exposure = float(np.clip(exposure_value, CAM_EXPOSURE_MIN_US, CAM_EXPOSURE_MAX_US))
        gain = float(np.clip(gain_value, CAM_GAIN_MIN_DB, CAM_GAIN_MAX_DB))
        self._camera_actual_exposure_us = None
        self._camera_actual_gain_db = None
        with self._camera_control_state_lock:
            self._camera_auto_exposure_enabled = False
            self._camera_auto_exposure_us = exposure
        self.exposure_us.set(exposure)
        self.exposure_slider_pos.set(self._exposure_to_position(exposure))
        self.exposure_value_text.set(self._format_exposure(exposure))
        self.exposure_range_min_text.set(self._format_exposure(CAM_EXPOSURE_MIN_US))
        self.exposure_range_max_text.set(self._format_exposure(CAM_EXPOSURE_MAX_US))
        self.gain_db.set(gain)
        self.gain_value_text.set(f"{gain:.1f} dB")
        self.gain_range_min_text.set(f"{CAM_GAIN_MIN_DB:g} dB")
        self.gain_range_max_text.set(f"{CAM_GAIN_MAX_DB:g} dB")
        if self.gain_scale_widget is not None:
            self.gain_scale_widget.configure(from_=CAM_GAIN_MIN_DB, to=CAM_GAIN_MAX_DB)

    def _set_camera_disconnected_ui(self) -> None:
        while True:
            try:
                self._camera_events.get_nowait()
            except queue.Empty:
                break
        self.connection_label_var.set("● 离线 · 文件 / 演示输入")
        self._camera_paused.clear()
        if self.camera_button is not None:
            self.camera_button.configure(text="连接相机", state="normal")
        if self.pause_button is not None:
            self.pause_button.configure(text="暂停实时", state="disabled")
        if self.fast_button is not None:
            self.fast_button.configure(text="快速 1/2")
        self.camera_note_title_var.set("离线预设")
        self._reset_offline_camera_ranges()
        self._on_camera_auto_mode_changed()

    def _start_camera_capture(self) -> None:
        self._camera_capture_stop.clear()
        self._camera_paused.clear()
        self._camera_pending_frame = None
        self._camera_analysis_inflight = False
        self._camera_capture_thread = threading.Thread(
            target=self._camera_capture_loop, name="spotlab-camera-stream", daemon=True)
        self._camera_capture_thread.start()
        self._camera_poll_id = self.root.after(35, self._poll_camera_frames)

    def toggle_camera_pause(self) -> None:
        if self._camera_state != "connected" or self._camera_backend is None:
            return
        backend = self._camera_backend
        if not self._camera_paused.is_set():
            self._camera_paused.set()
            self._camera_pending_frame = None
            while True:
                try:
                    self._camera_frame_queue.get_nowait()
                except queue.Empty:
                    break
            if self.pause_button is not None:
                self.pause_button.configure(text="继续实时", state="disabled")
            self.status_var.set("实时采集已暂停 · 画面冻结，可继续查看当前测量。")
            self._submit_camera_command("暂停实时采集", backend.stop_grabbing)
        else:
            self._camera_paused.clear()
            if self.pause_button is not None:
                self.pause_button.configure(text="暂停实时", state="disabled")
            self.status_var.set("正在恢复实时采集…")
            self._submit_camera_command("恢复实时采集", backend.start_grabbing)

    def _camera_capture_loop(self) -> None:
        backend = self._camera_backend
        if backend is None:
            return
        last_frame_time = 0.0
        while not self._camera_capture_stop.is_set():
            try:
                packet = backend.get_frame(timeout_ms=120)
            except Exception as exc:
                self._camera_events.put(("stream_error", str(exc)))
                return
            if packet is None:
                self._camera_capture_stop.wait(.05 if self._camera_paused.is_set() else .005)
                continue
            if self._camera_paused.is_set():
                # The SDK has been asked to stop grabbing; discard any in-flight
                # frame during the transition and do not run auto exposure.
                self._camera_capture_stop.wait(1.0 / CAMERA_PREVIEW_FPS)
                continue
            image, frame_number, exposure_us, gain_db = packet
            now = time.monotonic()
            item = (image, int(frame_number), exposure_us, gain_db, now)
            try:
                self._camera_frame_queue.put_nowait(item)
            except queue.Full:
                try:
                    self._camera_frame_queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._camera_frame_queue.put_nowait(item)
                except queue.Full:
                    pass
            self._maybe_adjust_camera_exposure(image, exposure_us, now)
            # A 6 MP render is CPU-heavy; keep a latest-frame preview rather than
            # trying to redraw at the camera's full sensor frame rate.
            delay = (1.0 / CAMERA_PREVIEW_FPS) - (now - last_frame_time) if last_frame_time else 0.0
            last_frame_time = now
            if delay > 0:
                self._camera_capture_stop.wait(delay)

    def _maybe_adjust_camera_exposure(self, image: np.ndarray,
                                      frame_exposure_us: float | None,
                                      now: float | None = None) -> None:
        """Beam-aware software AE; camera ExposureAuto stays Off to protect highlights."""
        timestamp = time.monotonic() if now is None else float(now)
        if timestamp - self._camera_auto_exposure_last_update < .45:
            return
        self._camera_auto_exposure_last_update = timestamp
        with self._camera_control_state_lock:
            enabled = self._camera_auto_exposure_enabled
            current = self._camera_auto_exposure_us
        if not enabled:
            return
        if frame_exposure_us is not None and math.isfinite(float(frame_exposure_us)) and float(frame_exposure_us) > 0:
            current = float(frame_exposure_us)
        high_adu, near_clip_fraction = self._camera_high_percentile(image)
        updated = self._safe_auto_exposure(
            current, high_adu, near_clip_fraction,
            self._camera_exposure_min_us, self._camera_exposure_max_us)
        if abs(updated - current) < max(1.0, current * .025):
            with self._camera_control_state_lock:
                if self._camera_auto_exposure_enabled:
                    self._camera_auto_exposure_us = current
            return
        backend = self._camera_backend
        if backend is None:
            return
        try:
            backend.set_float_feature("ExposureTime", updated)
        except Exception as exc:
            with self._camera_control_state_lock:
                self._camera_auto_exposure_enabled = False
            self._camera_events.put(("auto_exposure_error", str(exc)))
            return
        with self._camera_control_state_lock:
            if self._camera_auto_exposure_enabled:
                self._camera_auto_exposure_us = updated

    def _drain_camera_events(self) -> None:
        while True:
            try:
                event = self._camera_events.get_nowait()
            except queue.Empty:
                return
            kind = event[0]
            if kind == "command":
                _kind, label, future = event
                try:
                    future.result()
                except Exception as exc:
                    if label == "恢复实时采集":
                        self._camera_paused.set()
                        if self.pause_button is not None:
                            self.pause_button.configure(text="继续实时")
                    elif label == "暂停实时采集":
                        self._camera_paused.clear()
                        if self.pause_button is not None:
                            self.pause_button.configure(text="暂停实时")
                    if label in {"暂停实时采集", "恢复实时采集"}:
                        self.status_var.set(f"{label}失败：{exc}")
                    else:
                        self.status_var.set(f"相机参数 {label} 设置失败：{exc}")
                        self.camera_preset_note.set(f"{label} 设置失败：{exc}")
                finally:
                    if (label in {"暂停实时采集", "恢复实时采集"}
                            and self.pause_button is not None and self._camera_state == "connected"):
                        self.pause_button.configure(state="normal")
            elif kind == "auto_exposure_error":
                _kind, error = event
                self.exposure_auto.set(False)
                self._on_camera_auto_mode_changed("exposure")
                self.status_var.set(f"曝光自动控制失败，已切回手动：{error}")
            elif kind == "stream_error":
                _kind, error = event
                self.connection_label_var.set("⚠ MVS 在线 · 图像流异常")
                self.status_var.set(f"相机图像流异常：{error}")
                if not self._camera_closing:
                    messagebox.showerror("相机图像流异常", str(error), parent=self.root)

    def _update_camera_frame_controls(self, exposure_us: float | None, gain_db: float | None) -> None:
        if exposure_us is not None and math.isfinite(float(exposure_us)) and float(exposure_us) > 0:
            actual = float(np.clip(float(exposure_us),
                                   self._camera_exposure_min_us, self._camera_exposure_max_us))
            self._camera_actual_exposure_us = actual
            self.exposure_value_text.set(self._format_exposure(actual))
            if self.exposure_auto.get():
                self.exposure_us.set(actual)
                self.exposure_slider_pos.set(self._exposure_to_position(
                    actual, self._camera_exposure_min_us, self._camera_exposure_max_us))
        if gain_db is not None and math.isfinite(float(gain_db)):
            actual = float(np.clip(float(gain_db), self._camera_gain_min_db, self._camera_gain_max_db))
            self._camera_actual_gain_db = actual
            self.gain_value_text.set(f"{actual:.1f} dB")
            if self.gain_auto.get():
                self.gain_db.set(actual)

    def _poll_camera_frames(self) -> None:
        self._camera_poll_id = None
        self._drain_camera_events()
        if self._camera_state == "connected":
            try:
                while True:
                    self._camera_pending_frame = self._camera_frame_queue.get_nowait()
            except queue.Empty:
                pass
            if self._camera_paused.is_set():
                self._camera_pending_frame = None
            elif self._camera_pending_frame is not None and not self._camera_analysis_inflight:
                frame, frame_number, exposure_us, gain_db, _captured_at = self._camera_pending_frame
                self._camera_pending_frame = None
                self._update_camera_frame_controls(exposure_us, gain_db)
                self.image = frame
                self.white_level = 255.0
                device_name = self._camera_device.model if self._camera_device else "Hikrobot camera"
                self.meta = {"path": "", "name": f"实时相机 · {device_name}", "mode": "MVS",
                             "width": int(frame.shape[1]), "height": int(frame.shape[0]),
                             "bit_depth": 8, "frame_number": frame_number}
                self.source_paths = []
                self.average_count = 1
                self._camera_analysis_inflight = True
                self._set_source_labels()
                self._refresh_analysis()
        if not self._camera_closing and self._camera_state == "connected" and self.root.winfo_exists():
            self._camera_poll_id = self.root.after(35, self._poll_camera_frames)

    def _disconnect_camera(self) -> None:
        if self._camera_state in {"disconnected", "disconnecting"}:
            return
        if self._camera_dialog is not None:
            try:
                self._camera_dialog.destroy()
            except tk.TclError:
                pass
            self._camera_dialog = None
        if self._camera_state == "enumerating" and self._camera_backend is None:
            # Enumeration is in progress; let it finish and handle its result rather than
            # racing SDK finalization from the Tk thread.
            return
        self._camera_state = "disconnecting"
        if self.pause_button is not None:
            self.pause_button.configure(state="disabled")
        with self._camera_control_state_lock:
            self._camera_auto_exposure_enabled = False
        for after_id in self._camera_param_after_ids.values():
            try:
                self.root.after_cancel(after_id)
            except tk.TclError:
                pass
        self._camera_param_after_ids.clear()
        self.connection_label_var.set("◌ 正在断开 MVS 相机…")
        if self.camera_button is not None:
            self.camera_button.configure(text="断开中…", state="disabled")
        self._camera_capture_stop.set()
        thread = self._camera_capture_thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=0.35)
        self._camera_capture_thread = None
        if self._camera_poll_id is not None:
            try:
                self.root.after_cancel(self._camera_poll_id)
            except tk.TclError:
                pass
            self._camera_poll_id = None
        self._camera_pending_frame = None
        self._camera_analysis_inflight = False
        while True:
            try:
                self._camera_frame_queue.get_nowait()
            except queue.Empty:
                break
        backend = self._camera_backend
        if backend is None:
            self._camera_state = "disconnected"
            self._set_camera_disconnected_ui()
            return
        self._camera_action = "disconnect"
        try:
            self._camera_future = self._camera_executor.submit(backend.close)
        except RuntimeError:
            try:
                backend.close()
            except Exception:
                pass
            self._camera_backend = None
            self._camera_device = None
            self._camera_state = "disconnected"
            self._set_camera_disconnected_ui()
            return
        self._schedule_camera_operation_poll()

    def _section(self, parent: ttk.Frame, title: str) -> ttk.Labelframe:
        box = ttk.LabelFrame(parent, text=title, style="Section.TLabelframe", padding=(8, 6))
        box.pack(fill="x", pady=(0, 7))
        return box

    def _build_left_panel(self, parent: ttk.Frame) -> None:
        notebook = ttk.Notebook(parent)
        notebook.pack(fill="both", expand=True)
        input_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=4)
        analysis_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=4)
        display_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=4)
        notebook.add(input_tab, text="输入 / ROI")
        notebook.add(analysis_tab, text="分析 / 校准")
        notebook.add(display_tab, text="显示")

        source = self._section(input_tab, "输入源 / 帧控制")
        self.source_name_var = tk.StringVar(value="演示光斑")
        ttk.Label(source, textvariable=self.source_name_var, style="Panel.TLabel", wraplength=215).pack(anchor="w", pady=(1, 3))
        self.source_info_var = tk.StringVar(value="1024 × 768 · 8-bit")
        ttk.Label(source, textvariable=self.source_info_var, style="Panel.TLabel", foreground="#8191a0",
                  wraplength=230, justify="left").pack(anchor="w", pady=(0, 5))
        row = ttk.Frame(source, style="Panel.TFrame")
        row.pack(fill="x")
        ttk.Button(row, text="全分辨率", command=lambda: self.set_fast(False)).pack(side="left", fill="x", expand=True, padx=(0, 3))
        self.fast_button = ttk.Button(row, text="快速 1/2", command=lambda: self.set_fast(True))
        self.fast_button.pack(side="left", fill="x", expand=True, padx=(3, 0))
        ttk.Label(source, text="平均帧数：", style="Panel.TLabel").pack(anchor="w", pady=(5, 0))
        self.average_var = tk.StringVar(value="1")
        ttk.Label(source, textvariable=self.average_var, style="Panel.TLabel", foreground="#1e76b8").pack(anchor="w")

        proc = self._section(analysis_tab, "背景 / 光束分析")
        ttk.Checkbutton(proc, text="扣除自动估计背景", variable=self.subtract_bg, command=self.schedule_analysis).pack(anchor="w", pady=2)
        ttk.Checkbutton(proc, text="锁定手动基线", variable=self.lock_bg, command=self.schedule_analysis).pack(anchor="w", pady=2)
        line = ttk.Frame(proc, style="Panel.TFrame"); line.pack(fill="x", pady=2)
        ttk.Label(line, text="手动基线", style="Panel.TLabel").pack(side="left")
        ttk.Entry(line, textvariable=self.manual_bg, width=9).pack(side="right")
        ttk.Label(proc, text="截光水平", style="Panel.TLabel").pack(anchor="w", pady=(5, 2))
        self.clip_combo = ttk.Combobox(proc, textvariable=self.clip_choice, state="readonly", width=22,
                                       values=("13.5% · 1/e²", "50% · FWHM", "86.5%", "自定义"))
        self.clip_combo.pack(fill="x")
        self.clip_combo.bind("<<ComboboxSelected>>", lambda _e: self.schedule_analysis())
        line2 = ttk.Frame(proc, style="Panel.TFrame"); line2.pack(fill="x", pady=(5, 0))
        ttk.Label(line2, text="自定义截光 %", style="Panel.TLabel").pack(side="left")
        ttk.Entry(line2, textvariable=self.custom_clip, width=9).pack(side="right")
        ttk.Label(proc, text="平滑半径（µm）", style="Panel.TLabel").pack(anchor="w", pady=(5, 2))
        smooth = ttk.Combobox(proc, textvariable=self.smoothing, state="readonly", width=10,
                              values=("0", "2.4", "4.8", "7.2", "12.0"))
        smooth.pack(anchor="w")
        smooth.bind("<<ComboboxSelected>>", lambda _e: self.schedule_analysis())
        ttk.Checkbutton(proc, text="快速分析（隔点采样）", variable=self.fast_mode,
                        command=self.schedule_analysis).pack(anchor="w", pady=(5, 0))

        fit = self._section(analysis_tab, "拟合 / 质量检查")
        ttk.Checkbutton(fit, text="显示 Gaussian 曲线拟合", variable=self.show_fit,
                        command=self._refresh_profiles_only).pack(anchor="w", pady=2)
        ttk.Checkbutton(fit, text="显示 Top Hat 平顶模型（可选）", variable=self.show_tophat,
                        command=self._refresh_profiles_only).pack(anchor="w", pady=2)
        ttk.Label(fit, text="Top Hat 是平顶光束模型；对 Gaussian 光斑通常不会贴合，默认关闭。",
                  style="Panel.TLabel", foreground="#8493a1", wraplength=220).pack(anchor="w", pady=(2, 3))
        ttk.Label(fit, text="自动提示饱和、边缘和低信噪比。", style="Panel.TLabel",
                  foreground="#8493a1", wraplength=220).pack(anchor="w", pady=(3, 0))

        cal = self._section(analysis_tab, "空间标尺")
        ttk.Label(cal, text="标尺 µm / 图像格", style="Panel.TLabel").pack(anchor="w")
        calrow = ttk.Frame(cal, style="Panel.TFrame"); calrow.pack(fill="x", pady=(3, 2))
        self.scale_entry = ttk.Entry(calrow, textvariable=self.scale_um, width=14)
        self.scale_entry.pack(side="left")
        self.scale_entry.bind("<Return>", lambda _e: self.apply_spatial_scale())
        ttk.Button(calrow, text="设定", command=self.apply_spatial_scale).pack(side="right")
        ttk.Label(cal, text="默认 2.4 µm/格为传感器面标尺；有镜头倍率时请改用实测物方标定值。",
                  style="Panel.TLabel", foreground="#8493a1", wraplength=230).pack(anchor="w", pady=(2, 0))

        display = self._section(display_tab, "显示 / 剖面")
        ttk.Label(display, text="视图布局", style="Panel.TLabel").pack(anchor="w")
        view = ttk.Combobox(display, textvariable=self.view_mode, state="readonly", width=20,
                            values=("2D + 剖面", "仪表盘", "2D 图像", "3D 表面", "剖面"))
        view.pack(fill="x", pady=(2, 5)); view.bind("<<ComboboxSelected>>", lambda _e: self.render())
        ttk.Checkbutton(display, text="剖面跟随光束质心", variable=self.follow_beam_profiles,
                        command=self._toggle_profile_follow).pack(anchor="w", pady=(0, 5))
        ttk.Label(display, text="调色板", style="Panel.TLabel").pack(anchor="w")
        pal = ttk.Combobox(display, textvariable=self.palette, state="readonly", width=20,
                           values=("inferno", "viridis", "turbo", "gray", "plasma", "coolwarm"))
        pal.pack(fill="x", pady=(2, 5)); pal.bind("<<ComboboxSelected>>", lambda _e: self.render())
        ttk.Checkbutton(display, text="自动显示范围", variable=self.auto_contrast, command=self.render).pack(anchor="w", pady=2)
        manual = ttk.Frame(display, style="Panel.TFrame"); manual.pack(fill="x", pady=2)
        ttk.Label(manual, text="Min", style="Panel.TLabel").pack(side="left")
        ttk.Entry(manual, textvariable=self.vmin_var, width=6).pack(side="left", padx=3)
        ttk.Label(manual, text="Max", style="Panel.TLabel").pack(side="left", padx=(6, 0))
        ttk.Entry(manual, textvariable=self.vmax_var, width=7).pack(side="left", padx=3)
        ttk.Button(display, text="应用显示范围", command=self.render).pack(fill="x", pady=(3, 0))
        compare = self._section(display_tab, "参考光斑透明叠加")
        self.reference_status_var = tk.StringVar(value="尚未记录参考光斑")
        ttk.Label(compare, textvariable=self.reference_status_var, style="Panel.TLabel",
                  foreground="#66798a", wraplength=220).pack(anchor="w", pady=(0, 3))
        ttk.Checkbutton(compare, text="显示参考光斑（仅显示叠加，不参与分析）",
                        variable=self.show_reference, command=self.toggle_reference_display).pack(anchor="w", pady=2)
        opacity_row = ttk.Frame(compare, style="Panel.TFrame"); opacity_row.pack(fill="x", pady=2)
        ttk.Label(opacity_row, text="透明度", style="Panel.TLabel").pack(side="left")
        ttk.Label(opacity_row, textvariable=self.reference_opacity_text, style="Panel.TLabel",
                  foreground="#1a5e91").pack(side="right")
        ttk.Scale(compare, from_=0.0, to=1.0, variable=self.reference_opacity,
                  command=self.set_reference_opacity).pack(fill="x", pady=(2, 4))
        ttk.Label(compare, text="记录层以洋红色保持原始图像位置；当前图像和测量数据不会被改写。",
                  style="Panel.TLabel", foreground="#8493a1", wraplength=220).pack(anchor="w")

        roi_box = self._section(input_tab, "感兴趣区域 / 操作")
        self.roi_var = tk.StringVar(value="ROI：全画面")
        ttk.Label(roi_box, textvariable=self.roi_var, style="Panel.TLabel").pack(anchor="w", pady=(0, 4))
        row = ttk.Frame(roi_box, style="Panel.TFrame"); row.pack(fill="x")
        self.roi_btn = ttk.Button(row, text="框选 ROI", command=lambda: self.set_roi_mode(not self.roi_selecting))
        self.roi_btn.pack(side="left", fill="x", expand=True, padx=(0, 3))
        ttk.Button(row, text="清除", command=self.clear_roi).pack(side="left", padx=(3, 0))
        self.slice_btn = ttk.Button(roi_box, text="任意角度线切片", command=self.toggle_slice_mode)
        self.slice_btn.pack(fill="x", pady=(5, 0))
        ttk.Label(roi_box, text="单击主图可锁定 X/Y 剖面；勾选“剖面跟随光束质心”可自动跟随。线切片模式需依次点击两点。",
                  style="Panel.TLabel", foreground="#8493a1", wraplength=220).pack(anchor="w", pady=(5, 0))

    def _build_center(self, parent: ttk.Frame) -> None:
        top = ttk.Frame(parent, style="Panel.TFrame")
        top.pack(fill="x", padx=3, pady=(1, 3))
        ttk.Label(top, text="光束分布 · 2D / 3D / X-Y Profiles", style="Panel.TLabel",
                  font=("Segoe UI", 10, "bold")).pack(side="left")
        self.plot_hint_var = tk.StringVar(value="滚轮缩放 · 拖动十字线 · 点击锁定剖面 / 可开启质心跟随")
        ttk.Label(top, textvariable=self.plot_hint_var, style="Panel.TLabel", foreground="#8392a0").pack(side="right")
        self.figure = Figure(figsize=(12, 8), dpi=95, facecolor="white")
        # Dashboard: give the 2D beam map the largest area; keep 3D and profiles compact.
        self.ax2d = self.figure.add_axes([.045, .375, .55, .545])
        self.ax3d = self.figure.add_axes([.65, .375, .31, .545], projection="3d")
        self.ax_x = self.figure.add_axes([.045, .055, .42, .185])
        self.ax_y = self.figure.add_axes([.515, .055, .445, .185])
        self.base_positions = {ax: ax.get_position().frozen() for ax in (self.ax2d, self.ax3d, self.ax_x, self.ax_y)}
        self.plot_canvas = FigureCanvasTkAgg(self.figure, master=parent)
        self.plot_widget = self.plot_canvas.get_tk_widget()
        self.plot_widget.pack(fill="both", expand=True)
        self.nav_toolbar = NavigationToolbar2Tk(self.plot_canvas, parent, pack_toolbar=False)
        self.nav_toolbar.update()
        self.nav_toolbar.pack(fill="x", side="bottom")
        try:
            self.selector = RectangleSelector(self.ax2d, self._on_roi_selected, useblit=False,
                                              button=[1], minspanx=4, minspany=4,
                                              spancoords="pixels", interactive=False,
                                              props={"facecolor": "#27a0e0", "edgecolor": "#46b8ec", "alpha": .18,
                                                     "fill": True, "linewidth": 1.4})
            self.selector.set_active(False)
        except Exception:
            self.selector = None

    def _build_right_panel(self, parent: ttk.Frame) -> None:
        heading = ttk.Frame(parent, style="Panel.TFrame"); heading.pack(fill="x", pady=(0, 6))
        ttk.Label(heading, text="测量结果", style="Panel.TLabel", font=("Segoe UI", 12, "bold")).pack(side="left")
        self.quality_var = tk.StringVar(value="待分析")
        self.quality_label = tk.Label(heading, textvariable=self.quality_var, bg="#e9eef3", fg="#47637a",
                                      padx=9, pady=4, font=("Segoe UI", 9, "bold"))
        self.quality_label.pack(side="right")
        notebook = ttk.Notebook(parent)
        notebook.pack(fill="both", expand=True)
        summary_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=5)
        detail_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=5)
        record_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=5)
        notebook.add(summary_tab, text="摘要")
        notebook.add(detail_tab, text="进阶")
        notebook.add(record_tab, text="记录")
        self.metric_vars: dict[str, tk.StringVar] = {}

        def add_metrics(parent_frame: ttk.Frame, title: str, items: list[tuple[str, str]]) -> None:
            box = ttk.LabelFrame(parent_frame, text=title, style="Section.TLabelframe", padding=(8, 7))
            box.pack(fill="x", pady=(0, 7))
            for label, key in items:
                row = ttk.Frame(box, style="Panel.TFrame"); row.pack(fill="x", pady=3)
                ttk.Label(row, text=label, style="Panel.TLabel", width=19).pack(side="left", anchor="w")
                var = self.metric_vars.setdefault(key, tk.StringVar(value="—"))
                ttk.Label(row, textvariable=var, style="Panel.TLabel", foreground="#1a5e91",
                          font=("Segoe UI", 9, "bold"), anchor="e").pack(side="right", fill="x", expand=True)

        add_metrics(summary_tab, "光束宽度 / 形状", [
            ("当前质心 X / Y", "center"), ("D4σ X / Y", "d4"), ("D4σ 主轴 / 次轴", "major"),
            ("投影 FWHM X / Y", "fwhm"), ("投影截光宽度 X / Y", "clip"),
            ("椭圆度 / 方向角", "shape"), ("99% 能量直径", "ee99"),
        ])
        add_metrics(summary_tab, "可拖动十字线", [
            ("十字线中心 X / Y", "cross"), ("质心 − 十字线 ΔX / ΔY", "cross_delta"),
            ("质心差距离 ΔR", "cross_dist"),
        ])
        add_metrics(summary_tab, "记录光斑对比", [
            ("参考质心 X / Y", "ref_center"), ("当前 − 参考 ΔX / ΔY", "ref_delta"),
            ("质心差距离 ΔR", "ref_dist"),
        ])
        quality = ttk.LabelFrame(summary_tab, text="图像有效性", style="Section.TLabelframe", padding=(8, 7))
        quality.pack(fill="x", pady=(0, 7))
        self.quality_detail = tk.StringVar(value="导入图像或载入演示光斑后开始分析。")
        ttk.Label(quality, textvariable=self.quality_detail, style="Panel.TLabel", wraplength=270,
                  justify="left").pack(anchor="w")
        self.algo_note = tk.StringVar(value="D4σ 为二阶矩估计；正式 ISO 11146 合规性尚未验证。")
        ttk.Label(quality, textvariable=self.algo_note, style="Panel.TLabel", foreground="#8896a2",
                  wraplength=270, justify="left").pack(anchor="w", pady=(5, 0))
        add_metrics(detail_tab, "拟合 / 采集诊断", [
            ("峰值坐标 X / Y", "peak_xy"), ("Gau. 投影 FWHM X/Y", "gauss"),
            ("Gaussian 拟合 R²", "gauss_r2"), ("Tophat 投影宽度 X/Y", "tophat"),
            ("基线 / 背景 STD", "baseline"), ("峰值 / SNR", "peak_snr"),
            ("饱和像素比例", "sat"), ("视场尺寸 / 平均帧数", "frames"),
        ])
        hist_box = ttk.LabelFrame(detail_tab, text="灰度直方图", style="Section.TLabelframe", padding=(5, 4))
        hist_box.pack(fill="x", pady=(0, 7))
        self.hist_canvas = tk.Canvas(hist_box, height=120, bg="#fbfcfe", highlightthickness=0)
        self.hist_canvas.pack(fill="x", expand=True)
        self.hist_canvas.bind("<Configure>", lambda _e: self._draw_histogram())

        log_box = ttk.LabelFrame(record_tab, text="测量记录 · 尺寸单位 µm", style="Section.TLabelframe", padding=(5, 5))
        log_box.pack(fill="both", expand=True)
        cols = ("time", "cx", "cy", "dx", "dy", "quality")
        self.tree = ttk.Treeview(log_box, columns=cols, show="headings", height=16)
        for col, title, width in (("time", "时间", 72), ("cx", "X µm", 56), ("cy", "Y µm", 56),
                                  ("dx", "D4 X", 56), ("dy", "D4 Y", 56), ("quality", "状态", 48)):
            self.tree.heading(col, text=title); self.tree.column(col, width=width, anchor="center", stretch=False)
        scroll = ttk.Scrollbar(log_box, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        actions = ttk.Frame(record_tab, style="Panel.TFrame"); actions.pack(fill="x", pady=(6, 0))
        ttk.Button(actions, text="记录当前读数", command=self.add_record, style="Primary.TButton").pack(side="left", fill="x", expand=True, padx=(0, 3))
        ttk.Button(actions, text="导出 CSV", command=self.export_log).pack(side="left", padx=3)
        ttk.Button(actions, text="清空", command=self.clear_log).pack(side="left", padx=(3, 0))

    def _connect_plot_events(self) -> None:
        self.plot_canvas.mpl_connect("button_press_event", self._on_plot_click)
        self.plot_canvas.mpl_connect("motion_notify_event", self._on_plot_motion)
        self.plot_canvas.mpl_connect("button_release_event", self._on_plot_release)
        self.plot_canvas.mpl_connect("scroll_event", self._on_plot_scroll)
        self.plot_canvas.mpl_connect("draw_event", self._on_plot_draw)

    @staticmethod
    def _zoom_limits(limits: tuple[float, float], anchor: float, factor: float,
                     bounds: tuple[float, float] | None = None) -> tuple[float, float]:
        descending = limits[0] > limits[1]
        low, high = sorted((float(limits[0]), float(limits[1])))
        new_low = anchor + (low - anchor) * factor
        new_high = anchor + (high - anchor) * factor
        if bounds is not None:
            bound_low, bound_high = sorted(bounds)
            full_span = bound_high - bound_low
            if new_high - new_low >= full_span:
                new_low, new_high = bound_low, bound_high
            else:
                if new_low < bound_low:
                    shift = bound_low - new_low
                    new_low += shift; new_high += shift
                if new_high > bound_high:
                    shift = new_high - bound_high
                    new_low -= shift; new_high -= shift
        return (new_high, new_low) if descending else (new_low, new_high)

    def _on_plot_scroll(self, event: Any) -> None:
        if event.inaxes not in (self.ax2d, self.ax3d, self.ax_x, self.ax_y):
            return
        step = float(getattr(event, "step", 0.0) or 0.0)
        if not step:
            step = 1.0 if getattr(event, "button", "") == "up" else -1.0
        factor = 0.82 ** max(-5.0, min(5.0, step))
        if event.inaxes is self.ax2d and event.xdata is not None and event.ydata is not None:
            scale = self._scale_um_per_px()
            h, w = self.image.shape
            self.ax2d.set_xlim(self._zoom_limits(self.ax2d.get_xlim(), event.xdata, factor, (0, w * scale)))
            self.ax2d.set_ylim(self._zoom_limits(self.ax2d.get_ylim(), event.ydata, factor, (0, h * scale)))
        elif event.inaxes in (self.ax_x, self.ax_y) and event.xdata is not None and event.ydata is not None:
            ax = event.inaxes
            ax.set_xlim(self._zoom_limits(ax.get_xlim(), event.xdata, factor))
            ax.set_ylim(self._zoom_limits(ax.get_ylim(), event.ydata, factor))
        elif event.inaxes is self.ax3d:
            ax = self.ax3d
            for getter, setter in ((ax.get_xlim3d, ax.set_xlim3d),
                                   (ax.get_ylim3d, ax.set_ylim3d),
                                   (ax.get_zlim3d, ax.set_zlim3d)):
                limits = getter()
                setter(self._zoom_limits(limits, (limits[0] + limits[1]) / 2, factor))
        else:
            return
        self.plot_canvas.draw_idle()

    def _options(self) -> AnalysisOptions:
        clip = self._clip_value()
        try:
            manual = float(self.manual_bg.get())
        except ValueError:
            manual = 0.0
        scale = self._input_scale_um_per_px()
        live_step = 3 if self._camera_state == "connected" and self.fast_mode.get() else None
        effective_step = live_step if live_step is not None else (2 if self.fast_mode.get() else 1)
        try:
            smooth_um = max(0.0, float(self.smoothing.get()))
            smooth = int(round(smooth_um / (scale * effective_step)))
        except (TypeError, ValueError):
            smooth = 0
        return AnalysisOptions(subtract_background=self.subtract_bg.get(), lock_background=self.lock_bg.get(),
                               background_value=manual, clip_percent=clip, smoothing_radius=smooth,
                               fast_mode=self.fast_mode.get(), sample_step=live_step,
                               scale_um_per_px=scale)

    def _input_scale_um_per_px(self) -> float:
        try:
            value = float(self.scale_um.get())
            if math.isfinite(value) and value > 0:
                return value
        except (TypeError, ValueError):
            pass
        return DEFAULT_SENSOR_SCALE_UM_PER_PX

    def _scale_um_per_px(self) -> float:
        if self.result is not None and self.result.get("scale_um_per_px"):
            return float(self.result["scale_um_per_px"])
        return self._input_scale_um_per_px()

    def apply_spatial_scale(self) -> None:
        try:
            value = float(self.scale_um.get())
            if not math.isfinite(value) or value <= 0:
                raise ValueError
        except (TypeError, ValueError):
            value = DEFAULT_SENSOR_SCALE_UM_PER_PX
            self.scale_um.set(str(value))
            self.status_var.set(f"标尺无效，已恢复为传感器面默认值 {value:g} µm/格。")
        self._set_source_labels()
        self.schedule_analysis()

    def _clip_value(self) -> float:
        if self.clip_choice.get().startswith("50"):
            return 50.0
        if self.clip_choice.get().startswith("86.5"):
            return 86.5
        if self.clip_choice.get().startswith("自定义"):
            try:
                return float(np.clip(float(self.custom_clip.get()), .5, 99.5))
            except ValueError:
                return 13.5
        return 13.5

    def schedule_analysis(self) -> None:
        self._result_generation = -1
        if self._render_after_id:
            try:
                self.root.after_cancel(self._render_after_id)
            except tk.TclError:
                pass
        self._render_after_id = self.root.after(180, self._refresh_analysis)

    def _refresh_analysis(self) -> None:
        """Run the numerical pass off the Tk thread so large TIFFs stay responsive."""
        self._render_after_id = None
        if self._camera_state == "connected":
            self._camera_analysis_inflight = True
        self._analysis_generation += 1
        generation = self._analysis_generation
        if self._analysis_future is not None and not self._analysis_future.done():
            self._analysis_future.cancel()
        frame = self.image
        white_level = self.white_level
        options = self._options()
        roi = self.roi
        self.status_var.set("正在分析图像… 操作界面仍可继续使用。")
        future = self._analysis_executor.submit(analyze_image, frame, white_level, options, roi)
        self._analysis_future = future
        future.add_done_callback(lambda f, g=generation: self._analysis_queue.put((g, f)))

    def _poll_analysis(self) -> None:
        try:
            while True:
                generation, future = self._analysis_queue.get_nowait()
                if generation != self._analysis_generation:
                    continue
                try:
                    result = future.result()
                except Exception as exc:
                    self._camera_analysis_inflight = False
                    self.status_var.set(f"分析失败：{exc}")
                    self.quality_var.set("需检查")
                    self.quality_detail.set(str(exc))
                    continue
                self.result = result
                self._result_generation = generation
                h, w = self.image.shape
                if self.crosshair_pos is None:
                    self.crosshair_pos = (result["centroid_x"], result["centroid_y"])
                else:
                    self.crosshair_pos = (float(np.clip(self.crosshair_pos[0], 0, w - 1)),
                                          float(np.clip(self.crosshair_pos[1], 0, h - 1)))
                self._update_metrics()
                self._set_source_labels()
                if self._dragging_crosshair:
                    # Keep pointer motion high priority; show the newest frame once
                    # the drag ends instead of redrawing the full plot underneath it.
                    self._live_render_pending = True
                else:
                    self.render()
                scale = float(result.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
                status_text = (f"分析完成 · {self.meta.get('name', '图像')} · "
                               f"{self.image.shape[1]*scale:.0f} × {self.image.shape[0]*scale:.0f} µm · "
                               f"{result['quality']}")
                if self._camera_state == "connected" and result.get("saturated_fraction", 0) > .001:
                    status_text += " · ⚠ 仍有饱和像素：曝光自动正在下调；若持续存在，请切手动降低曝光/增益"
                if self._camera_state == "connected" and self._camera_paused.is_set():
                    status_text = "实时已暂停 · " + status_text
                self.status_var.set(status_text)
                self._camera_analysis_inflight = False
        except queue.Empty:
            pass
        if self.root.winfo_exists():
            self._analysis_poll_id = self.root.after(60, self._poll_analysis)

    def _toggle_profile_follow(self) -> None:
        if self.follow_beam_profiles.get():
            self.profile_anchor = None
            self.slice_profile = None
            self.slice_start = None
            self.slice_mode = False
            if hasattr(self, "slice_btn"):
                self.slice_btn.configure(text="任意角度线切片")
        elif self.result is not None and self.profile_anchor is None:
            # Freeze the current centroid cross-sections when follow is disabled.
            self.profile_anchor = (int(round(self.result["y_profile_x"])),
                                   int(round(self.result["x_profile_y"])))
        if self.result is not None:
            self._refresh_profiles_only()

    def _display_profiles(self) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float, float]:
        assert self.result is not None
        r = self.result
        if self.profile_anchor is None and self.slice_profile is None:
            if self.follow_beam_profiles.get():
                return (r["x_coords"], r["x_profile"], r["y_coords"], r["y_profile"],
                        r["x_profile_y"], r["y_profile_x"])
            return (r["x_coords"], r.get("x_projection", r["x_profile"]),
                    r["y_coords"], r.get("y_projection", r["y_profile"]), float("nan"), float("nan"))
        if self.profile_anchor is None:
            # A line slice may be active without a discrete image click.
            return r["x_coords"], r["x_profile"], r["y_coords"], r["y_profile"], r["x_profile_y"], r["y_profile_x"]
        h, w = self.image.shape
        x0, y0, x1, y1 = self.roi if self.roi else (0, 0, w, h)
        px, py = self.profile_anchor
        px = int(np.clip(px, x0, max(x0, x1 - 1))); py = int(np.clip(py, y0, max(y0, y1 - 1)))
        xcoords = np.arange(x0, x1, dtype=np.float64)
        ycoords = np.arange(y0, y1, dtype=np.float64)
        xprof = self.image[py, x0:x1].astype(np.float32, copy=True)
        yprof = self.image[y0:y1, px].astype(np.float32, copy=True)
        return xcoords, xprof, ycoords, yprof, float(py), float(px)

    def _update_metrics(self) -> None:
        if self.result is None:
            return
        r = self.result
        scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)

        def length(value: Any, digits: int = 2) -> str:
            try:
                number = float(value) * scale
                return f"{number:.{digits}f} µm" if math.isfinite(number) else "—"
            except (TypeError, ValueError):
                return "—"

        self.metric_vars["center"].set(f"{length(r['centroid_x'])} / {length(r['centroid_y'])}")
        self.metric_vars["peak_xy"].set(f"{length(r['peak_x'], 1)} / {length(r['peak_y'], 1)}")
        self.metric_vars["d4"].set(f"{length(r['d4sigma_x'])} · {length(r['d4sigma_y'])}")
        self.metric_vars["major"].set(f"{length(r['d4sigma_major'])} / {length(r['d4sigma_minor'])}")
        self.metric_vars["fwhm"].set(f"{length(r['fwhm_x'])} · {length(r['fwhm_y'])}")
        self.metric_vars["clip"].set(f"{length(r['clip_width_x'])} · {length(r['clip_width_y'])}")
        self.metric_vars["ee99"].set(length(r["encircled_energy_99_diameter"]))
        self.metric_vars["shape"].set(f"{r['ellipticity']:.3f} / {r['orientation_deg']:.2f}°")
        self.metric_vars["gauss"].set(f"{length(r['gaussian_x'].get('fwhm'))} / {length(r['gaussian_y'].get('fwhm'))}")
        self.metric_vars["gauss_r2"].set(f"{_fmt(r['gaussian_x'].get('r2'), 3)} / {_fmt(r['gaussian_y'].get('r2'), 3)}")
        self.metric_vars["tophat"].set(f"{length(r['tophat_x'].get('width'))} / {length(r['tophat_y'].get('width'))}")
        self.metric_vars["baseline"].set(f"{r['baseline']:.2f} / {r['baseline_std']:.2f}")
        self.metric_vars["peak_snr"].set(f"{r['peak']:.1f} / {r['snr']:.1f}")
        self.metric_vars["sat"].set(f"{100*r['saturated_fraction']:.3f}%")
        mode = f"快速 1/{r['fast_step']}" if r["fast_step"] > 1 else "全分辨率"
        field_w = r["width"] * scale; field_h = r["height"] * scale
        self.metric_vars["frames"].set(f"{field_w:.0f} × {field_h:.0f} µm · {self.average_count} 帧 · {mode}")
        if r["quality"] == "良好":
            self.quality_var.set("● 良好"); self.quality_label.configure(bg="#e4f4eb", fg="#24724c")
            self.quality_detail.set("未发现明显饱和、边缘或低信噪比问题。请仍检查原始图像和标定设置。")
        else:
            self.quality_var.set("● 检查"); self.quality_label.configure(bg="#fff0dc", fg="#9a6722")
            self.quality_detail.set("；".join(r["quality_reasons"]) or "请检查图像质量与背景设置。")
        self.algo_note.set(
            f"FWHM/截光宽度按扣背景 X/Y 投影计算（较抗散斑）；实时剖面可随质心更新，点击主图锁定位置。"
            f" 标尺 {scale:g} µm/像素未验证；有镜头倍率时需用已知尺寸重新标定。")
        if self.roi:
            x0, y0, x1, y1 = self.roi
            self.roi_var.set(f"ROI：{x0*scale:.1f}, {y0*scale:.1f} – {x1*scale:.1f}, {y1*scale:.1f} µm · {(x1-x0)*scale:.1f} × {(y1-y0)*scale:.1f} µm")
        else:
            self.roi_var.set("ROI：全视场")
        self._update_crosshair_metrics()
        self._draw_histogram()

    def _update_crosshair_metrics(self) -> None:
        if not hasattr(self, "metric_vars") or not self.result:
            return
        r = self.result
        scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        if self.crosshair_pos is None:
            self.metric_vars["cross"].set("—")
            self.metric_vars["cross_delta"].set("—")
            self.metric_vars["cross_dist"].set("—")
        else:
            xh, yh = self.crosshair_pos
            dx, dy, distance = center_offset((r["centroid_x"], r["centroid_y"]), (xh, yh))
            self.metric_vars["cross"].set(f"{xh*scale:.2f} / {yh*scale:.2f} µm")
            self.metric_vars["cross_delta"].set(f"{dx*scale:+.2f} / {dy*scale:+.2f} µm")
            self.metric_vars["cross_dist"].set(f"{distance*scale:.2f} µm")
        if self.reference_metrics:
            rcx = float(self.reference_metrics["centroid_x"]); rcy = float(self.reference_metrics["centroid_y"])
            self.metric_vars["ref_center"].set(f"{rcx*scale:.2f} / {rcy*scale:.2f} µm")
            same_size = self.reference_image is not None and self.reference_image.shape == self.image.shape
            if same_size:
                dx, dy, distance = center_offset((r["centroid_x"], r["centroid_y"]), (rcx, rcy))
                self.metric_vars["ref_delta"].set(f"{dx*scale:+.2f} / {dy*scale:+.2f} µm")
                self.metric_vars["ref_dist"].set(f"{distance*scale:.2f} µm")
            else:
                self.metric_vars["ref_delta"].set("尺寸不匹配")
                self.metric_vars["ref_dist"].set("不比较")
            if hasattr(self, "reference_status_var") and self.reference_image is not None:
                rh, rw = self.reference_image.shape
                name = (self.reference_meta or {}).get("name", "参考光斑")
                suffix = "" if same_size else " · 尺寸不同，原坐标叠加，不比较偏移"
                self.reference_status_var.set(f"参考：{name} · {rw*scale:.0f} × {rh*scale:.0f} µm{suffix}")
        else:
            self.metric_vars["ref_center"].set("未记录")
            self.metric_vars["ref_delta"].set("—")
            self.metric_vars["ref_dist"].set("—")

    def _draw_histogram(self) -> None:
        if not hasattr(self, "hist_canvas"):
            return
        if self._camera_state == "connected" and self.meta.get("mode") == "MVS":
            now = time.monotonic()
            if now - self._last_histogram_draw < 1.0:
                return
            self._last_histogram_draw = now
        c = self.hist_canvas; c.delete("all")
        width = max(180, c.winfo_width()); height = max(65, c.winfo_height())
        left, right, top, bottom = 26, 8, 7, 17
        plot_w, plot_h = width - left - right, height - top - bottom
        if plot_w <= 10 or plot_h <= 10 or not self.image.size:
            return
        arr = self.image
        if self.roi:
            x0, y0, x1, y1 = self.roi; arr = arr[y0:y1, x0:x1]
        sample = arr[::max(1, int(math.ceil(arr.size / 250_000)))].ravel()
        bins = 72
        hist, _ = np.histogram(sample, bins=bins, range=(0, max(1, self.white_level)))
        values = np.log1p(hist.astype(np.float64)); topv = max(1.0, float(values.max()))
        for g in range(1, 4):
            y = top + plot_h * g / 4
            c.create_line(left, y, left + plot_w, y, fill="#e6ebf0")
        bw = plot_w / bins
        for i, value in enumerate(values):
            bh = plot_h * value / topv
            x0 = left + i * bw
            c.create_rectangle(x0, top + plot_h - bh, x0 + max(1, bw - .5), top + plot_h,
                               fill="#438fbe", outline="")
        if self.result and self.white_level > 0:
            bx = left + plot_w * np.clip(self.result["baseline"] / self.white_level, 0, 1)
            c.create_line(bx, top, bx, top + plot_h, fill="#d68e39", dash=(3, 2), width=1)
        c.create_line(left, top + plot_h, left + plot_w, top + plot_h, fill="#8794a0")
        c.create_text(left, height - 5, text="0", anchor="w", fill="#788795", font=("Segoe UI", 7))
        c.create_text(left + plot_w, height - 5, text=f"{self.white_level:g}", anchor="e", fill="#788795", font=("Segoe UI", 7))

    def _live_render_key(self) -> tuple[Any, ...] | None:
        if (self._camera_state != "connected" or self.meta.get("mode") != "MVS"
                or self.view_mode.get() != "2D + 剖面"):
            return None
        return (tuple(self.image.shape), self.view_mode.get(), self._scale_um_per_px(),
                tuple(self.roi) if self.roi is not None else None,
                tuple(self.profile_anchor) if self.profile_anchor is not None else None,
                bool(self.follow_beam_profiles.get()), self.slice_profile is not None,
                self.slice_start is not None,
                id(self.reference_rgba) if self.reference_rgba is not None else None)

    def _render_live_update(self) -> bool:
        """Update cached live artists instead of clearing/rebuilding the whole figure."""
        key = self._live_render_key()
        if (key is None or key != self._live_render_signature or self.image_artist is None
                or self.beam_ellipse_artist is None or self.centroid_artist is None
                or self.peak_artist is None or not hasattr(self, "colorbar")):
            return False
        try:
            r = self.result
            h, w = self.image.shape
            scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
            stride = self._live_display_stride
            display = self.image[::stride, ::stride]
            if display.shape != np.asarray(self.image_artist.get_array()).shape:
                return False
            if self.auto_contrast.get():
                sample = self.image[::max(1, h // 420), ::max(1, w // 420)]
                vmin = float(np.percentile(sample, .2))
                vmax = float(np.percentile(sample, 99.8))
                if vmax <= vmin:
                    vmax = vmin + 1
                self.vmin_var.set(f"{vmin:.1f}"); self.vmax_var.set(f"{vmax:.1f}")
            else:
                try: vmin = float(self.vmin_var.get())
                except ValueError: vmin = 0.0
                try: vmax = float(self.vmax_var.get())
                except ValueError: vmax = self.white_level
                if vmax <= vmin:
                    vmax = vmin + 1
            self.image_artist.set_data(display)
            cmap_name = self.palette.get() or "inferno"
            if self.image_artist.get_cmap().name != cmap_name:
                self.image_artist.set_cmap(cmap_name)
            if self.image_artist.get_clim() != (vmin, vmax):
                self.image_artist.set_clim(vmin, vmax)

            frac = np.clip(r["clip_percent"] / 100.0, .005, .995)
            factor = math.sqrt(max(.01, -2 * math.log(frac)))
            self.beam_ellipse_artist.set_center((r["centroid_x"] * scale, r["centroid_y"] * scale))
            self.beam_ellipse_artist.set_width(max(scale, r["d4sigma_major"] * scale / 2 * factor))
            self.beam_ellipse_artist.set_height(max(scale, r["d4sigma_minor"] * scale / 2 * factor))
            self.beam_ellipse_artist.set_angle(r["orientation_deg"])
            self.centroid_artist.set_data([r["centroid_x"] * scale], [r["centroid_y"] * scale])
            self.peak_artist.set_data([r["peak_x"] * scale], [r["peak_y"] * scale])
            self._update_crosshair_artists()

            xlim_x, ylim_x = self.ax_x.get_xlim(), self.ax_x.get_ylim()
            xlim_y, ylim_y = self.ax_y.get_xlim(), self.ax_y.get_ylim()
            autoscale_xx, autoscale_yx = self.ax_x.get_autoscalex_on(), self.ax_x.get_autoscaley_on()
            autoscale_xy, autoscale_yy = self.ax_y.get_autoscalex_on(), self.ax_y.get_autoscaley_on()
            xcoords, xprof, ycoords, yprof, x_y, y_x = self._display_profiles()
            if self.slice_profile is not None:
                sc, sv, _p0, _p1 = self.slice_profile
                self._draw_profile(self.ax_x, sc, sv, "Line", float(sc[-1]), r)
            else:
                self._draw_profile(self.ax_x, xcoords, xprof, "X", x_y, r)
            self._draw_profile(self.ax_y, ycoords, yprof, "Y", y_x, r)
            if not autoscale_xx:
                self.ax_x.set_xlim(xlim_x)
            if not autoscale_yx:
                self.ax_x.set_ylim(ylim_x)
            if not autoscale_xy:
                self.ax_y.set_xlim(xlim_y)
            if not autoscale_yy:
                self.ax_y.set_ylim(ylim_y)
            self._crosshair_background = None
            self.plot_canvas.draw_idle()
            return True
        except Exception:
            self._live_render_signature = None
            return False

    def render(self) -> None:
        if self.result is None:
            return
        if self._render_live_update():
            return
        self._live_render_signature = None
        if hasattr(self, "colorbar"):
            try:
                self.colorbar.remove()
            except Exception:
                pass
            del self.colorbar
        r = self.result; h, w = self.image.shape
        scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        cmap_name = self.palette.get() or "inferno"
        if self.auto_contrast.get():
            sample = self.image[::max(1, h // 420), ::max(1, w // 420)]
            vmin = float(np.percentile(sample, .2))
            vmax = float(np.percentile(sample, 99.8))
            if vmax <= vmin:
                vmax = vmin + 1
            self.vmin_var.set(f"{vmin:.1f}"); self.vmax_var.set(f"{vmax:.1f}")
        else:
            try: vmin = float(self.vmin_var.get())
            except ValueError: vmin = 0.0
            try: vmax = float(self.vmax_var.get())
            except ValueError: vmax = self.white_level
            if vmax <= vmin: vmax = vmin + 1
        mode = self.view_mode.get()
        self.ax2d.clear(); self.ax3d.clear(); self.ax_x.clear(); self.ax_y.clear()
        self.image_artist = None; self.beam_ellipse_artist = None
        self.centroid_artist = None; self.peak_artist = None
        self.anchor_artist = None; self.slice_line_artist = None; self.slice_start_artist = None
        self.crosshair_h_artist = None; self.crosshair_v_artist = None; self.crosshair_marker_artist = None
        self.reference_artist = None; self.reference_center_artist = None; self._crosshair_background = None
        for ax, position in self.base_positions.items():
            ax.set_position(position)
        if mode == "2D 图像":
            self.ax2d.set_position([.08, .12, .84, .78])
            for ax in (self.ax3d, self.ax_x, self.ax_y): ax.set_visible(False)
            self.ax2d.set_visible(True)
        elif mode == "3D 表面":
            self.ax3d.set_position([.08, .12, .84, .78])
            for ax in (self.ax2d, self.ax_x, self.ax_y): ax.set_visible(False)
            self.ax3d.set_visible(True)
        elif mode == "剖面":
            self.ax_x.set_position([.08, .56, .84, .32]); self.ax_y.set_position([.08, .12, .84, .32])
            self.ax_x.set_visible(True); self.ax_y.set_visible(True)
            for ax in (self.ax2d, self.ax3d): ax.set_visible(False)
        elif mode == "2D + 剖面":
            self.ax2d.set_position([.045, .385, .90, .535])
            self.ax_x.set_position([.045, .055, .42, .185])
            self.ax_y.set_position([.515, .055, .445, .185])
            self.ax2d.set_visible(True); self.ax_x.set_visible(True); self.ax_y.set_visible(True)
            self.ax3d.set_visible(False)
        else:
            for ax in (self.ax2d, self.ax3d, self.ax_x, self.ax_y): ax.set_visible(True)

        if self.ax2d.get_visible():
            stride = max(1, int(math.ceil(max(h, w) / 900)))
            self._live_display_stride = stride
            display = self.image[::stride, ::stride]
            extent = (0, w * scale, h * scale, 0)
            self.image_artist = self.ax2d.imshow(display, cmap=cmap_name, origin="upper", extent=extent, vmin=vmin,
                                                 vmax=vmax, interpolation="nearest", aspect="auto", zorder=1)
            im = self.image_artist
            if self.reference_rgba is not None and self.reference_image is not None and self.show_reference.get():
                rh, rw = self.reference_image.shape
                self.reference_artist = self.ax2d.imshow(self.reference_rgba, origin="upper",
                    extent=(0, rw * scale, rh * scale, 0), interpolation="nearest", alpha=float(self.reference_opacity.get()),
                    aspect="auto", zorder=4)
                self.reference_artist.set_animated(True)
                if self.reference_metrics:
                    self.reference_center_artist, = self.ax2d.plot(
                        [self.reference_metrics["centroid_x"] * scale], [self.reference_metrics["centroid_y"] * scale],
                        marker="x", color="#ff43d1", ms=8, mew=1.8, linestyle="none", zorder=8)
                    self.reference_center_artist.set_animated(True)
            self.ax2d.set_facecolor("#080a0d")
            self.ax2d.set_title("2D Beam Image", fontsize=9, loc="left", pad=7, color="#273747")
            self.ax2d.set_xlabel("X / µm", fontsize=8); self.ax2d.set_ylabel("Y / µm", fontsize=8)
            self.ax2d.tick_params(labelsize=7)
            self.ax2d.set_xlim(0, w * scale); self.ax2d.set_ylim(h * scale, 0)
            # Clip-level contours are useful offline but expensive to recompute on
            # every live 6 MP frame; the live beam ellipse/centroid remain visible.
            if self.meta.get("mode") != "MVS":
                contour_level = r["baseline"] + (r["peak"] - r["baseline"]) * r["clip_percent"] / 100.0
                if np.min(display) < contour_level < np.max(display):
                    xs = np.linspace(0, w * scale, display.shape[1]); ys = np.linspace(0, h * scale, display.shape[0])
                    try: self.ax2d.contour(xs, ys, display, levels=[contour_level], colors="#f7f7f7", linewidths=.9)
                    except Exception: pass
            frac = np.clip(r["clip_percent"] / 100.0, .005, .995)
            factor = math.sqrt(max(.01, -2 * math.log(frac)))
            self.beam_ellipse_artist = Ellipse((r["centroid_x"] * scale, r["centroid_y"] * scale),
                                               max(scale, r["d4sigma_major"] * scale / 2 * factor),
                                               max(scale, r["d4sigma_minor"] * scale / 2 * factor),
                                               angle=r["orientation_deg"], fill=False, edgecolor="#fff0a8",
                                               linewidth=1.1, linestyle="--")
            self.ax2d.add_patch(self.beam_ellipse_artist)
            self.centroid_artist, = self.ax2d.plot(r["centroid_x"] * scale, r["centroid_y"] * scale,
                                                   marker="+", color="#fff28d", ms=9, mew=1.5,
                                                   linestyle="none")
            self.peak_artist, = self.ax2d.plot(r["peak_x"] * scale, r["peak_y"] * scale,
                                               marker="x", color="#ff756b", ms=6, mew=1.2,
                                               linestyle="none")
            if self.roi:
                x0, y0, x1, y1 = self.roi
                self.ax2d.add_patch(Rectangle((x0*scale, y0*scale), (x1-x0)*scale, (y1-y0)*scale,
                                              fill=False, edgecolor="#77d4ff", linewidth=1.2, linestyle=":"))
            if self.profile_anchor is not None:
                px, py = self.profile_anchor
                self.anchor_artist, = self.ax2d.plot([px*scale], [py*scale], marker="o", mfc="none", mec="#ffffff", ms=6)
            if self.slice_start is not None:
                self.slice_start_artist, = self.ax2d.plot([self.slice_start[0]*scale], [self.slice_start[1]*scale], marker="o", color="#ffffff", ms=5)
            if self.slice_profile:
                _dist, _vals, p0, p1 = self.slice_profile
                self.slice_line_artist, = self.ax2d.plot([p0[0]*scale, p1[0]*scale], [p0[1]*scale, p1[1]*scale], color="#ffffff", linewidth=1.2, linestyle="-")
            if self.crosshair_pos is not None:
                xh, yh = self.crosshair_pos[0] * scale, self.crosshair_pos[1] * scale
                self.crosshair_h_artist = self.ax2d.axhline(yh, color="#71ffe0", linewidth=.85, linestyle="-", alpha=.9, zorder=10)
                self.crosshair_v_artist = self.ax2d.axvline(xh, color="#71ffe0", linewidth=.85, linestyle="-", alpha=.9, zorder=10)
                self.crosshair_marker_artist, = self.ax2d.plot([xh], [yh], marker="+", color="#71ffe0", ms=12, mew=1.8, linestyle="none", zorder=11)
                for artist in (self.crosshair_h_artist, self.crosshair_v_artist, self.crosshair_marker_artist):
                    artist.set_animated(True)
            # The old colorbar is removed at the beginning of render, so each view
            # gets one correctly placed scale without leaving duplicate axes behind.
            self.colorbar = self.figure.colorbar(im, ax=self.ax2d, fraction=.046, pad=.025)
            self.colorbar.ax.tick_params(labelsize=6)

        if self.ax3d.get_visible():
            step3 = max(1, int(math.ceil(max(h, w) / 44)))
            z = self.image[::step3, ::step3].astype(np.float32)
            yy = np.arange(z.shape[0]) * step3 * scale; xx = np.arange(z.shape[1]) * step3 * scale
            X, Y = np.meshgrid(xx, yy)
            self.ax3d.plot_surface(X, Y, z, cmap=cmap_name, linewidth=0, antialiased=False,
                                   rstride=1, cstride=1, vmin=vmin, vmax=vmax)
            self.ax3d.set_facecolor("#f4f6f8")
            self.ax3d.set_title("3D Intensity", fontsize=9, loc="left", pad=5, color="#273747")
            self.ax3d.set_xlabel("X / µm", fontsize=7, labelpad=0); self.ax3d.set_ylabel("Y / µm", fontsize=7, labelpad=0)
            self.ax3d.set_zlabel("Intensity / ADU", fontsize=7, labelpad=1); self.ax3d.tick_params(labelsize=7, pad=0)
            self.ax3d.view_init(elev=31, azim=-58)
            self.ax3d.set_box_aspect((w * scale, h * scale, max(w, h) * scale * .42))

        xcoords, xprof, ycoords, yprof, x_y, y_x = self._display_profiles()
        if self.ax_x.get_visible():
            if self.slice_profile is not None:
                sc, sv, p0, p1 = self.slice_profile
                self._draw_profile(self.ax_x, sc, sv, "Line", float(sc[-1]), r)
            else:
                self._draw_profile(self.ax_x, xcoords, xprof, "X", x_y, r)
        if self.ax_y.get_visible():
            self._draw_profile(self.ax_y, ycoords, yprof, "Y", y_x, r)
        self.plot_canvas.draw_idle()
        self._live_render_signature = self._live_render_key()

    def _refresh_profiles_only(self) -> None:
        """Update click-selected sections without rebuilding the 3D surface or 2D map."""
        if self.result is None:
            return
        scale = float(self.result.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        if self.ax2d.get_visible():
            if self.profile_anchor is not None:
                x, y = self.profile_anchor
                if self.anchor_artist is None:
                    self.anchor_artist, = self.ax2d.plot([x*scale], [y*scale], marker="o", mfc="none", mec="#ffffff", ms=6)
                else:
                    self.anchor_artist.set_data([x*scale], [y*scale])
            elif self.anchor_artist is not None:
                self.anchor_artist.set_data([], [])
            if self.slice_start is not None:
                x, y = self.slice_start
                if self.slice_start_artist is None:
                    self.slice_start_artist, = self.ax2d.plot([x*scale], [y*scale], marker="o", color="#ffffff", ms=5)
                else:
                    self.slice_start_artist.set_data([x*scale], [y*scale])
            elif self.slice_start_artist is not None:
                self.slice_start_artist.set_data([], [])
            if self.slice_profile:
                _dist, _values, p0, p1 = self.slice_profile
                if self.slice_line_artist is None:
                    self.slice_line_artist, = self.ax2d.plot([p0[0]*scale, p1[0]*scale], [p0[1]*scale, p1[1]*scale], color="#ffffff", linewidth=1.2)
                else:
                    self.slice_line_artist.set_data([p0[0]*scale, p1[0]*scale], [p0[1]*scale, p1[1]*scale])
            elif self.slice_line_artist is not None:
                self.slice_line_artist.set_data([], [])
        xcoords, xprof, ycoords, yprof, x_y, y_x = self._display_profiles()
        if self.ax_x.get_visible():
            if self.slice_profile is not None:
                sc, sv, _p0, _p1 = self.slice_profile
                self._draw_profile(self.ax_x, sc, sv, "Line", float(sc[-1]), self.result)
            else:
                self._draw_profile(self.ax_x, xcoords, xprof, "X", x_y, self.result)
        if self.ax_y.get_visible():
            self._draw_profile(self.ax_y, ycoords, yprof, "Y", y_x, self.result)
        self.plot_canvas.draw_idle()
        self._live_render_signature = self._live_render_key()

    def _draw_profile(self, ax: Any, coords: np.ndarray, profile: np.ndarray, axis_name: str,
                      anchor: float, result: dict[str, Any]) -> None:
        ax.clear()
        if coords.size == 0 or profile.size == 0:
            return
        scale = float(result.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        coords_um = coords * scale
        anchor_um = anchor * scale
        is_projection = axis_name in ("X", "Y") and not math.isfinite(anchor)
        baseline = 0.0 if is_projection else (result["baseline"] if self.subtract_bg.get() else 0.0)
        ax.set_facecolor("#ffffff")
        ax.plot(coords_um, profile, color="#263746", linewidth=1.15, label="Image")
        ax.axhline(baseline, color="#aab4bd", linewidth=.55, linestyle=":", label="_nolegend_")
        if math.isfinite(anchor_um):
            ax.axvline(anchor_um, color="#b5bec6", linewidth=.55, linestyle=":", label="_nolegend_")
        if self.show_fit.get():
            fit = _fit_gaussian(profile, coords_um, baseline)
            if fit.get("valid"):
                curve = baseline + float(fit["amplitude"]) * np.exp(-.5 * ((coords_um - float(fit["center"])) / float(fit["sigma"])) ** 2)
                ax.plot(coords_um, curve, color="#c7433d", linewidth=1.25, label="Gaussian")
        if self.show_tophat.get():
            top = _top_hat_fit(profile, coords_um, baseline)
            if top.get("valid"):
                left = float(top["center"]) - float(top["width"]) / 2
                right = float(top["center"]) + float(top["width"]) / 2
                model = np.full(profile.shape, baseline, dtype=np.float32)
                model[(coords_um >= left) & (coords_um <= right)] = float(top["plateau"])
                ax.step(coords_um, model, where="mid", color="#8064a2", linewidth=1.0, label="Top-hat")
        if axis_name == "Line":
            ax.set_title(f"Line slice · {anchor_um:.1f} µm", fontsize=7, loc="left", pad=4)
            ax.set_xlabel("Distance / µm", fontsize=7)
        elif axis_name == "X":
            title = "X projection · mean across ROI" if is_projection else f"X profile · y = {anchor_um:.1f} µm"
            ax.set_title(title, fontsize=7, loc="left", pad=4)
            ax.set_xlabel("X / µm", fontsize=7)
        else:
            title = "Y projection · mean across ROI" if is_projection else f"Y profile · x = {anchor_um:.1f} µm"
            ax.set_title(title, fontsize=7, loc="left", pad=4)
            ax.set_xlabel("Y / µm", fontsize=7)
        ax.set_ylabel("Mean intensity / ADU" if is_projection else "Intensity / ADU", fontsize=7)
        ax.tick_params(labelsize=7, colors="#5c6872")
        ax.grid(True, axis="y", color="#edf0f3", linewidth=.55)
        ax.margins(x=.01, y=.10)
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(handles, labels, loc="lower right", bbox_to_anchor=(1.0, 1.02),
                      fontsize=6, frameon=False, ncol=min(3, len(handles)),
                      handlelength=1.25, columnspacing=.9, borderaxespad=0.0)

    def _on_plot_click(self, event: Any) -> None:
        if self.roi_selecting or event.inaxes is not self.ax2d or event.xdata is None or event.ydata is None:
            return
        if event.button not in (1, None) or getattr(self.nav_toolbar, "mode", ""):
            return
        h, w = self.image.shape
        scale = self._scale_um_per_px()
        x = float(np.clip(event.xdata / scale, 0, w - 1)); y = float(np.clip(event.ydata / scale, 0, h - 1))
        if self.crosshair_pos is not None and self.ax2d.get_visible():
            marker_px = self.ax2d.transData.transform((self.crosshair_pos[0] * scale, self.crosshair_pos[1] * scale))
            if float(np.hypot(event.x - marker_px[0], event.y - marker_px[1])) <= 16.0:
                self._dragging_crosshair = True
                self.status_var.set("正在拖动十字线；差值按当前强度质心 − 十字线坐标计算。")
                return
        if self.slice_mode:
            if self.slice_start is None:
                self.slice_start = (x, y)
                self.plot_hint_var.set(f"切片起点 {x*scale:.1f}, {y*scale:.1f} µm；再点终点")
            else:
                start = self.slice_start
                dx, dy = x - start[0], y - start[1]
                length = float(np.hypot(dx, dy))
                n = int(np.clip(np.ceil(length * 1.5) + 1, 2, 6000))
                xs = np.linspace(start[0], x, n); ys = np.linspace(start[1], y, n)
                x0 = np.floor(xs).astype(int); y0 = np.floor(ys).astype(int)
                x1 = np.clip(x0 + 1, 0, w - 1); y1 = np.clip(y0 + 1, 0, h - 1)
                x0 = np.clip(x0, 0, w - 1); y0 = np.clip(y0, 0, h - 1)
                fx = xs - x0; fy = ys - y0
                a = self.image[y0, x0] * (1 - fx) * (1 - fy)
                b = self.image[y0, x1] * fx * (1 - fy)
                c = self.image[y1, x0] * (1 - fx) * fy
                d = self.image[y1, x1] * fx * fy
                distance = np.linspace(0, length, n)
                self.slice_profile = (distance, (a + b + c + d).astype(np.float32), start, (x, y))
                self.slice_mode = False; self.slice_start = None
                self.slice_btn.configure(text="任意角度线切片")
                self.plot_hint_var.set(f"任意线切片：长度 {length*scale:.1f} µm")
            self.profile_anchor = None
            self._refresh_profiles_only()
            return
        self.slice_profile = None; self.slice_start = None
        self.follow_beam_profiles.set(False)
        self.profile_anchor = (int(round(x)), int(round(y)))
        self.plot_hint_var.set(f"剖面位置：X {x*scale:.1f} µm · Y {y*scale:.1f} µm（质心结果未改变）")
        self._refresh_profiles_only()

    def _on_plot_motion(self, event: Any) -> None:
        if not self._dragging_crosshair or event.inaxes is not self.ax2d or event.xdata is None or event.ydata is None:
            return
        h, w = self.image.shape
        scale = self._scale_um_per_px()
        self.crosshair_pos = (float(np.clip(event.xdata / scale, 0, w - 1)),
                              float(np.clip(event.ydata / scale, 0, h - 1)))
        self._update_crosshair_artists()
        self._update_crosshair_metrics()
        self._blit_crosshair()

    def _on_plot_release(self, event: Any) -> None:
        if self._dragging_crosshair:
            self._dragging_crosshair = False
            if self.crosshair_pos:
                x, y = self.crosshair_pos
                scale = self._scale_um_per_px()
                self.status_var.set(f"十字线：X {x*scale:.2f} µm，Y {y*scale:.2f} µm；偏差已更新。")
            if self._live_render_pending:
                self._live_render_pending = False
                try:
                    self.root.after_idle(self.render)
                except tk.TclError:
                    pass

    def _update_crosshair_artists(self) -> None:
        if self.crosshair_pos is None:
            return
        scale = self._scale_um_per_px()
        x, y = self.crosshair_pos[0] * scale, self.crosshair_pos[1] * scale
        if self.crosshair_h_artist is None or self.crosshair_v_artist is None or self.crosshair_marker_artist is None:
            return
        self.crosshair_h_artist.set_ydata([y, y])
        self.crosshair_v_artist.set_xdata([x, x])
        self.crosshair_marker_artist.set_data([x], [y])

    def _on_plot_draw(self, _event: Any) -> None:
        if not hasattr(self, "ax2d") or not self.ax2d.get_visible():
            self._crosshair_background = None
            return
        try:
            self._crosshair_background = self.plot_canvas.copy_from_bbox(self.ax2d.bbox)
            self._blit_crosshair()
        except Exception:
            self._crosshair_background = None

    def _blit_crosshair(self) -> None:
        if self._crosshair_background is None or not self.ax2d.get_visible():
            if hasattr(self, "plot_canvas"):
                self.plot_canvas.draw_idle()
            return
        artists = (self.reference_artist, self.reference_center_artist, self.crosshair_h_artist,
                   self.crosshair_v_artist, self.crosshair_marker_artist)
        artists = tuple(artist for artist in artists if artist is not None and artist.get_visible())
        if not artists:
            return
        try:
            self.plot_canvas.restore_region(self._crosshair_background)
            for artist in artists:
                self.ax2d.draw_artist(artist)
            self.plot_canvas.blit(self.ax2d.bbox)
        except Exception:
            self.plot_canvas.draw_idle()

    def reset_crosshair(self) -> None:
        if self.result is None:
            return
        self.crosshair_pos = (self.result["centroid_x"], self.result["centroid_y"])
        self._update_crosshair_artists()
        self._update_crosshair_metrics()
        if self.crosshair_marker_artist is None:
            self.render()
        else:
            self._blit_crosshair()
        self.status_var.set("十字线已放回当前强度质心。")

    def toggle_slice_mode(self) -> None:
        if self.slice_mode:
            self.slice_mode = False; self.slice_start = None
            self.slice_btn.configure(text="任意角度线切片")
            self.plot_hint_var.set("任意线切片已取消")
        else:
            self.set_roi_mode(False)
            self.slice_mode = True; self.slice_start = None; self.slice_profile = None
            self.slice_btn.configure(text="取消线切片")
            self.plot_hint_var.set("在线图上依次点击切片起点与终点")
        self._refresh_profiles_only()

    def set_roi_mode(self, active: bool) -> None:
        self.roi_selecting = bool(active)
        if active and self.slice_mode:
            self.slice_mode = False; self.slice_start = None
            self.slice_btn.configure(text="任意角度线切片")
        if self.selector is not None:
            self.selector.set_active(self.roi_selecting)
        self.roi_btn.configure(text="完成框选" if self.roi_selecting else "框选 ROI")
        self.status_var.set("在 2D 图中拖曳框选 ROI；按 Esc 取消。" if self.roi_selecting else "ROI 框选已关闭。")

    def _on_roi_selected(self, eclick: Any, erelease: Any) -> None:
        if not self.roi_selecting or eclick.xdata is None or erelease.xdata is None:
            return
        h, w = self.image.shape
        scale = self._scale_um_per_px()
        x0 = int(np.clip(min(eclick.xdata, erelease.xdata) / scale, 0, w - 1))
        x1 = int(np.clip(max(eclick.xdata, erelease.xdata) / scale, x0 + 1, w))
        y0 = int(np.clip(min(eclick.ydata, erelease.ydata) / scale, 0, h - 1))
        y1 = int(np.clip(max(eclick.ydata, erelease.ydata) / scale, y0 + 1, h))
        self.roi = (x0, y0, x1, y1)
        self.profile_anchor = None
        self.set_roi_mode(False)
        self._refresh_analysis()

    def clear_roi(self) -> None:
        self.roi = None; self.profile_anchor = None
        self.set_roi_mode(False); self._refresh_analysis()

    def set_fast(self, enabled: bool) -> None:
        self.fast_mode.set(bool(enabled)); self._refresh_analysis()

    def open_image(self) -> None:
        path = filedialog.askopenfilename(parent=self.root, title="打开光斑图像",
            filetypes=(("图像文件", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"), ("所有文件", "*.*")))
        if not path: return
        try:
            image, white, meta = load_grayscale(path)
            if self._camera_state == "connected":
                self._disconnect_camera()
            self.image, self.white_level, self.meta = image, white, meta
            self.source_paths = [str(path)]; self.average_count = 1
            self._reset_analysis_selection()
            self._set_source_labels(); self._refresh_analysis()
        except Exception as exc:
            messagebox.showerror("无法打开图像", str(exc), parent=self.root)

    def average_image_stack(self) -> None:
        paths = filedialog.askopenfilenames(parent=self.root, title="选择多张同尺寸图像进行帧平均",
            filetypes=(("图像文件", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"), ("所有文件", "*.*")))
        if not paths: return
        try:
            loaded = [load_grayscale(p) for p in paths]
            shapes = {item[0].shape for item in loaded}
            if len(shapes) != 1:
                raise ValueError("所选图像尺寸不一致。请选取相同分辨率的帧后再平均。")
            if self._camera_state == "connected":
                self._disconnect_camera()
            self.image = average_frames([item[0] for item in loaded])
            self.white_level = max(item[1] for item in loaded)
            self.meta = {"path": "", "name": f"帧平均 · {len(paths)} 张", "mode": "AVERAGED",
                         "width": int(self.image.shape[1]), "height": int(self.image.shape[0]),
                         "bit_depth": max(item[2]["bit_depth"] for item in loaded)}
            self.source_paths = [str(p) for p in paths]; self.average_count = len(paths)
            self._reset_analysis_selection()
            self._set_source_labels(); self._refresh_analysis()
        except Exception as exc:
            messagebox.showerror("多帧平均失败", str(exc), parent=self.root)

    def load_demo(self) -> None:
        if self._camera_state == "connected":
            self._disconnect_camera()
        self.image, self.white_level, self.meta = make_demo_beam(seed=int(datetime.now().timestamp()) % 100000)
        self.source_paths = []; self.average_count = 1; self._reset_analysis_selection()
        self.fast_mode.set(False); self._set_source_labels(); self._refresh_analysis()

    def _reset_analysis_selection(self) -> None:
        self.roi = None; self.profile_anchor = None; self.slice_mode = False
        self.slice_start = None; self.slice_profile = None; self.roi_selecting = False
        self.follow_beam_profiles.set(False)
        if hasattr(self, "slice_btn"):
            self.slice_btn.configure(text="任意角度线切片")
        if hasattr(self, "roi_btn"):
            self.roi_btn.configure(text="框选 ROI")
        if getattr(self, "selector", None) is not None:
            self.selector.set_active(False)

    def _set_source_labels(self) -> None:
        self.source_name_var.set(self.meta.get("name", "图像"))
        bd = self.meta.get("bit_depth", 8)
        scale = self._input_scale_um_per_px()
        self.source_info_var.set(f"视场 {self.image.shape[1]*scale:.0f} × {self.image.shape[0]*scale:.0f} µm · {bd}-bit · 最大灰阶 {self.white_level:g}")
        self.average_var.set(str(self.average_count))

    def save_tiff(self) -> None:
        path = filedialog.asksaveasfilename(parent=self.root, title="保存分析用灰度帧", defaultextension=".tif",
            filetypes=(("TIFF", "*.tif"), ("PNG", "*.png")))
        if not path: return
        try:
            if self.white_level > 255:
                arr = np.clip(self.image, 0, 65535).astype(np.uint16)
                im = Image.fromarray(arr)
            else:
                arr = np.clip(self.image, 0, 255).astype(np.uint8)
                im = Image.fromarray(arr)
            im.save(path)
            self.status_var.set(f"已保存灰度帧：{path}")
        except Exception as exc:
            messagebox.showerror("保存失败", str(exc), parent=self.root)

    def _csv_rows(self) -> list[list[Any]]:
        if self.result is None: return []
        r = self.result
        scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        um = lambda value: float(value) * scale
        cross_dx = cross_dy = cross_dist = ""
        if self.crosshair_pos is not None:
            dx, dy, distance = center_offset((r["centroid_x"], r["centroid_y"]), self.crosshair_pos)
            cross_dx, cross_dy, cross_dist = um(dx), um(dy), um(distance)
        ref_dx = ref_dy = ref_dist = ref_cx = ref_cy = ""
        if self.reference_metrics:
            ref_cx, ref_cy = um(self.reference_metrics["centroid_x"]), um(self.reference_metrics["centroid_y"])
            if self.reference_image is not None and self.reference_image.shape == self.image.shape:
                dx, dy, distance = center_offset((r["centroid_x"], r["centroid_y"]),
                                                 (self.reference_metrics["centroid_x"], self.reference_metrics["centroid_y"]))
                ref_dx, ref_dy, ref_dist = um(dx), um(dy), um(distance)
        rows: list[list[Any]] = [["项目", "值", "单位"],
            ["图像", self.meta.get("name", ""), ""], ["宽度", um(r["width"]), "µm"], ["高度", um(r["height"]), "µm"],
            ["质心 X", um(r["centroid_x"]), "µm"], ["质心 Y", um(r["centroid_y"]), "µm"],
            ["十字线 X", um(self.crosshair_pos[0]) if self.crosshair_pos else "", "µm"],
            ["十字线 Y", um(self.crosshair_pos[1]) if self.crosshair_pos else "", "µm"],
            ["质心 - 十字线 ΔX", cross_dx, "µm"], ["质心 - 十字线 ΔY", cross_dy, "µm"],
            ["质心 - 十字线 ΔR", cross_dist, "µm"],
            ["参考质心 X", ref_cx, "µm"], ["参考质心 Y", ref_cy, "µm"],
            ["当前 - 参考 ΔX", ref_dx, "µm"], ["当前 - 参考 ΔY", ref_dy, "µm"], ["当前 - 参考 ΔR", ref_dist, "µm"],
            ["峰值坐标 X", um(r["peak_x"]), "µm"], ["峰值坐标 Y", um(r["peak_y"]), "µm"],
            ["D4σ X", um(r["d4sigma_x"]), "µm"], ["D4σ Y", um(r["d4sigma_y"]), "µm"],
            ["D4σ 主轴", um(r["d4sigma_major"]), "µm"], ["D4σ 次轴", um(r["d4sigma_minor"]), "µm"],
            ["方向角", r["orientation_deg"], "deg"], ["椭圆度", r["ellipticity"], ""],
            ["FWHM X", um(r["fwhm_x"]), "µm"], ["FWHM Y", um(r["fwhm_y"]), "µm"],
            [f"截光宽度 X ({r['clip_percent']}%)", um(r["clip_width_x"]), "µm"],
            [f"截光宽度 Y ({r['clip_percent']}%)", um(r["clip_width_y"]), "µm"],
            ["99% 包围能量直径", um(r["encircled_energy_99_diameter"]), "µm"],
            ["背景基线", r["baseline"], "灰度"], ["背景 STD", r["baseline_std"], "灰度"],
            ["峰值", r["peak"], "灰度"], ["SNR 估计", r["snr"], ""],
            ["饱和比例", r["saturated_fraction"], "fraction"], ["帧质量", r["quality"], ""],
            ["平均帧数", self.average_count, "frames"], ["快速模式", r["fast_step"] > 1, ""],
            ["空间标尺", scale, "µm/格"], [],
        ]
        projection_view = getattr(self, "profile_anchor", None) is None and getattr(self, "slice_profile", None) is None
        x_name = "X projection coordinate" if projection_view else "X profile coordinate"
        y_name = "Y projection coordinate" if projection_view else "Y profile coordinate"
        profile_unit = "Mean intensity / ADU" if projection_view else "Intensity / ADU"
        rows.append([x_name, profile_unit, "µm"])
        xcoords, xprof, ycoords, yprof, _a, _b = self._display_profiles()
        rows.extend([[um(x), float(v), "µm"] for x, v in zip(xcoords, xprof)])
        rows.extend([[], [y_name, profile_unit, "µm"]])
        rows.extend([[um(y), float(v), "µm"] for y, v in zip(ycoords, yprof)])
        if self.slice_profile:
            dist, values, _p0, _p1 = self.slice_profile
            rows.extend([[], ["Line slice distance", "Intensity / ADU", "µm"]])
            rows.extend([[um(d), float(v), "µm"] for d, v in zip(dist, values)])
        return rows

    def export_csv(self) -> None:
        if self.result is None: return
        path = filedialog.asksaveasfilename(parent=self.root, title="导出测量数据", defaultextension=".csv",
            filetypes=(("CSV", "*.csv"),))
        if not path: return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                csv.writer(f).writerows(self._csv_rows())
            self.status_var.set(f"CSV 已导出：{path}")
        except Exception as exc:
            messagebox.showerror("导出失败", str(exc), parent=self.root)

    def export_log(self) -> None:
        if not self.records:
            messagebox.showinfo("测量记录", "目前没有记录。", parent=self.root); return
        path = filedialog.asksaveasfilename(parent=self.root, title="导出测量记录", defaultextension=".csv",
            filetypes=(("CSV", "*.csv"),))
        if not path: return
        source_fields = ["time", "image", "centroid_x", "centroid_y", "d4sigma_x", "d4sigma_y", "fwhm_x", "fwhm_y",
                         "ellipticity", "orientation_deg", "cross_delta_x", "cross_delta_y", "cross_distance",
                         "reference_delta_x", "reference_delta_y", "reference_distance", "quality"]
        output_fields = ["time", "image", "centroid_x_um", "centroid_y_um", "d4sigma_x_um", "d4sigma_y_um",
                         "fwhm_x_um", "fwhm_y_um", "ellipticity", "orientation_deg", "cross_delta_x_um",
                         "cross_delta_y_um", "cross_distance_um", "reference_delta_x_um", "reference_delta_y_um",
                         "reference_distance_um", "quality"]
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f); writer.writerow(output_fields)
            for rec in self.records:
                writer.writerow([rec.get(key, "") for key in source_fields])
        self.status_var.set(f"记录 CSV 已导出：{path}")

    def export_report(self) -> None:
        if self.result is None: return
        path = filedialog.asksaveasfilename(parent=self.root, title="生成独立 HTML 测量报告", defaultextension=".html",
            filetypes=(("HTML", "*.html"),))
        if not path: return
        try:
            self.plot_canvas.draw()
            dynamic = [self.reference_artist, self.reference_center_artist, self.crosshair_h_artist,
                       self.crosshair_v_artist, self.crosshair_marker_artist]
            animation_state = [(artist, artist.get_animated()) for artist in dynamic if artist is not None]
            for artist, _state in animation_state: artist.set_animated(False)
            buf = io.BytesIO()
            try:
                self.figure.savefig(buf, format="png", dpi=130, bbox_inches="tight")
            finally:
                for artist, state in animation_state: artist.set_animated(state)
                self.plot_canvas.draw_idle()
            image64 = base64.b64encode(buf.getvalue()).decode("ascii")
            r = self.result
            scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
            labels = [("视场宽 / 高", f"{r['width']*scale:.2f} / {r['height']*scale:.2f} µm"),
                      ("空间标尺", f"{scale:g} µm/格"),
                      ("质心 X / Y", f"{r['centroid_x']*scale:.3f} / {r['centroid_y']*scale:.3f} µm"),
                      ("十字线中心 X / Y", self.metric_vars["cross"].get()),
                      ("质心 − 十字线 ΔX / ΔY", self.metric_vars["cross_delta"].get()),
                      ("中心 − 十字线 ΔR", self.metric_vars["cross_dist"].get()),
                      ("当前质心 − 参考质心 ΔX / ΔY", self.metric_vars["ref_delta"].get()),
                      ("当前质心 − 参考质心 ΔR", self.metric_vars["ref_dist"].get()),
                      ("D4σ X / Y", f"{r['d4sigma_x']*scale:.3f} / {r['d4sigma_y']*scale:.3f} µm"),
                      ("FWHM X / Y", f"{r['fwhm_x']*scale:.3f} / {r['fwhm_y']*scale:.3f} µm"),
                      ("D4σ 主轴 / 次轴", f"{r['d4sigma_major']*scale:.3f} / {r['d4sigma_minor']*scale:.3f} µm"),
                      ("椭圆度 / 方向角", f"{r['ellipticity']:.4f} / {r['orientation_deg']:.3f}°"),
                      ("背景基线 / STD", f"{r['baseline']:.3f} / {r['baseline_std']:.3f}"),
                      ("SNR / 饱和比例", f"{r['snr']:.2f} / {r['saturated_fraction']*100:.4f}%"),
                      ("99% 包围能量直径", f"{r['encircled_energy_99_diameter']*scale:.3f} µm"),
                      ("质量提示", r["quality"] + ("：" + "；".join(r["quality_reasons"]) if r["quality_reasons"] else ""))]
            table = "".join(f"<tr><th>{html.escape(k)}</th><td>{html.escape(v)}</td></tr>" for k,v in labels)
            report = f"""<!doctype html><html lang='zh-CN'><meta charset='utf-8'><title>SpotLab 测量报告</title>
            <style>body{{font-family:Segoe UI,Microsoft YaHei,sans-serif;margin:32px;color:#203040}}h1{{font-size:24px}}.note{{padding:12px;background:#fff5e5;border-left:4px solid #e2a245}}img{{max-width:100%;border:1px solid #ddd}}table{{border-collapse:collapse;width:100%;max-width:780px;margin:16px 0}}td,th{{border:1px solid #dce3e9;padding:8px;text-align:left}}th{{background:#f4f7fa;width:230px}}</style>
            <h1>光束分析测量报告</h1><p>生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} · 数据源：{html.escape(str(self.meta.get('name','')))}</p>
            <div class='note'>离线图像分析结果。D4σ 为本软件二阶矩计算；未经过您的相机、光学配置和标准样品验证，不应直接作为认证测量。</div>
            <h2>测量参数</h2><table>{table}</table><h2>二维图像与剖面</h2><img src='data:image/png;base64,{image64}'></html>"""
            Path(path).write_text(report, encoding="utf-8")
            self.status_var.set(f"HTML 报告已保存：{path}")
        except Exception as exc:
            messagebox.showerror("生成报告失败", str(exc), parent=self.root)

    def save_project(self) -> None:
        path = filedialog.asksaveasfilename(parent=self.root, title="保存 SpotLab 项目", defaultextension=".beamproj",
            filetypes=(("SpotLab project", "*.beamproj"), ("JSON", "*.json")))
        if not path: return
        project_path = Path(path)
        frame_path = project_path.with_name(project_path.stem + "_frame.tif")
        reference_path = project_path.with_name(project_path.stem + "_reference.tif")
        try:
            self._save_gray_to_path(frame_path)
            if self.reference_image is not None:
                self._save_gray_to_path(reference_path, self.reference_image, self.reference_white_level)
            options = self._options()
            project = {"app": "SpotLab", "version": "0.7.4", "frame_file": frame_path.name,
                       "source_name": self.meta.get("name", ""), "white_level": self.white_level,
                       "crosshair_pos": list(self.crosshair_pos) if self.crosshair_pos else None,
                       "reference_frame": reference_path.name if self.reference_image is not None else None,
                       "reference_white_level": self.reference_white_level if self.reference_image is not None else None,
                       "reference_metrics": self.reference_metrics,
                       "reference_meta": self.reference_meta,
                       "show_reference": bool(self.show_reference.get()),
                       "reference_opacity": float(self.reference_opacity.get()),
                       "camera_preset": self._camera_preset(),
                       "roi": list(self.roi) if self.roi else None,
                       "settings": {"subtract_background": options.subtract_background,
                                    "lock_background": options.lock_background,
                                    "background_value": options.background_value,
                                    "clip_percent": options.clip_percent,
                                    "smoothing_radius": options.smoothing_radius,
                                    "smoothing_radius_um": float(self.smoothing.get()),
                                    "fast_mode": options.fast_mode,
                                    "scale_um_per_px": options.scale_um_per_px,
                                    "palette": self.palette.get(), "view_mode": self.view_mode.get(),
                                    "show_fit": self.show_fit.get(), "show_tophat": self.show_tophat.get()},
                       "records": self.records}
            project_path.write_text(json.dumps(project, ensure_ascii=False, indent=2), encoding="utf-8")
            self.status_var.set(f"项目已保存：{project_path.name}（附带灰度帧 {frame_path.name}）")
        except Exception as exc:
            messagebox.showerror("保存项目失败", str(exc), parent=self.root)

    def open_project(self) -> None:
        path = filedialog.askopenfilename(parent=self.root, title="打开 SpotLab 项目",
            filetypes=(("SpotLab project", "*.beamproj *.json"), ("所有文件", "*.*")))
        if not path: return
        try:
            p = Path(path); project = json.loads(p.read_text(encoding="utf-8"))
            if self._camera_state == "connected":
                self._disconnect_camera()
            frame_path = p.parent / project["frame_file"]
            self.image, loaded_white_level, self.meta = load_grayscale(frame_path)
            self.white_level = float(project.get("white_level", loaded_white_level))
            self.meta["name"] = project.get("source_name", frame_path.name)
            self.source_paths = [str(frame_path)]; self.average_count = 1
            self.profile_anchor = None; self.slice_mode = False; self.slice_start = None; self.slice_profile = None
            self.follow_beam_profiles.set(False)
            self.roi_selecting = False; self.roi = tuple(project["roi"]) if project.get("roi") else None
            self.slice_btn.configure(text="任意角度线切片"); self.roi_btn.configure(text="框选 ROI")
            if self.selector is not None: self.selector.set_active(False)
            self.crosshair_pos = tuple(project["crosshair_pos"]) if project.get("crosshair_pos") else None
            ref_file = project.get("reference_frame")
            if ref_file and (p.parent / ref_file).exists():
                self.reference_image, loaded_ref_white, loaded_ref_meta = load_grayscale(p.parent / ref_file)
                self.reference_white_level = float(project.get("reference_white_level", loaded_ref_white))
                self.reference_meta = project.get("reference_meta") or loaded_ref_meta
                self.reference_metrics = project.get("reference_metrics")
                self.reference_metrics = ({k: float(v) for k, v in self.reference_metrics.items()}
                                          if self.reference_metrics else None)
                if self.reference_metrics:
                    self.reference_rgba = self._build_reference_display_overlay(
                        self.reference_image, self.reference_metrics)
                else:
                    self.reference_rgba = None
                self.reference_status_var.set(f"参考：{self.reference_meta.get('name', '光斑')} · 已载入")
            else:
                self.reference_image = None; self.reference_rgba = None
                self.reference_metrics = None; self.reference_meta = None
                self.reference_status_var.set("尚未记录参考光斑")
            self.show_reference.set(bool(project.get("show_reference", True)))
            self.reference_opacity.set(float(project.get("reference_opacity", .38)))
            self.reference_opacity_text.set(f"{round(self.reference_opacity.get()*100):d}%")
            self._restore_camera_preset(project.get("camera_preset"))
            s = project.get("settings", {})
            self.subtract_bg.set(bool(s.get("subtract_background", True)))
            self.lock_bg.set(bool(s.get("lock_background", False)))
            self.manual_bg.set(str(s.get("background_value", 0)))
            self.clip_choice.set("自定义" if s.get("clip_percent") not in (13.5, 50.0, 86.5) else
                                 {13.5: "13.5% · 1/e²", 50.0: "50% · FWHM", 86.5: "86.5%"}.get(s.get("clip_percent"), "13.5% · 1/e²"))
            self.custom_clip.set(str(s.get("clip_percent", 13.5)))
            saved_scale = float(s.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
            self.scale_um.set(str(saved_scale))
            if "smoothing_radius_um" in s:
                smoothing_um = float(s["smoothing_radius_um"])
            else:
                smoothing_um = float(s.get("smoothing_radius", 0)) * saved_scale
            self.smoothing.set(f"{smoothing_um:g}")
            self.fast_mode.set(bool(s.get("fast_mode", False)))
            self.palette.set(s.get("palette", "turbo")); self.view_mode.set(s.get("view_mode", "2D + 剖面"))
            self.show_fit.set(bool(s.get("show_fit", True)))
            self.show_tophat.set(bool(s.get("show_tophat", False)))
            self.records = project.get("records", [])
            for record in self.records:
                if not isinstance(record, dict) or record.get("unit") == "µm":
                    continue
                for key in ("centroid_x", "centroid_y", "d4sigma_x", "d4sigma_y", "fwhm_x", "fwhm_y",
                            "cross_delta_x", "cross_delta_y", "cross_distance", "reference_delta_x",
                            "reference_delta_y", "reference_distance"):
                    try:
                        record[key] = float(record[key]) * saved_scale
                    except (KeyError, TypeError, ValueError):
                        pass
                record["unit"] = "µm"
            self._rebuild_log(); self._set_source_labels(); self._refresh_analysis()
        except Exception as exc:
            messagebox.showerror("打开项目失败", str(exc), parent=self.root)

    def _save_gray_to_path(self, path: Path, image: np.ndarray | None = None,
                           white_level: float | None = None) -> None:
        data = self.image if image is None else image
        white = self.white_level if white_level is None else float(white_level)
        source_meta = self.meta if image is None else (self.reference_meta or {})
        bit_depth = int(source_meta.get("bit_depth", 16 if white > 255 else 8))
        if bit_depth >= 32:
            im = Image.fromarray(np.asarray(data, dtype=np.float32))
        elif white > 255:
            im = Image.fromarray(np.clip(data, 0, 65535).astype(np.uint16))
        else:
            im = Image.fromarray(np.clip(data, 0, 255).astype(np.uint8))
        im.save(path, format="TIFF")

    def add_record(self) -> None:
        if self.result is None: return
        r = self.result
        scale = float(r.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        cross_dx = cross_dy = cross_dist = ref_dx = ref_dy = ref_dist = ""
        if self.crosshair_pos is not None:
            cross_dx, cross_dy, cross_dist = center_offset((r["centroid_x"], r["centroid_y"]), self.crosshair_pos)
            cross_dx *= scale; cross_dy *= scale; cross_dist *= scale
        if self.reference_metrics and self.reference_image is not None and self.reference_image.shape == self.image.shape:
            ref_dx, ref_dy, ref_dist = center_offset(
                (r["centroid_x"], r["centroid_y"]),
                (self.reference_metrics["centroid_x"], self.reference_metrics["centroid_y"]))
            ref_dx *= scale; ref_dy *= scale; ref_dist *= scale
        rec = {"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "image": self.meta.get("name", ""),
               "unit": "µm", "centroid_x": r["centroid_x"]*scale, "centroid_y": r["centroid_y"]*scale,
               "d4sigma_x": r["d4sigma_x"]*scale, "d4sigma_y": r["d4sigma_y"]*scale,
               "fwhm_x": r["fwhm_x"]*scale, "fwhm_y": r["fwhm_y"]*scale, "ellipticity": r["ellipticity"],
               "orientation_deg": r["orientation_deg"], "cross_delta_x": cross_dx, "cross_delta_y": cross_dy,
               "cross_distance": cross_dist, "reference_delta_x": ref_dx, "reference_delta_y": ref_dy,
               "reference_distance": ref_dist, "quality": r["quality"]}
        self.records.append(rec); self._insert_record(rec)
        self.status_var.set(f"已记录第 {len(self.records)} 条测量结果（µm）。")

    def _insert_record(self, rec: dict[str, Any]) -> None:
        self.tree.insert("", "end", values=(rec.get("time", "").split(" ")[-1], _fmt(rec.get("centroid_x"),1),
                          _fmt(rec.get("centroid_y"),1), _fmt(rec.get("d4sigma_x"),1),
                          _fmt(rec.get("d4sigma_y"),1), rec.get("quality", "")))

    def _rebuild_log(self) -> None:
        for item in self.tree.get_children(): self.tree.delete(item)
        for rec in self.records: self._insert_record(rec)

    def clear_log(self) -> None:
        if self.records and not messagebox.askyesno("清空记录", "确定清空本次会话的测量记录吗？", parent=self.root): return
        self.records.clear(); self._rebuild_log()

    def _build_reference_display_overlay(self, image: np.ndarray, metrics: dict[str, Any]) -> np.ndarray:
        rgba = make_reference_overlay(image, metrics["baseline"], metrics["peak"],
                                      metrics.get("clip_percent", 13.5), color=(255, 40, 210))
        h, w = rgba.shape[:2]
        shrink = min(1.0, 700.0 / max(h, w))
        if shrink < 1.0:
            size = (max(1, round(w * shrink)), max(1, round(h * shrink)))
            rgba = np.asarray(Image.fromarray(rgba).resize(size, resample=Image.Resampling.NEAREST))
        return rgba

    def record_reference(self) -> None:
        if self.result is None or self._result_generation != self._analysis_generation:
            messagebox.showinfo("请稍候", "当前图像仍在分析，请等读数更新后再记录参考光斑。", parent=self.root)
            return
        if self.reference_image is not None and not messagebox.askyesno(
                "替换参考光斑", "已存在一个参考光斑。要用当前图像替换它吗？", parent=self.root):
            return
        self.reference_image = self.image.copy()
        self.reference_white_level = float(self.white_level)
        self.reference_meta = dict(self.meta)
        keys = ("centroid_x", "centroid_y", "baseline", "peak", "clip_percent",
                "d4sigma_x", "d4sigma_y", "orientation_deg", "ellipticity")
        self.reference_metrics = {key: float(self.result[key]) for key in keys}
        self.reference_rgba = self._build_reference_display_overlay(self.reference_image, self.reference_metrics)
        self.show_reference.set(True)
        h, w = self.reference_image.shape
        scale = float(self.result.get("scale_um_per_px") or DEFAULT_SENSOR_SCALE_UM_PER_PX)
        name = self.reference_meta.get("name", "参考光斑")
        self.reference_status_var.set(f"参考：{name} · {w*scale:.0f} × {h*scale:.0f} µm · 透明洋红叠加")
        self._update_crosshair_metrics()
        self.render()
        self.status_var.set("已记录参考光斑；它只作为显示叠加，不会参与当前帧分析。")

    def clear_reference(self) -> None:
        self.reference_image = None; self.reference_rgba = None
        self.reference_metrics = None; self.reference_meta = None
        self.reference_artist = None; self.reference_center_artist = None
        self.reference_status_var.set("尚未记录参考光斑")
        self._update_crosshair_metrics()
        self.render()
        self.status_var.set("参考光斑已清除。")

    def toggle_reference_display(self) -> None:
        visible = bool(self.show_reference.get())
        if visible and self.reference_rgba is not None and self.reference_artist is None:
            self.render()
            return
        for artist in (self.reference_artist, self.reference_center_artist):
            if artist is not None:
                artist.set_visible(visible)
        self._blit_crosshair()
        self._live_render_signature = self._live_render_key()
        self.status_var.set("参考光斑叠加已显示。" if visible else "参考光斑仅隐藏，记录仍保留。")

    def set_reference_opacity(self, value: str | float) -> None:
        try:
            opacity = float(np.clip(float(value), 0.0, 1.0))
        except (TypeError, ValueError):
            opacity = float(self.reference_opacity.get())
        self.reference_opacity_text.set(f"{round(opacity * 100):d}%")
        if self.reference_artist is not None:
            self.reference_artist.set_alpha(opacity)
            self._blit_crosshair()

    def _on_close(self) -> None:
        self._camera_closing = True
        if self._render_after_id:
            try: self.root.after_cancel(self._render_after_id)
            except tk.TclError: pass
        if self._analysis_poll_id:
            try: self.root.after_cancel(self._analysis_poll_id)
            except tk.TclError: pass
        for after_id in (self._camera_poll_id, self._camera_operation_poll_id,
                         *self._camera_param_after_ids.values()):
            if after_id:
                try: self.root.after_cancel(after_id)
                except tk.TclError: pass
        with self._camera_control_state_lock:
            self._camera_auto_exposure_enabled = False
        self._camera_capture_stop.set()
        if self._camera_dialog is not None:
            try: self._camera_dialog.destroy()
            except tk.TclError: pass
            self._camera_dialog = None
        thread = self._camera_capture_thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=0.5)

        backend = self._camera_backend
        future = self._camera_future
        action = self._camera_action
        if future is not None:
            if not future.done():
                future.cancel()
                try:
                    result = future.result(timeout=1.5)
                except Exception:
                    result = None
            else:
                try:
                    result = future.result()
                except Exception:
                    result = None
            if action == "enumerate" and result:
                backend = result[0]
        if backend is not None:
            try:
                backend.close()
            except Exception:
                pass

        if self._analysis_future is not None:
            self._analysis_future.cancel()
        self._analysis_executor.shutdown(wait=False, cancel_futures=True)
        self._camera_executor.shutdown(wait=False, cancel_futures=True)
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    SpotLabApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
