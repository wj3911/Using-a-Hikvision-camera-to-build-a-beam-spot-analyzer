"""Core image loading and beam-analysis routines for SpotLab Offline.

The analysis is intentionally independent of any camera SDK. The later MVS
adapter can pass NumPy frames into this module without changing the metrics/UI.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from PIL import Image, ImageOps


@dataclass
class AnalysisOptions:
    subtract_background: bool = True
    lock_background: bool = False
    background_value: float = 0.0
    clip_percent: float = 13.5
    smoothing_radius: int = 0
    fast_mode: bool = False
    sample_step: int | None = None
    scale_um_per_px: float | None = None


def load_grayscale(path: str | Path) -> tuple[np.ndarray, float, dict[str, Any]]:
    """Load the first image/frame and return a 2-D float32 grayscale array.

    8-bit, 16-bit grayscale, RGB and RGBA PNG/JPEG/BMP/TIFF are supported by
    Pillow. For color files, Rec. 709 luma is used for preview analysis.
    """
    path = Path(path)
    with Image.open(path) as im:
        im = ImageOps.exif_transpose(im)
        mode = im.mode
        size = im.size
        if mode in ("I;16", "I;16L", "I;16B"):
            arr = np.asarray(im, dtype=np.uint16).astype(np.float32)
            white = 65535.0
            bit_depth = 16
        elif mode == "I":
            raw = np.asarray(im)
            arr = raw.astype(np.float32)
            # Pillow's mode I is commonly 16-bit TIFF promoted to int32.
            high = float(np.nanmax(arr)) if arr.size else 0.0
            white = 65535.0 if high > 255 else 255.0
            bit_depth = 16 if white > 255 else 8
        elif mode == "F":
            arr = np.asarray(im, dtype=np.float32)
            finite = arr[np.isfinite(arr)]
            white = float(np.max(finite)) if finite.size else 1.0
            if white <= 0:
                white = 1.0
            bit_depth = 32
        elif mode in ("L", "1"):
            arr = np.asarray(im.convert("L"), dtype=np.uint8).astype(np.float32)
            white = 255.0
            bit_depth = 8
        else:
            rgb = np.asarray(im.convert("RGB"), dtype=np.uint8).astype(np.float32)
            arr = 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]
            white = 255.0
            bit_depth = 8
    if arr.ndim != 2:
        raise ValueError(f"需要单帧二维图像，当前维度为 {arr.shape}")
    if not arr.size or not np.isfinite(arr).any():
        raise ValueError("图像为空，或没有有限像素值。")
    arr = np.nan_to_num(arr, copy=False, nan=0.0, posinf=white, neginf=0.0)
    arr = np.maximum(arr, 0).astype(np.float32, copy=False)
    meta = {"path": str(path.resolve()), "name": path.name, "mode": mode,
            "width": int(size[0]), "height": int(size[1]), "bit_depth": bit_depth}
    return arr, float(white), meta


def make_demo_beam(width: int = 1024, height: int = 768, seed: int = 12) -> tuple[np.ndarray, float, dict[str, Any]]:
    """Create a reproducible, slightly rotated elliptical Gaussian test beam."""
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:height, 0:width]
    cx, cy = width * 0.49, height * 0.515
    sx, sy, angle = width * 0.105, height * 0.078, np.deg2rad(17.0)
    ca, sa = np.cos(angle), np.sin(angle)
    dx, dy = x - cx, y - cy
    u, v = ca * dx + sa * dy, -sa * dx + ca * dy
    signal = 223.0 * np.exp(-0.5 * ((u / sx) ** 2 + (v / sy) ** 2))
    # A small secondary feature prevents the sample from looking perfectly synthetic.
    signal += 23.0 * np.exp(-0.5 * (((x - width * .63) / 18.0) ** 2 + ((y - height * .39) / 14.0) ** 2))
    image = np.clip(7.0 + signal + rng.normal(0.0, 1.15, (height, width)), 0, 255).astype(np.float32)
    return image, 255.0, {"path": "", "name": "演示光斑", "mode": "DEMO", "width": width,
                          "height": height, "bit_depth": 8}


def average_frames(frames: Iterable[np.ndarray]) -> np.ndarray:
    """Average equal-sized 2-D frames in float32, rejecting mismatched sizes."""
    seq = list(frames)
    if not seq:
        raise ValueError("没有可平均的图像帧。")
    shape = seq[0].shape
    if any(a.ndim != 2 or a.shape != shape for a in seq):
        raise ValueError("平均帧尺寸必须一致；请先统一图像尺寸。")
    accum = np.zeros(shape, dtype=np.float64)
    for frame in seq:
        accum += np.asarray(frame, dtype=np.float32)
    return (accum / len(seq)).astype(np.float32)


def _border_values(arr: np.ndarray, band: int | None = None) -> np.ndarray:
    h, w = arr.shape
    if band is None:
        band = max(2, min(h, w) // 40)
    band = max(1, min(band, max(1, min(h, w) // 3)))
    return np.concatenate((arr[:band, :].ravel(), arr[-band:, :].ravel(),
                           arr[band:-band, :band].ravel(), arr[band:-band, -band:].ravel()))


def make_reference_overlay(image: np.ndarray, baseline: float, peak: float,
                           clip_percent: float = 13.5,
                           color: tuple[int, int, int] = (255, 40, 210)) -> np.ndarray:
    """Build a transparent tinted reference-beam layer for visualization only.

    The returned RGBA image is an independent overlay; it never alters the live
    image used by analysis. Pixels below the selected reference clip level remain
    transparent.
    """
    arr = np.asarray(image, dtype=np.float32)
    signal = np.maximum(arr - float(baseline), 0.0)
    peak_signal = max(float(peak) - float(baseline), 1e-9)
    fraction = float(np.clip(clip_percent, .5, 99.5)) / 100.0
    threshold = peak_signal * fraction
    mask = signal >= threshold
    denom = max(peak_signal - threshold, 1e-9)
    strength = np.clip((signal - threshold) / denom, 0.0, 1.0)
    rgba = np.zeros((*arr.shape, 4), dtype=np.uint8)
    rgba[..., 0] = np.uint8(np.clip(color[0], 0, 255))
    rgba[..., 1] = np.uint8(np.clip(color[1], 0, 255))
    rgba[..., 2] = np.uint8(np.clip(color[2], 0, 255))
    alpha = np.where(mask, 55.0 + 200.0 * strength, 0.0)
    rgba[..., 3] = np.clip(alpha, 0, 255).astype(np.uint8)
    return rgba


def center_offset(center: tuple[float, float], target: tuple[float, float]) -> tuple[float, float, float]:
    """Return signed X/Y offset (center minus target) and radial distance in pixels."""
    dx = float(center[0]) - float(target[0])
    dy = float(center[1]) - float(target[1])
    return dx, dy, float(np.hypot(dx, dy))


def estimate_background(arr: np.ndarray) -> tuple[float, float]:
    """Robust edge baseline and conventional standard deviation estimate."""
    edge = _border_values(arr)
    if not edge.size:
        return 0.0, 0.0
    # Sampling a maximum of ~250k edge values keeps large TIFFs responsive.
    stride = max(1, edge.size // 250_000)
    edge = edge[::stride].astype(np.float64, copy=False)
    median = float(np.median(edge))
    std = float(np.std(edge))
    return median, std


def _box_smooth(arr: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return arr
    radius = min(int(radius), 5)
    k = 2 * radius + 1
    # Separable box filter with reflect padding; memory stays bounded to a few frames.
    p = np.pad(arr, ((0, 0), (radius, radius)), mode="reflect")
    out = np.zeros_like(arr, dtype=np.float32)
    for i in range(k):
        out += p[:, i:i + arr.shape[1]]
    out /= k
    p = np.pad(out, ((radius, radius), (0, 0)), mode="reflect")
    out2 = np.zeros_like(arr, dtype=np.float32)
    for i in range(k):
        out2 += p[i:i + arr.shape[0], :]
    out2 /= k
    return out2


def _smooth_profile(profile: np.ndarray, radius: int = 1) -> np.ndarray:
    """Small 1-D box filter to suppress pixel-scale speckle in projected profiles."""
    values = np.asarray(profile, dtype=np.float64)
    if radius <= 0 or values.size < 3:
        return values
    radius = min(int(radius), 5, max(0, (values.size - 1) // 2))
    padded = np.pad(values, (radius, radius), mode="edge")
    kernel = np.full(2 * radius + 1, 1.0 / (2 * radius + 1), dtype=np.float64)
    return np.convolve(padded, kernel, mode="valid")


def _crossing_width(profile: np.ndarray, coords: np.ndarray, baseline: float, fraction: float) -> float:
    """Measure the main-lobe threshold width, ignoring isolated below-level speckle dips.

    A single noisy pixel inside a saturated/flat-topped profile must not collapse
    the reported FWHM to one pixel. Require two consecutive samples below the
    crossing level while walking outwards from the peak.
    """
    if profile.size < 2 or coords.size != profile.size:
        return 0.0
    values = np.asarray(profile, dtype=np.float64)
    x = np.asarray(coords, dtype=np.float64)
    peak_i = int(np.argmax(values))
    peak = float(values[peak_i])
    level = float(baseline) + max(0.0, peak - float(baseline)) * float(fraction)
    if peak <= baseline:
        return 0.0

    def find_edge(direction: int) -> float:
        index = peak_i + direction
        below_run = 0
        first_below = -1
        while 0 <= index < values.size:
            if values[index] < level:
                if below_run == 0:
                    first_below = index
                below_run += 1
                if below_run >= 2:
                    inner = first_below - direction
                    low_value, high_value = float(values[first_below]), float(values[inner])
                    denom = high_value - low_value
                    t = 0.0 if abs(denom) < 1e-12 else (level - low_value) / denom
                    return float(x[first_below] + t * (x[inner] - x[first_below]))
            else:
                below_run = 0
                first_below = -1
            index += direction
        return float(x[0] if direction < 0 else x[-1])

    left = find_edge(-1)
    right = find_edge(1)
    return max(0.0, right - left)


def _fit_gaussian(profile: np.ndarray, coords: np.ndarray, baseline: float) -> dict[str, float | bool]:
    """Log-quadratic Gaussian fit; returns width/FWHM and an R² diagnostic."""
    signal = np.maximum(profile.astype(np.float64) - baseline, 0.0)
    if signal.size < 5 or float(signal.max(initial=0)) <= 0:
        return {"valid": False, "center": float("nan"), "sigma": float("nan"),
                "fwhm": float("nan"), "amplitude": float("nan"), "r2": float("nan")}
    threshold = signal.max() * 0.025
    mask = signal > max(threshold, 1e-12)
    if mask.sum() < 5:
        return {"valid": False, "center": float("nan"), "sigma": float("nan"),
                "fwhm": float("nan"), "amplitude": float("nan"), "r2": float("nan")}
    x = coords[mask].astype(np.float64)
    y = np.log(np.maximum(signal[mask], 1e-12))
    try:
        a, b, c = np.linalg.lstsq(np.column_stack((np.ones_like(x), x, x * x)), y, rcond=None)[0]
    except np.linalg.LinAlgError:
        return {"valid": False, "center": float("nan"), "sigma": float("nan"),
                "fwhm": float("nan"), "amplitude": float("nan"), "r2": float("nan")}
    if c >= -1e-15:
        return {"valid": False, "center": float("nan"), "sigma": float("nan"),
                "fwhm": float("nan"), "amplitude": float("nan"), "r2": float("nan")}
    sigma = float(np.sqrt(-1.0 / (2.0 * c)))
    center = float(-b / (2.0 * c))
    amp = float(np.exp(a - b * b / (4.0 * c)))
    prediction = baseline + amp * np.exp(-0.5 * ((coords.astype(np.float64) - center) / sigma) ** 2)
    observed = profile.astype(np.float64)
    ss_res = float(np.sum((observed - prediction) ** 2))
    ss_tot = float(np.sum((observed - np.mean(observed)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-12 else float("nan")
    return {"valid": True, "center": center, "sigma": sigma, "fwhm": 2.354820045 * sigma,
            "amplitude": amp, "r2": r2}


def _top_hat_fit(profile: np.ndarray, coords: np.ndarray, baseline: float) -> dict[str, float | bool]:
    if profile.size < 3:
        return {"valid": False, "center": float("nan"), "width": float("nan"), "plateau": float("nan"), "r2": float("nan")}
    peak = float(np.max(profile))
    if peak <= baseline:
        return {"valid": False, "center": float("nan"), "width": float("nan"), "plateau": float("nan"), "r2": float("nan")}
    level = baseline + .5 * (peak - baseline)
    mask = profile >= level
    inds = np.flatnonzero(mask)
    if inds.size < 2:
        return {"valid": False, "center": float("nan"), "width": float("nan"), "plateau": float("nan"), "r2": float("nan")}
    left_i, right_i = int(inds[0]), int(inds[-1])
    width = float(coords[right_i] - coords[left_i])
    center = float((coords[right_i] + coords[left_i]) / 2)
    plateau = float(np.mean(profile[left_i:right_i + 1]))
    fitted = np.full(profile.shape, baseline, dtype=np.float64)
    fitted[left_i:right_i + 1] = plateau
    ss_res = float(np.sum((profile - fitted) ** 2))
    ss_tot = float(np.sum((profile - np.mean(profile)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-12 else float("nan")
    return {"valid": True, "center": center, "width": width, "plateau": plateau, "r2": r2}


def _encircled_energy_diameter(weights: np.ndarray, xcoords: np.ndarray, ycoords: np.ndarray,
                               cx: float, cy: float, total: float, fraction: float = .99) -> float:
    """Approximate 99% encircled-energy diameter without allocating a full radius map."""
    max_radius = int(np.ceil(np.hypot(max(abs(xcoords[0] - cx), abs(xcoords[-1] - cx)),
                                      max(abs(ycoords[0] - cy), abs(ycoords[-1] - cy))))) + 2
    hist = np.zeros(max_radius + 1, dtype=np.float64)
    dx2 = (xcoords.astype(np.float64) - cx) ** 2
    for iy, y in enumerate(ycoords):
        bins = np.floor(np.sqrt(dx2 + (float(y) - cy) ** 2)).astype(np.int32)
        hist += np.bincount(bins, weights=weights[iy].astype(np.float64), minlength=hist.size)[:hist.size]
    idx = int(np.searchsorted(np.cumsum(hist), total * fraction))
    return float(2 * min(idx, hist.size - 1))


def analyze_image(image: np.ndarray, white_level: float = 255.0,
                  options: AnalysisOptions | None = None,
                  roi: tuple[int, int, int, int] | None = None) -> dict[str, Any]:
    """Analyze a grayscale image and return metrics plus profile arrays.

    Coordinates/widths are reported in original input pixels, even in fast mode.
    `roi` uses (x0, y0, x1, y1) in original image coordinates.
    """
    opts = options or AnalysisOptions()
    src = np.asarray(image, dtype=np.float32)
    if src.ndim != 2 or not src.size:
        raise ValueError("分析输入必须是非空的二维灰度图像。")
    h0, w0 = src.shape
    step = max(1, int(opts.sample_step)) if opts.sample_step is not None else (2 if opts.fast_mode else 1)
    if step > 1:
        work = src[::step, ::step]
    else:
        work = src
    h, w = work.shape
    if roi is None:
        ox0, oy0, ox1, oy1 = 0, 0, w0, h0
    else:
        ox0, oy0, ox1, oy1 = map(int, roi)
        ox0, ox1 = max(0, min(ox0, w0 - 1)), max(1, min(ox1, w0))
        oy0, oy1 = max(0, min(oy0, h0 - 1)), max(1, min(oy1, h0))
        if ox1 <= ox0 or oy1 <= oy0:
            raise ValueError("ROI 区域无效。")
    ix0, iy0 = ox0 // step, oy0 // step
    ix1, iy1 = max(ix0 + 1, int(np.ceil(ox1 / step))), max(iy0 + 1, int(np.ceil(oy1 / step)))
    ix1, iy1 = min(ix1, w), min(iy1, h)
    crop_raw = work[iy0:iy1, ix0:ix1]
    if crop_raw.size < 4:
        raise ValueError("ROI 区域像素太少。")
    smoothed = _box_smooth(crop_raw, opts.smoothing_radius)
    estimated_bg, background_std = estimate_background(smoothed)
    baseline = float(opts.background_value) if opts.lock_background else estimated_bg
    if not opts.subtract_background:
        baseline_for_weights = 0.0
    else:
        baseline_for_weights = baseline
    weights = np.maximum(smoothed - baseline_for_weights, 0.0).astype(np.float32, copy=False)
    total = float(np.sum(weights, dtype=np.float64))
    if total <= 1e-9:
        raise ValueError("没有可分析的光斑信号；请检查图像、背景值或 ROI。")

    xcoords = (ix0 + np.arange(crop_raw.shape[1], dtype=np.float64)) * step
    ycoords = (iy0 + np.arange(crop_raw.shape[0], dtype=np.float64)) * step
    proj_x = np.sum(weights, axis=0, dtype=np.float64)
    proj_y = np.sum(weights, axis=1, dtype=np.float64)
    cx = float(np.dot(xcoords, proj_x) / total)
    cy = float(np.dot(ycoords, proj_y) / total)
    var_x = float(np.dot((xcoords - cx) ** 2, proj_x) / total)
    var_y = float(np.dot((ycoords - cy) ** 2, proj_y) / total)
    row_xsum = weights.astype(np.float64, copy=False) @ xcoords
    mean_xy = float(np.dot(ycoords, row_xsum) / total)
    cov_xy = mean_xy - cx * cy
    var_x, var_y = max(var_x, 0.0), max(var_y, 0.0)
    d4x, d4y = 4.0 * np.sqrt(var_x), 4.0 * np.sqrt(var_y)
    trace = var_x + var_y
    disc = float(np.sqrt(max(0.0, (var_x - var_y) ** 2 + 4 * cov_xy ** 2)))
    eig1, eig2 = max(0.0, (trace + disc) / 2), max(0.0, (trace - disc) / 2)
    d4_major, d4_minor = 4 * np.sqrt(eig1), 4 * np.sqrt(eig2)
    angle = float(0.5 * np.degrees(np.arctan2(2 * cov_xy, var_x - var_y)))
    ellipticity = float(d4_major / max(d4_minor, 1e-12))

    # Profiles pass through the nearest sampled pixel to the weighted centroid.
    local_x = int(np.clip(round(cx / step) - ix0, 0, crop_raw.shape[1] - 1))
    local_y = int(np.clip(round(cy / step) - iy0, 0, crop_raw.shape[0] - 1))
    xprof = smoothed[local_y, :].astype(np.float32, copy=True)
    yprof = smoothed[:, local_x].astype(np.float32, copy=True)
    # A single camera row/column can cut through coherent speckle or a clipped
    # pixel patch and report a misleadingly tiny width. Use the background-treated
    # 1-D marginal profiles for quantitative threshold widths and fits; retain the
    # center-line profiles separately for users who want to inspect a cross-section.
    x_projection = _smooth_profile(proj_x / crop_raw.shape[0])
    y_projection = _smooth_profile(proj_y / crop_raw.shape[1])
    x_widths = {p: _crossing_width(x_projection, xcoords, 0.0, p / 100.0)
                for p in (13.5, 50.0, 86.5)}
    y_widths = {p: _crossing_width(y_projection, ycoords, 0.0, p / 100.0)
                for p in (13.5, 50.0, 86.5)}
    clip = float(np.clip(opts.clip_percent, .5, 99.5))
    clip_x = _crossing_width(x_projection, xcoords, 0.0, clip / 100.0)
    clip_y = _crossing_width(y_projection, ycoords, 0.0, clip / 100.0)
    gx = _fit_gaussian(x_projection, xcoords, 0.0)
    gy = _fit_gaussian(y_projection, ycoords, 0.0)
    tx = _top_hat_fit(x_projection, xcoords, 0.0)
    ty = _top_hat_fit(y_projection, ycoords, 0.0)
    peak = float(np.max(crop_raw))
    peak_flat = int(np.argmax(crop_raw))
    peak_y_local, peak_x_local = np.unravel_index(peak_flat, crop_raw.shape)
    peak_x = float(xcoords[peak_x_local]); peak_y = float(ycoords[peak_y_local])
    saturation_limit = float(white_level) * .995
    saturated_fraction = float(np.count_nonzero(crop_raw >= saturation_limit) / crop_raw.size)
    near_edge = (cx < w0 * .015 or cx > w0 * .985 or cy < h0 * .015 or cy > h0 * .985)
    snr = float((peak - baseline) / max(background_std, 1e-9))
    quality_reasons = []
    if saturated_fraction > .001:
        quality_reasons.append("存在饱和像素")
    if near_edge:
        quality_reasons.append("光斑靠近图像边缘")
    if snr < 5:
        quality_reasons.append("信噪比较低")
    quality = "检查" if quality_reasons else "良好"
    ee99 = _encircled_energy_diameter(weights, xcoords, ycoords, cx, cy, total, .99)
    scale = float(opts.scale_um_per_px) if opts.scale_um_per_px and opts.scale_um_per_px > 0 else None
    return {
        "width": int(w0), "height": int(h0), "analysis_width": int(crop_raw.shape[1]),
        "analysis_height": int(crop_raw.shape[0]), "fast_step": step,
        "baseline": float(baseline), "baseline_std": float(background_std),
        "peak": peak, "peak_x": peak_x, "peak_y": peak_y, "centroid_x": cx, "centroid_y": cy,
        "sum_intensity": total, "snr": snr, "saturated_fraction": saturated_fraction,
        "d4sigma_x": float(d4x), "d4sigma_y": float(d4y),
        "d4sigma_major": float(d4_major), "d4sigma_minor": float(d4_minor),
        "orientation_deg": angle, "ellipticity": ellipticity, "clip_percent": clip,
        "clip_width_x": float(clip_x), "clip_width_y": float(clip_y),
        "width_13_5_x": float(x_widths[13.5]), "width_13_5_y": float(y_widths[13.5]),
        "fwhm_x": float(x_widths[50.0]), "fwhm_y": float(y_widths[50.0]),
        "width_86_5_x": float(x_widths[86.5]), "width_86_5_y": float(y_widths[86.5]),
        "encircled_energy_99_diameter": float(ee99),
        "gaussian_x": gx, "gaussian_y": gy, "tophat_x": tx, "tophat_y": ty,
        "quality": quality, "quality_reasons": quality_reasons,
        "scale_um_per_px": scale, "x_profile": xprof, "y_profile": yprof,
        "x_projection": x_projection.astype(np.float32),
        "y_projection": y_projection.astype(np.float32),
        "x_coords": xcoords, "y_coords": ycoords, "processed_image": smoothed,
        "roi": (ox0, oy0, ox1, oy1), "profile_anchor": (peak_x, peak_y),
        "x_profile_y": float(ycoords[local_y]), "y_profile_x": float(xcoords[local_x]),
        "white_level": float(white_level),
    }
